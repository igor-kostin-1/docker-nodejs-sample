--
-- Create a database using `MYSQL_DATABASE` placeholder
--
CREATE DATABASE IF NOT EXISTS `MYSQL_DATABASE`;



 
MYSQL_HOST="localhost"
MYSQL_PORT="3306"
MYSQL_ROOT_USER=`MYSQL_USER`
MYSQL_ROOT_PASSWORD=`MYSQL_PASSWORD`

# Check if the user already exists
existing_user=$(mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_ROOT_USER -p$MYSQL_ROOT_PASSWORD -e "SELECT 1 FROM mysql.user WHERE user='$MYSQL_USER';" | grep -q 1; echo $?)

if [ $existing_user -eq 0 ]; then
    echo "User '$MYSQL_USER' already exists."
else
    # Create the new user
    mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_ROOT_USER -p$MYSQL_ROOT_PASSWORD -e "CREATE USER '$MYSQL_USER'@'%' IDENTIFIED BY '$MYSQL_PASSWORD';"
    echo "User '$MYSQL_USER' created successfully."

    # Grant access to the specified database
    mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_ROOT_USER -p$MYSQL_ROOT_PASSWORD -e "GRANT ALL PRIVILEGES ON $MYSQL_DATABASE.* TO '$MYSQL_USER'@'%';"
    mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_ROOT_USER -p$MYSQL_ROOT_PASSWORD -e "FLUSH PRIVILEGES;"
    echo "All privileges granted to user '$MYSQL_USER' for database '$MYSQL_DATABASE'."
fi
USE `MYSQL_ROOT_USER`;
USE ``;
USE `MYSQL_DATABASE`;
USE `MYSQL_USER`;
USE `MYSQL_PASSWORD`;
