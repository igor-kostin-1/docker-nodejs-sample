package com.vegait.expensetracker.mapper.common;


import com.vegait.expensetracker.model.common.IEntityObject;

/**
 * SaveIEntityMapper is a specialized IEntityMapper implementation used for creating new entities.
 * It ensures that the identifier of the entity is set to null before creating a new item.
 *
 * @param <T>     The type of the entity.
 * @param <T_DTO> The type of the DTO representing the entity.
 * @param <T_ID>  The type of the entity's identifier.
 */
public class SaveIEntityMapper<
        T extends IEntityObject<T_ID>,
        T_DTO extends IEntityObject<T_ID>,
        T_ID
        > implements IEntityMapper<T, T_DTO> {

    private final IEntityMapper<T, T_DTO> mapper;

    public SaveIEntityMapper(IEntityMapper<T, T_DTO> mapper) {
        this.mapper = mapper;
    }

    public static <_T extends IEntityObject<_T_ID>, _T_ID> _T saveSafe(_T entity) {
        entity.setId(null);
        return entity;
    }

    /**
     * Maps a DTO to an entity, ensuring that the entity's identifier is set to null.
     *
     * @param tDto The DTO to be mapped to an entity.
     * @return The entity mapped from the DTO with its identifier set to null.
     */
    @Override
    public T toEntity(final T_DTO tDto) {
        T e = this.mapper.toEntity(tDto);
        e.setId(null); // making sure that ID is null before creating new item
        return e;
    }

    @Override
    public T_DTO toDTO(final T entity) {
        return this.mapper.toDTO(entity);
    }

    @Override
    public T updateEntity(T entity, T_DTO tDto) {
        return this.mapper.updateEntity(entity, tDto);
    }
}
