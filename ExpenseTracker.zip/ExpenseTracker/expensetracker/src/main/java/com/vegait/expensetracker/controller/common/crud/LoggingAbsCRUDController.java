package com.vegait.expensetracker.controller.common.crud;

import com.vegait.expensetracker.model.common.IEntityObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * LoggingAbsCRUDController is a class that provides logging capabilities
 * for ICRUDControllerHandler. It serves as a layer before ICRUDControllerHandler
 *
 * @param <T>     The type of entity managed by the controller.
 * @param <T_DTO> The DTO (Data Transfer Object) type representing the entity.
 * @param <T_ID>  The type of the entity's identifier.
 */
@Slf4j
public class LoggingAbsCRUDController<
        T extends IEntityObject<T_ID>,
        T_DTO extends IEntityObject<T_ID>,
        T_ID
        > implements ICRUDControllerHandler<T_DTO, T_ID> {

    private final String plural;
    private final String singular;
    private final ICRUDControllerHandler<T_DTO, T_ID> handler;
    private Authentication auth = null;

    /**
     * Constructs a LoggingAbsCRUDController with the specified handler, plural name, and singular name.
     *
     * @param handler  The handler responsible for executing CRUD operations.
     * @param plural   The plural name of the entity.
     * @param singular The singular name of the entity.
     */
    public LoggingAbsCRUDController(final ICRUDControllerHandler<T_DTO, T_ID> handler, final String plural, final String singular) {
        this.handler = handler;
        this.plural = plural;
        this.singular = singular;
    }

    @Override
    public ResponseEntity<Iterable<T_DTO>> findAll() {
//        log.info("User '{}' request for access of all '{}'", username(), this.entityPlural());
        return this.handler.findAll();
    }

    @Override
    public ResponseEntity<T_DTO> findById(final T_ID id) {
//        log.info("User '{}' request for access '{}' with id: {}", username(), this.entitySingular(), id);
        return this.handler.findById(id);
    }

    @Override
    public ResponseEntity<T_DTO> save(final T_DTO newProvideEntity) {
//        log.info("User '{}' sent request to create new '{}' with values: {}", username(), this.entitySingular(), newProvideEntity);
        return this.handler.save(newProvideEntity);
    }

    @Override
    public ResponseEntity<T_DTO> update(final T_ID id, final T_DTO dto) {
//        log.info("User '{}' sent request for updating '{}' with id: {} and set new values to: '{}'", username(), this.entitySingular(), id, dto);
        return this.handler.update(id, dto);
    }

    @Override
    public ResponseEntity<Void> delete(final T_ID id) {
//        log.info("User '{}' request for deleting '{}' with id: {}", username(), this.entitySingular(), id);
        return this.handler.delete(id);
    }

    private String username() {
        if (this.auth == null) this.auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getName();
    }

    protected String entityPlural() {
        return this.plural;
    }

    protected String entitySingular() {
        return this.singular;
    }

}