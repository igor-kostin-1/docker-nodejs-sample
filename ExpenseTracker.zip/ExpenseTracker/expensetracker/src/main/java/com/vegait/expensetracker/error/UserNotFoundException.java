package com.vegait.expensetracker.error;

public class UserNotFoundException {
}
