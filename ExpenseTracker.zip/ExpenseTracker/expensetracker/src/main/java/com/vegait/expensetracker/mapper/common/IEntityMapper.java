package com.vegait.expensetracker.mapper.common;

/**
 * IEntityMapper is an interface for mapping between entity objects and their corresponding DTOs (Data Transfer Objects).
 *
 * @param <T>     The type of the entity.
 * @param <T_DTO> The type of the DTO representing the entity.
 */
public interface IEntityMapper<T, T_DTO> {

    /**
     * Maps a DTO to an entity.
     *
     * @param dto The DTO to be mapped to an entity.
     * @return The entity mapped from the DTO.
     */
    T toEntity(T_DTO dto);

    /**
     * Maps an entity to a DTO.
     *
     * @param entity The entity to be mapped to a DTO.
     * @return The DTO mapped from the entity.
     */
    T_DTO toDTO(T entity);

    /**
     * Updates an entity with the values from a DTO.
     *
     * @param entity The entity to be updated.
     * @param dto    The DTO containing the updated values.
     * @return The updated entity.
     */
    T updateEntity(T entity, T_DTO dto);
}

