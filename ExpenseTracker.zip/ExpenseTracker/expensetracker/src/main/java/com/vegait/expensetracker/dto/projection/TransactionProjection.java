package com.vegait.expensetracker.dto.projection;

import org.springframework.beans.factory.annotation.Value;

import java.time.ZonedDateTime;

public interface TransactionProjection {
    Long getId();

    String getName();

    String getDescription();

    Double getAmount();

    ZonedDateTime getCreated();

    @Value("#{target.group.name}")
    String getGroupName();

    @Value("#{target.group.id}")
    Long getGroupId();

}
