package com.vegait.expensetracker.mapper;

import com.vegait.expensetracker.dto.IncomeGroupDTO;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.IncomeGroup;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * IncomeGroupMapperImpl is a service class that implements the IEntityMapper interface
 * for mapping between IncomeGroup entities and IncomeGroupDTOs.
 */
@Service
public class IncomeGroupMapper implements IEntityMapper<IncomeGroup, IncomeGroupDTO> {
    @Override
    public IncomeGroup toEntity(final IncomeGroupDTO dto) {
        if (dto == null) return null;
        return new IncomeGroup(dto.getId(), dto.getName(), dto.getDescription());
    }

    @Override
    public IncomeGroupDTO toDTO(final IncomeGroup entity) {
        if (entity == null) return null;
        return new IncomeGroupDTO(entity.getId(), entity.getName(), entity.getDescription());
    }

    /**
     * Updates an existing IncomeGroup entity with the values from an IncomeGroupDTO.
     * Only name and description are updated if not null, otherwise vales from entity will be used.
     *
     * @param entity The existing IncomeGroup entity to be updated.
     * @param dto    The IncomeGroupDTO containing the updated values.
     * @return The updated IncomeGroup entity.
     */
    @Override
    public IncomeGroup updateEntity(IncomeGroup entity, IncomeGroupDTO dto) {
        return IncomeGroup.builder()
                .id(entity.getId())
                .user(entity.getUser())
                .name(StringUtils.hasText(dto.getName()) ? dto.getName() : entity.getName())
                .description(StringUtils.hasText(dto.getDescription()) ? dto.getDescription() : entity.getDescription())
                .build();
    }
}