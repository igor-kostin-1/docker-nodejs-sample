package com.vegait.expensetracker.mapper;

import com.vegait.expensetracker.dto.ExpenseGroupDTO;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.ExpenseGroup;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * ExpenseGroupMapperImpl is a service class that implements the IEntityMapper interface
 * for mapping between ExpenseGroup entities and ExpenseGroupDTOs.
 */
@Service
public class ExpenseGroupMapper implements IEntityMapper<ExpenseGroup, ExpenseGroupDTO> {
    @Override
    public ExpenseGroup toEntity(final ExpenseGroupDTO dto) {
        if (dto == null) return null;
        return new ExpenseGroup(dto.getId(), dto.getName(), dto.getDescription());
    }

    @Override
    public ExpenseGroupDTO toDTO(final ExpenseGroup entity) {
        if (entity == null) return null;
        return new ExpenseGroupDTO(entity.getId(), entity.getName(), entity.getDescription());
    }

    /**
     * Updates an existing ExpenseGroup entity with the values from an ExpenseGroupDTO.
     * Only name and description are updated if not null, otherwise vales from entity will be used.
     *
     * @param entity The existing ExpenseGroup entity to be updated.
     * @param dto    The ExpenseGroup containing the updated values.
     * @return The updated ExpenseGroup entity.
     */
    @Override
    public ExpenseGroup updateEntity(ExpenseGroup entity, ExpenseGroupDTO dto) {
        return ExpenseGroup.builder()
                .id(entity.getId())
                .user(entity.getUser())
                .name(StringUtils.hasText(dto.getName()) ? dto.getName() : entity.getName())
                .description(StringUtils.hasText(dto.getDescription()) ? dto.getDescription() : entity.getDescription())
                .build();
    }
}
