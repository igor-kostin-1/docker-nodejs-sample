package com.vegait.expensetracker.dto.projection;

import lombok.Data;

import java.time.ZonedDateTime;

/**
 * Represents an enhanced projection for TransactionProjection, designed to retain the original class type of the entity represented by the projection.
 */
public interface EnhencedTransactionProjection extends TransactionProjection {

    /**
     * Represents an implementation of EnhancedTransactionProjection.
     */
    @Data
    class ETP implements EnhencedTransactionProjection {
        private Class<?> clazz;
        private Long id;
        private String name;
        private String description;
        private Double amount;
        private ZonedDateTime created;
        private String groupName;
        private Long groupId;


        /**
         * Constructs an instance of ETP using a TransactionProjection instance.
         *
         * @param clazz The class type of the entity.
         * @param tp    The TransactionProjection instance.
         */
        public ETP(Class<?> clazz, TransactionProjection tp) {
            this.clazz = clazz;
            this.id = tp.getId();
            this.name = tp.getName();
            this.description = tp.getDescription();
            this.amount = tp.getAmount();
            this.created = tp.getCreated();
            this.groupName = tp.getGroupName();
            this.groupId = tp.getGroupId();
        }
    }

    Class<?> getClazz();

    void setClazz(Class<?> clazz);
}
