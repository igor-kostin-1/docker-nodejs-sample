package com.vegait.expensetracker.utility.transactionsUtils;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.vegait.expensetracker.dto.projection.EnhencedTransactionProjection;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.utility.format.Formatter;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import java.util.List;
import java.util.Map;

/**
 * Utility class for handling transactions in PDF documents.
 */
public class TransactionPDFUtitly {

    /**
     * Creates a PDF table for displaying transactions.
     *
     * @param transactions The list of transactions to display.
     * @return A PdfPTable representing the transactions.
     * @throws DocumentException if there is an error creating the table.
     */
    public static PdfPTable createTransactionsTable(List<EnhencedTransactionProjection> transactions) throws DocumentException {
        float[] columnWidths = {1, 4, 3, 4, 3};
        PdfPTable table = new PdfPTable(5);
        table.setHorizontalAlignment(Element.ALIGN_LEFT);
        table.setWidths(columnWidths);

        // Styling
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 18, Font.BOLD);
        Font incomeFont = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.ITALIC, BaseColor.GREEN);
        Font expenseFont = FontFactory.getFont(FontFactory.HELVETICA, 14, Font.ITALIC, BaseColor.RED);

        // Header
        addCell(table, "Id", headerFont);
        addCell(table, "Name", headerFont);
        addCell(table, "Amount", headerFont);
        addCell(table, "Group", headerFont);
        addCell(table, "Created", headerFont);

        // Data rows
        for (EnhencedTransactionProjection transaction : transactions) {
            Font font = transaction.getClazz() == Income.class ? incomeFont : expenseFont;
            addCell(table, String.valueOf(transaction.getId()));
            addCell(table, transaction.getName());
            addCell(table, Formatter.number(transaction.getAmount()), font);
            addCell(table, transaction.getGroupName());
            addCell(table, Formatter.time(transaction.getCreated()));
        }

        return table;
    }

    private static void addCell(PdfPTable table, String text) {
        table.addCell(new PdfPCell(new Phrase(text)));
    }

    private static void addCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        table.addCell(cell);
    }

    /**
     * Generates a pie chart representing transactions by group.
     *
     * @param transactions The map of transactions by group.
     * @param title        The title of the chart.
     * @return A JFreeChart representing the pie chart.
     */
    public static JFreeChart createTransactionByGroupPieChart(Map<String, Double> transactions, String title) {
        DefaultPieDataset dataSet = new DefaultPieDataset();
        transactions.forEach(dataSet::setValue);
        return ChartFactory.createPieChart(title, dataSet, true, true, false);
    }

    /**
     * Generates a bar chart representing transactions.
     *
     * @param transactions The map of transactions.
     * @param title        The title of the chart.
     * @param y            The label for the y-axis.
     * @param x            The label for the x-axis.
     * @return A JFreeChart representing the bar chart.
     */
    public static JFreeChart CreateBarChart(Map<String, Double> transactions, String title, String y, String x) {
        DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
        transactions.forEach((k, v) -> dataSet.setValue(v, "Sum", k));
        return ChartFactory.createBarChart(title, x, y, dataSet, PlotOrientation.VERTICAL, false, true, false);
    }

    /**
     * Generates a line chart representing transactions.
     *
     * @param balanceByMonth The map of transactions by month.
     * @param title          The title of the chart.
     * @param y              The label for the y-axis.
     * @param x              The label for the x-axis.
     * @return A JFreeChart representing the line chart.
     */
    public static JFreeChart CreateLineChart(Map<String, Double> balanceByMonth, String title, String y, String x) {
        DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
        balanceByMonth.forEach((k, v) -> dataSet.setValue(v, "Sum", k));
        return ChartFactory.createLineChart(title, x, y, dataSet, PlotOrientation.VERTICAL, true, true, false);
    }
}