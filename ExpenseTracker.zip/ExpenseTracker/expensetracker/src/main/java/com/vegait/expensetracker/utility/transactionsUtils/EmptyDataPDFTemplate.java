package com.vegait.expensetracker.utility.transactionsUtils;

import com.itextpdf.text.DocumentException;

import java.io.FileNotFoundException;
import java.time.Month;

public class EmptyDataPDFTemplate extends TransactionPDFTemplates {
    public EmptyDataPDFTemplate(TransactionDataStats dataStats) {
        super(dataStats);
    }

    @Override
    public byte[] totalTransactionReport() throws DocumentException, FileNotFoundException {
        return super.emptyReport();
    }

    @Override
    public byte[] monthlyTransactionReport(Month month) throws DocumentException, FileNotFoundException {
        return super.emptyReport();
    }
}
