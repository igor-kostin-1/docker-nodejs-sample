package com.vegait.expensetracker.model.common;

/**
 * IEntityObject is an interface representing an object with a generic identifier type.
 * Implementing classes provide methods to retrieve and set the identifier associated with the object.
 *
 * @param <T_ID> The type of the identifier associated with the object.
 */
public interface IEntityObject<T_ID> {

    /**
     * Retrieves the identifier associated with the object.
     *
     * @return The identifier associated with the object.
     */
    T_ID getId();

    /**
     * Sets the identifier associated with the object.
     *
     * @param id The identifier to associate with the object.
     */
    void setId(T_ID id);
}
