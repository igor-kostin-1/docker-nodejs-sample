package com.vegait.expensetracker.security.controller;


import com.vegait.expensetracker.error.UserAlreadyExistException;
import com.vegait.expensetracker.model.Reminder;
import com.vegait.expensetracker.security.enums.ERole;
import com.vegait.expensetracker.security.jwt.JwtUtils;
import com.vegait.expensetracker.security.model.Role;
import com.vegait.expensetracker.security.model.User;
import com.vegait.expensetracker.security.payload.JwtResponse;
import com.vegait.expensetracker.security.payload.LoginRequest;
import com.vegait.expensetracker.security.payload.MessageResponse;
import com.vegait.expensetracker.security.payload.SignupRequest;
import com.vegait.expensetracker.security.repository.RoleRepository;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.security.service.UserDetailsImpl;
import com.vegait.expensetracker.service.SchedulerReportService;
import com.vegait.expensetracker.task.TaskFrequency;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/auth")
public class AuthController {
    AuthenticationManager authenticationManager;
    UserRepository userRepository;
    RoleRepository roleRepository;
    PasswordEncoder encoder;
    SchedulerReportService srs;
    JwtUtils jwtUtils;

    public AuthController(AuthenticationManager authenticationManager, UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder, JwtUtils jwtUtils, SchedulerReportService srs) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.encoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
        this.srs = srs;
    }

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

        log.info("Request for logging in from user with username: '{}'", loginRequest.getUsername());

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);

        UserDetailsImpl<Long> userDetails = (UserDetailsImpl<Long>) authentication.getPrincipal();
        List<String> roles = userDetails.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());

        return ResponseEntity.ok(new JwtResponse(
                jwt,
                userDetails.getId(),
                userDetails.getUsername(),
                userDetails.getFullName(),
                userDetails.getEmail(),
                roles));
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {

        log.info("Request for registering new user with username: '{}' and email: '{}' with roles: '{}'",
                signUpRequest.getUsername(), signUpRequest.getEmail(), signUpRequest.getRole());

        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            throw new UserAlreadyExistException("User with username  already exists");
        }

        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            throw new UserAlreadyExistException("User with email already exists");
        }

        // Create new user's account
        User user = new User(signUpRequest.getUsername(), signUpRequest.getFullName(), signUpRequest.getEmail(), encoder.encode(signUpRequest.getPassword()));

        Set<String> strRoles = signUpRequest.getRole();

        Set<Role> roles = new HashSet<>();

        Role userRole = roleRepository.findByName(ERole.ROLE_USER).orElseThrow(() -> new RuntimeException("Error: Role is not found."));
        Reminder defaultReminder = Reminder.builder()
                .frequency(TaskFrequency.MINUTE)
                .onDay(1)
                .onDayOfWeek(1)
                .onHour(9)
                .build();
        roles.add(userRole); // setting default role

        if (strRoles != null) {
            strRoles.remove(null); // [null]

            strRoles.forEach(role -> {
                switch (role) {
                    case "premium_user":
                        Role adminRole = roleRepository.findByName(ERole.ROLE_PREMIUM_USER)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(adminRole);
//                        user.setReminder(defaultReminder);
                        break;
                    default:
                        roles.add(userRole);
                }

            });
        }

        log.info("Creating new user......");

        user.setRoles(roles.stream().toList());
        userRepository.save(user);

        log.info("User created successfully ......");

        srs.activateUserReminder(user);

        return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
    }
}
