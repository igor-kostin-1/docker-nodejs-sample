package com.vegait.expensetracker.model.common;

/**
 * ITransaction is an interface representing a transaction with a generic group type.
 * Implementing classes provide methods to retrieve and set the group associated with the transaction.
 *
 * @param <T> The type of the group associated with the transaction.
 */
public interface ITransaction<T> {

    /**
     * Retrieves the group associated with the transaction.
     *
     * @return The group associated with the transaction.
     */
    T getGroup();

    /**
     * Sets the group associated with the transaction.
     *
     * @param group The group to associate with the transaction.
     */
    void setGroup(T group);
}
