package com.vegait.expensetracker.error;

public class InvalidEntityField extends RuntimeException {

    public InvalidEntityField(String s) {
        super(s);
    }
}
