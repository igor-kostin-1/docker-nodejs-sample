package com.vegait.expensetracker.mapper.common;

public class CollectionMapperFactory {
    public static <T, T_DTO> ICollectionMapper<T, T_DTO> create(final IEntityMapper<T, T_DTO> mapper) {
        return new ICollectionMapperImpl<>(mapper);
    }
}
