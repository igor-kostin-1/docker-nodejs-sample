package com.vegait.expensetracker.security.payload;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequest {
    @NotBlank(message = "Login Request: Invalid Username: Empty username")
    @NotNull(message = "Login Request: Invalid Username: Username is NULL")
    private String username;


    @NotBlank(message = "Login Request: Invalid Password: Empty password")
    @NotNull(message = "Login Request: Invalid Password: Password is NULL")
    private String password;
}