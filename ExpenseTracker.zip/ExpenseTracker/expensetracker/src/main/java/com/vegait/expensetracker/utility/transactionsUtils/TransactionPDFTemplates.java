package com.vegait.expensetracker.utility.transactionsUtils;

import com.google.common.collect.Iterables;
import com.itextpdf.text.DocumentException;
import com.vegait.expensetracker.utility.format.Formatter;
import com.vegait.expensetracker.utility.pdf.IndentedListBuilder;
import com.vegait.expensetracker.utility.pdf.PDFBuilder;
import lombok.AllArgsConstructor;

import java.io.FileNotFoundException;
import java.time.Month;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.Map;

/**
 * Utility class for generating PDF templates for transaction reports.
 */
@AllArgsConstructor
public class TransactionPDFTemplates {

    private TransactionDataStats dataStats;

    /**
     * Generates a total transaction report in PDF format.
     *
     * @return The byte array representing the PDF document.
     * @throws DocumentException     if there is an error creating the PDF document.
     * @throws FileNotFoundException if the file specified is not found.
     */
    public byte[] totalTransactionReport() throws DocumentException, FileNotFoundException {
        return PDFBuilder.create()
                .withTitle("User transaction report")
                .withSpacing(20F)
                .withElement(
                        IndentedListBuilder.create()
                                .withTitle("User Financial Summary")
                                .withInnerList(IndentedListBuilder
                                        .create()
                                        .withItem(String.format("Total Balance as of %s: %s",
                                                Formatter.time(ZonedDateTime.now()),
                                                Formatter.number(dataStats.getTotalBalance())
                                        ))
                                        .withItem(String.format("Total Incomes as of %s: %s",
                                                Formatter.time(ZonedDateTime.now()),
                                                Formatter.number(dataStats.getTotalIncome())
                                        ))
                                        .withItem(String.format("Total Expenses as of %s: %s",
                                                Formatter.time(ZonedDateTime.now()),
                                                Formatter.number(dataStats.getTotalExpense())
                                        ))
                                        .build())
                                .build()
                )
                .withPage()
                .withChart(TransactionPDFUtitly.CreateLineChart(dataStats.getBalancePerMonth(), "Monthly balance", "Balance", "Month"))
                .withPage()
                .withElement(
                        IndentedListBuilder
                                .create()
                                .withTitle("User incomes report")
                                .withInnerList(IndentedListBuilder
                                        .create()
                                        .withItem(String.format("Your biggest single income was `%s` , it was created on `%s`, you made it in group `%s`, you name it `%s`, with description `%s` !",
                                                Formatter.number(dataStats.getMaxIncomeTransaction().getAmount()),
                                                Formatter.time(dataStats.getMaxIncomeTransaction().getCreated()),
                                                dataStats.getMaxIncomeTransaction().getGroupName(),
                                                dataStats.getMaxIncomeTransaction().getName(),
                                                dataStats.getMaxIncomeTransaction().getDescription()
                                        ))
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Income overview by Groups")
                                                .withItem(String.format("Your most profitable income group was `%s`, with total amount  `%s`",
                                                        Iterables.getFirst(dataStats.getIncomeSumAmountByGroupSorted().entrySet(), null).getKey(),
                                                        Formatter.number(Iterables.getFirst(dataStats.getIncomeSumAmountByGroupSorted().entrySet(), null).getValue())
                                                ))
                                                .withItem(String.format("Your least profitable income group was `%s`, with total income `%s`",
                                                        Iterables.getLast(dataStats.getIncomeSumAmountByGroupSorted().entrySet()).getKey(),
                                                        Formatter.number(Iterables.getLast(dataStats.getIncomeSumAmountByGroupSorted().entrySet()).getValue())
                                                ))
                                                .build())
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Income overview by Month")
                                                .withItem(String.format("Your most profitable month was `%s`, with total amount  `%s`",
                                                        Collections.max(dataStats.getIncomeSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        Formatter.number(Collections.max(dataStats.getIncomeSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .withItem(String.format("Your least profitable month was `%s`, with total income `%s`",
                                                        Collections.min(dataStats.getIncomeSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        Formatter.number(Collections.min(dataStats.getIncomeSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .build())
                                        .build())
                                .build()
                )
                .withPage()
                .withChart(TransactionPDFUtitly.createTransactionByGroupPieChart(
                        dataStats.getIncomeSumAmountByGroupSorted(),
                        "Incomes by group"
                ))
                .withPage()
                .withChart(TransactionPDFUtitly.CreateBarChart(
                                dataStats.getIncomeSumAmountByMonthSorted(),
                                "Incomes by month",
                                "Total income",
                                "Months"
                        )
                )
                .withPage()
                .withElement(
                        IndentedListBuilder
                                .create()
                                .withTitle("User expenses report")
                                .withInnerList(IndentedListBuilder
                                        .create()
                                        .withItem(String.format("Your biggest single expense was `%s` , it was created on `%s`, you made it in group `%s`, you name it `%s`, with description `%s` !",
                                                Formatter.number(dataStats.getMaxExpenseTransaction().getAmount()),
                                                Formatter.time(dataStats.getMaxExpenseTransaction().getCreated()),
                                                dataStats.getMaxExpenseTransaction().getGroupName(),
                                                dataStats.getMaxExpenseTransaction().getName(),
                                                dataStats.getMaxExpenseTransaction().getDescription()
                                        ))
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Expanse overview by Groups")
                                                .withItem(String.format("You spend the most money on `%s`, with total amount  `%s`",
                                                        Iterables.getFirst(dataStats.getExpenseSumAmountByGroupSorted().entrySet(), null).getKey(),
                                                        Formatter.number(Iterables.getFirst(dataStats.getExpenseSumAmountByGroupSorted().entrySet(), null).getValue())
                                                ))
                                                .withItem(String.format("Your spent the lest money on `%s`, with total income `%s`",
                                                        Iterables.getLast(dataStats.getExpenseSumAmountByGroupSorted().entrySet()).getKey(),
                                                        Formatter.number(Iterables.getLast(dataStats.getExpenseSumAmountByGroupSorted().entrySet()).getValue())
                                                ))
                                                .build())
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Expense overview by Month")
                                                .withItem(String.format("You made the most expenses in `%s`, with total amount  `%s`",
                                                        Collections.max(dataStats.getExpenseSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        Formatter.number(Collections.max(dataStats.getExpenseSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .withItem(String.format("You have saved the most money n `%s`, with total income `%s`",
                                                        Collections.min(dataStats.getExpenseSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        Formatter.number(Collections.min(dataStats.getExpenseSumAmountByMonthSorted().entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .build())
                                        .build())
                                .build()
                )
                .withPage()
                .withChart(TransactionPDFUtitly.createTransactionByGroupPieChart(
                        dataStats.getExpenseSumAmountByGroupSorted(),
                        "Expenses by group"
                ))
                .withPage()
                .withChart(TransactionPDFUtitly.CreateBarChart(
                                dataStats.getExpenseSumAmountByMonthSorted(),
                                "Expense by month",
                                "Total expense",
                                "Months"
                        )
                )
                .withPage()
                .withTitle("All expenses sorted by date")
                .withElement(TransactionPDFUtitly.createTransactionsTable(dataStats.getTransactionSortedByCreated()))
                .getBytes();
    }

    public byte[] monthlyTransactionReport(Month month) throws DocumentException, FileNotFoundException {
        return PDFBuilder.create()
                .withTitle("User transaction report for " + month.name())
                .withSpacing(50F)
                .withElement(
                        IndentedListBuilder
                                .create()
                                .withTitle("User incomes report")
                                .withInnerList(IndentedListBuilder
                                        .create()
                                        .withItem(String.format("Your biggest single income in %s was `%s` , it was created on `%s`, you made it in group `%s`, you name it `%s`, with description `%s` !",
                                                month.name(),
                                                Formatter.number(dataStats.getMaxIncomeTransaction().getAmount()),
                                                Formatter.time(dataStats.getMaxIncomeTransaction().getCreated()),
                                                dataStats.getMaxIncomeTransaction().getGroupName(),
                                                dataStats.getMaxIncomeTransaction().getName(),
                                                dataStats.getMaxIncomeTransaction().getDescription()
                                        ))
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Income overview by Groups")
                                                .withItem(String.format("Your most profitable income group in %s was `%s`, with total amount  `%s`",
                                                        month.name(),
                                                        Iterables.getFirst(dataStats.getIncomeSumAmountByGroupSorted().entrySet(), null).getKey(),
                                                        Formatter.number(Iterables.getFirst(dataStats.getIncomeSumAmountByGroupSorted().entrySet(), null).getValue())
                                                ))
                                                .withItem(String.format("Your least profitable income group in %s was `%s`, with total income `%s`",
                                                        month.name(),
                                                        Iterables.getLast(dataStats.getIncomeSumAmountByGroupSorted().entrySet()).getKey(),
                                                        Formatter.number(Iterables.getLast(dataStats.getIncomeSumAmountByGroupSorted().entrySet()).getValue())
                                                ))
                                                .build())
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Income overview by Days")
                                                .withItem(String.format("Most profitable day in %s `%s`, with total amount  `%s`",
                                                        month.name(),
                                                        Collections.max(dataStats.transactionByDay(dataStats.getIncomes(), month).entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        Formatter.number(Collections.max(dataStats.transactionByDay(dataStats.getIncomes(), month).entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .withItem(String.format("Your least profitable day in %s was `%s`, with total income `%s`",
                                                        month.name(),
                                                        Collections.min(dataStats.transactionByDay(dataStats.getIncomes(), month).entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        Formatter.number(Collections.min(dataStats.transactionByDay(dataStats.getIncomes(), month).entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .build())
                                        .build())
                                .build()
                )
                .withPage()
                .withChart(TransactionPDFUtitly.createTransactionByGroupPieChart(
                        dataStats.getIncomeSumAmountByGroupSorted(),
                        "Incomes by group"
                ))
                .withPage()
                .withChart(TransactionPDFUtitly.CreateBarChart(
                                dataStats.transactionByDay(dataStats.getIncomes(), month),
                                "Incomes by day",
                                "Total income",
                                "Months"
                        )
                )
                .withPage()
                .withElement(
                        IndentedListBuilder
                                .create()
                                .withTitle("User expenses report")
                                .withInnerList(IndentedListBuilder
                                        .create()
                                        .withItem(String.format("Your biggest single expense in %s was `%s` , it was created on `%s`, you made it in group `%s`, you name it `%s`, with description `%s` !",
                                                month.name(),
                                                Formatter.number(dataStats.getMaxExpenseTransaction().getAmount()),
                                                Formatter.time(dataStats.getMaxExpenseTransaction().getCreated()),
                                                dataStats.getMaxExpenseTransaction().getGroupName(),
                                                dataStats.getMaxExpenseTransaction().getName(),
                                                dataStats.getMaxExpenseTransaction().getDescription()
                                        ))
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Expanse overview by Groups")
                                                .withItem(String.format("In %s you spent the most money on  %s, with total amount  `%s`",
                                                        month.name(),
                                                        Iterables.getFirst(dataStats.getExpenseSumAmountByGroupSorted().entrySet(), null).getKey(),
                                                        Formatter.number(Iterables.getFirst(dataStats.getExpenseSumAmountByGroupSorted().entrySet(), null).getValue())
                                                ))
                                                .withItem(String.format("In %s your spent the lest money on %s, with total income `%s`",
                                                        month.name(),
                                                        Iterables.getLast(dataStats.getExpenseSumAmountByGroupSorted().entrySet()).getKey(),
                                                        Formatter.number(Iterables.getLast(dataStats.getExpenseSumAmountByGroupSorted().entrySet()).getValue())
                                                ))
                                                .build())
                                        .withInnerList(IndentedListBuilder.create()
                                                .withTitle("Expense overview by Day")
                                                .withItem(String.format("In %s you made the most expenses in %sth %s, with total amount  `%s`",
                                                        month.name(),
                                                        Collections.max(dataStats.transactionByDay(dataStats.getExpenses(), month).entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        month.name(),
                                                        Formatter.number(Collections.max(dataStats.transactionByDay(dataStats.getExpenses(), month).entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .withItem(String.format("In %s you have saved the most money n %sth %s, with total income `%s`",
                                                        month.name(),
                                                        Collections.min(dataStats.transactionByDay(dataStats.getExpenses(), month).entrySet(), Map.Entry.comparingByValue()).getKey(),
                                                        month.name(),
                                                        Formatter.number(Collections.min(dataStats.transactionByDay(dataStats.getExpenses(), month).entrySet(), Map.Entry.comparingByValue()).getValue())
                                                ))
                                                .build())
                                        .build())
                                .build()
                )
                .withPage()
                .withChart(TransactionPDFUtitly.createTransactionByGroupPieChart(
                        dataStats.getExpenseSumAmountByGroupSorted(),
                        "Expenses by group"
                ))
                .withPage()
                .withChart(TransactionPDFUtitly.CreateBarChart(
                                dataStats.transactionByDay(dataStats.getExpenses(), month),
                                "Expense by Day",
                                "Total expense",
                                "Day"
                        )
                )
                .withPage()
                .withTitle("All expenses sorted by date")
                .withElement(TransactionPDFUtitly.createTransactionsTable(dataStats.getTransactionSortedByCreated()))
                .getBytes();
    }

    public byte[] emptyReport() throws DocumentException {
        return PDFBuilder.create()
                .withTitle("User transaction report for ")
                .withSpacing(50F)
                .withParagraph("Sorry ther is no transaction data on which we could make report")
                .getBytes();
    }
}
