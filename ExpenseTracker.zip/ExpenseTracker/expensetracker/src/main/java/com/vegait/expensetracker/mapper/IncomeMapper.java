package com.vegait.expensetracker.mapper;

import com.vegait.expensetracker.dto.IncomeDTO;
import com.vegait.expensetracker.dto.IncomeGroupDTO;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class IncomeMapper implements IEntityMapper<Income, IncomeDTO> {
    IEntityMapper<IncomeGroup, IncomeGroupDTO> dtoMapper;

    public IncomeMapper(IEntityMapper<IncomeGroup, IncomeGroupDTO> dtoMapper) {
        this.dtoMapper = dtoMapper;
    }

    @Override
    public Income toEntity(IncomeDTO dto) {
        if (dto == null) return null;
        return Income.builder()
                .id(dto.getId())
                .name(dto.getName())
                .description(dto.getDescription())
                .amount(dto.getAmount())

                .group(dtoMapper.toEntity(dto.getGroup()))

                .build();
    }


    @Override
    public IncomeDTO toDTO(Income entity) {
        if (entity == null) return null;
        return IncomeDTO.builder()
                .id(entity.getId())
                .name(entity.getName())
                .description(entity.getDescription())
                .amount(entity.getAmount())

                .group(dtoMapper.toDTO(entity.getGroup()))

                .build();
    }

    /**
     * Updates an existing Income entity with the values from an IncomeDTO.
     * If fields in the DTO are not null or empty, they are updated; otherwise, the original values are retained.
     *
     * @param entity The existing Income entity to be updated.
     * @param dto    The IncomeDTO containing the updated values.
     * @return The updated Income entity.
     */
    @Override
    public Income updateEntity(Income entity, IncomeDTO dto) {
        return Income.builder()
                .id(entity.getId())

                .name(StringUtils.hasText(dto.getName()) ? dto.getName() : entity.getName())
                .description(StringUtils.hasText(dto.getDescription()) ? dto.getDescription() : entity.getDescription())
                .amount(dto.getAmount() != null ? dto.getAmount() : entity.getAmount())

                .user(entity.getUser())
                .group(dto.getGroup() != null ? dtoMapper.toEntity(dto.getGroup()) : entity.getGroup())

                .created(entity.getCreated())
                .lastUpdate(entity.getLastUpdate())

                .build();
    }
}
