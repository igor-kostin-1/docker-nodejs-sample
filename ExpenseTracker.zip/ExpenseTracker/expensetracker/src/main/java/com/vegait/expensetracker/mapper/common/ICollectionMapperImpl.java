package com.vegait.expensetracker.mapper.common;

import java.util.Collection;
import java.util.stream.Collectors;


/**
 * ICollectionMapperImpl is an implementation of the ICollectionMapper interface for mapping collections of entities
 * and their corresponding DTOs (Data Transfer Objects).
 *
 * @param <T>     The type of the entity.
 * @param <T_DTO> The type of the DTO representing the entity.
 */
public class ICollectionMapperImpl<T, T_DTO> implements ICollectionMapper<T, T_DTO> {

    private final IEntityMapper<T, T_DTO> mapper;


    /**
     * Constructs an ICollectionMapperImpl with the specified entity mapper.
     *
     * @param mapper The entity mapper used for mapping between entities and DTOs.
     */
    ICollectionMapperImpl(final IEntityMapper<T, T_DTO> mapper) {
        this.mapper = mapper;
    }

    @Override
    public Collection<T> mapToEntities(final Collection<T_DTO> collection) {
        if (collection == null) return null;
        return collection.stream().map(mapper::toEntity).collect(Collectors.toList());
    }

    @Override
    public Collection<T_DTO> mapDTOs(final Collection<T> collection) {
        if (collection == null) return null;
        return collection.stream().map(mapper::toDTO).collect(Collectors.toList());
    }
}
