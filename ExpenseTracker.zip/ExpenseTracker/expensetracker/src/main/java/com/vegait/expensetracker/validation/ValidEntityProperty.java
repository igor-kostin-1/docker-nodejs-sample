package com.vegait.expensetracker.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EntityPropertyValidator.class)
public @interface ValidEntityProperty {

    Class<?> clazz();

    String message() default "Must be valid entity property";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

}