package com.vegait.expensetracker.model.filter;

import com.querydsl.core.types.dsl.BooleanExpression;
import com.vegait.expensetracker.model.QExpense;
import com.vegait.expensetracker.model.QIncome;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.springframework.util.StringUtils;

import java.time.ZonedDateTime;

@AllArgsConstructor
@Builder
public class TransactionFilter {
    private String name;
    private String description;
    private Double amountGT;
    private Double amountLT;

    private ZonedDateTime createdBefore;
    private ZonedDateTime createdAfter;

    private Long groupId;


    public BooleanExpression buildIncomeFilter(Long userId) {
        QIncome root = QIncome.income;

        BooleanExpression expression = root.user.id.eq(userId);

        if (StringUtils.hasText(name)) {
            expression = expression.and(root.name.contains(name));
        }

        if (StringUtils.hasText(description)) {
            expression = expression.and(root.description.contains(description));
        }

        if (amountGT != null) {
            expression = expression.and(root.amount.gt(amountGT));
        }

        if (amountLT != null) {
            expression = expression.and(root.amount.lt(amountLT));
        }

        if (createdBefore != null) {
            expression = expression.and(root.created.before(createdBefore));
        }

        if (createdAfter != null) {
            expression = expression.and(root.created.after(createdAfter));
        }

        if (groupId != null) {
            expression = expression.and(root.group.id.eq(groupId));
        }

        return expression;
    }

    public BooleanExpression buildExpenseFilter(Long userId) {
        QExpense root = QExpense.expense;

        BooleanExpression expression = root.user.id.eq(userId);

        if (StringUtils.hasText(name)) {
            expression = expression.and(root.name.contains(name));
        }

        if (StringUtils.hasText(description)) {
            expression = expression.and(root.description.contains(description));
        }

        if (amountGT != null) {
            expression = expression.and(root.amount.goe(amountGT));
        }

        if (amountLT != null) {
            expression = expression.and(root.amount.loe(amountLT));
        }

        if (createdBefore != null) {
            expression = expression.and(root.created.before(createdBefore));
        }

        if (createdAfter != null) {
            expression = expression.and(root.created.after(createdAfter));
        }

        if (groupId != null) {
            expression = expression.and(root.group.id.eq(groupId));
        }

        return expression;
    }
}
