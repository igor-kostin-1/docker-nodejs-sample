package com.vegait.expensetracker.controller;

import com.vegait.expensetracker.controller.common.crud.CRUDControllerHandlerImpl;
import com.vegait.expensetracker.controller.common.crud.ICRUDControllerHandler;
import com.vegait.expensetracker.controller.common.crud.ILoggable;
import com.vegait.expensetracker.controller.common.crud.LoggingAbsCRUDController;
import com.vegait.expensetracker.dto.IncomeDTO;
import com.vegait.expensetracker.dto.projection.TransactionProjection;
import com.vegait.expensetracker.mapper.common.CollectionMapperFactory;
import com.vegait.expensetracker.mapper.common.ICollectionMapper;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.service.common.TransactionService;
import com.vegait.expensetracker.validation.ValidEntityProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.ZonedDateTime;
import java.util.Objects;

@RestController
@RequestMapping("/income")
public class IncomeController implements ILoggable {
    @Getter
    private final String singular = "Income";
    @Getter
    private final String plural = "Incomes";

    protected final TransactionService<Income, Long, Long, IncomeGroup, Long> service;
    protected final IEntityMapper<Income, IncomeDTO> mapper;
    protected final ICollectionMapper<Income, IncomeDTO> collectionMapper;

    protected final ICRUDControllerHandler<IncomeDTO, Long> crudHandler;

    public IncomeController(final TransactionService<Income, Long, Long, IncomeGroup, Long> service,
                            final IEntityMapper<Income, IncomeDTO> mapper) {
        this.service = service;
        this.mapper = mapper;
        this.collectionMapper = CollectionMapperFactory.create(mapper);
        this.crudHandler = new LoggingAbsCRUDController<>(new CRUDControllerHandlerImpl<>(service, mapper), "Incomes", "Income");
    }

    // GET - getAll, getOne ----------------------------------------------------------------------------
    // Get all entity

    /**
     * Retrieves all entities.
     *
     * @return A ResponseEntity containing a collection of DTOs representing the entities.
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public Page<TransactionProjection> findAll(
             @RequestParam(defaultValue = "0") @Valid @Min(0) int page,
            @RequestParam(defaultValue = "10") @Valid @Max(100) int size,
            @RequestParam(defaultValue = "created") @Valid @ValidEntityProperty(clazz= Income.class) String sortBy,
            @RequestParam(defaultValue = "DESC") String sortOrder,
            @RequestParam(required = false, defaultValue = "") String name,
            @RequestParam(required = false, defaultValue = "") String description,
            @RequestParam(required = false, defaultValue = "") Double amountGT,
            @RequestParam(required = false, defaultValue = "") Double amountLT,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdBefore,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdAfter,
            @RequestParam(required = false, defaultValue = "") Long groupId

    ) {

        Sort.Direction _sortOrder = Objects.equals(sortOrder.toUpperCase(), "DESC") ? Sort.Direction.DESC : Sort.Direction.ASC;
        TransactionFilter filter = new TransactionFilter(name, description, amountGT, amountLT, createdBefore, createdAfter, groupId);

        Pageable paging = PageRequest.of(page, size, _sortOrder, sortBy);


        return service.findAll(paging, filter);
    }

    // Get one entity

    /**
     * Retrieves an entity by its identifier.
     *
     * @param id The identifier of the entity to retrieve.
     * @return A ResponseEntity containing the DTO representing the entity, if found.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<IncomeDTO> findById(@PathVariable("id") Long id) {
        return crudHandler.findById(id);
    }

    // POST - create(one), --------------------------------------------------------------------------------
    // Create one entity

    /**
     * Creates a new entity.
     *
     * @param newProvideEntity The DTO representing the new entity to create.
     * @return A ResponseEntity containing the DTO representing the created entity.
     */
    @RequestMapping(path = "", method = RequestMethod.POST)
    public ResponseEntity<IncomeDTO> save(@Valid @RequestBody IncomeDTO newProvideEntity) {
        return crudHandler.save(newProvideEntity);
    }


    // PUT - update(one), ----------------------------------------------------------------------------------------------
    // Update one entity

    /**
     * Updates an existing entity.
     *
     * @param dto The DTO containing the updated information for the entity.
     * @return A ResponseEntity containing the DTO representing the updated entity.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.PUT)
    public ResponseEntity<IncomeDTO> update(@PathVariable("id") Long id, @Valid @RequestBody IncomeDTO dto) {
        return crudHandler.update(id, dto);
    }


    // DELETE - delete(one) -------------------------------------------------------------------------------
    // Delete one entity

    /**
     * Deletes an entity by its identifier.
     *
     * @param id The identifier of the entity to delete.
     * @return A ResponseEntity indicating the success or failure of the deletion operation.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        return crudHandler.delete(id);
    }

     @GetMapping(path = "/sum")
    public Double sum(
            @RequestParam(required = false, defaultValue = "") String name,
            @RequestParam(required = false, defaultValue = "") String description,
            @RequestParam(required = false, defaultValue = "") Double amountGT,
            @RequestParam(required = false, defaultValue = "") Double amountLT,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdBefore,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdAfter,
            @RequestParam(required = false, defaultValue = "") Long groupId) {
        TransactionFilter filter = new TransactionFilter(name, description, amountGT, amountLT, createdBefore, createdAfter, groupId);


        return this.service.sum(filter);
    }
}
