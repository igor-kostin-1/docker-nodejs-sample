package com.vegait.expensetracker.error;

public class ValidationRespone {
    private static class ConstrainsViolation{
        String message;
        String property;
        String rootClass;

    }
    private String failedForEntity;
//    private List<>
}
