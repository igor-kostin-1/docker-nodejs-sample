package com.vegait.expensetracker.mapper.common;

import java.util.Collection;

/**
 * ICollectionMapper is an interface for mapping collections of entities and their corresponding DTOs (Data Transfer Objects).
 *
 * @param <T>     The type of the entity.
 * @param <T_DTO> The type of the DTO representing the entity.
 */
public interface ICollectionMapper<T, T_DTO> {

    /**
     * Maps a collection of DTOs to a collection of entities.
     *
     * @param collection The collection of DTOs to be mapped to entities.
     * @return The collection of entities mapped from the DTOs.
     */
    Collection<T> mapToEntities(Collection<T_DTO> collection);

    /**
     * Maps a collection of entities to a collection of DTOs.
     *
     * @param collection The collection of entities to be mapped to DTOs.
     * @return The collection of DTOs mapped from the entities.
     */
    Collection<T_DTO> mapDTOs(Collection<T> collection);
}
