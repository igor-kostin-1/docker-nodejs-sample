package com.vegait.expensetracker.mapper.common;

import com.vegait.expensetracker.model.common.IEntityObject;

/**
 * UpdateIEntityMapper is a specialized IEntityMapper implementation used for updating existing entities.
 * It ensures that the identifier of the entity is not changed during the update process.
 *
 * @param <T>     The type of the entity.
 * @param <T_DTO> The type of the DTO representing the entity.
 * @param <T_ID>  The type of the entity's identifier.
 */
public class UpdateIEntityMapper<
        T extends IEntityObject<T_ID>,
        T_DTO extends IEntityObject<T_ID>,
        T_ID
        > implements IEntityMapper<T, T_DTO> {

    private final IEntityMapper<T, T_DTO> mapper;

    public UpdateIEntityMapper(IEntityMapper<T, T_DTO> mapper) {
        this.mapper = mapper;
    }

    /**
     * Maps a DTO to an entity, ensuring that the entity's identifier is not changed.
     *
     * @param tDto The DTO to be mapped to an entity.
     * @return The entity mapped from the DTO with its identifier preserved.
     */
    @Override
    public T toEntity(final T_DTO tDto) {
        T_ID id = tDto.getId();
        T e = this.mapper.toEntity(tDto);
        e.setId(id); // making sure that ID is not changed
        return e;
    }

    @Override
    public T_DTO toDTO(final T entity) {
        return this.mapper.toDTO(entity);
    }

    /**
     * Updates an entity with the values from a DTO using the provided entity mapper.
     * It ensures that the identifier of the entity is not changed during the update process.
     *
     * @param entity The entity to be updated.
     * @param dto    The DTO containing the updated values.
     * @return The updated entity.
     */
    @Override
    public T updateEntity(T entity, T_DTO dto) {
        T_ID id = entity.getId();
        T e = this.mapper.updateEntity(entity, dto);
        e.setId(id); // making sure that ID is not changed
        return e;
    }
}
