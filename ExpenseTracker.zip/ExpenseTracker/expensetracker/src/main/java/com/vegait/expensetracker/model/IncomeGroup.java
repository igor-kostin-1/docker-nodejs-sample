package com.vegait.expensetracker.model;

import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.model.common.IUserOwned;
import com.vegait.expensetracker.security.model.User;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "income_group")
public class IncomeGroup implements IUserOwned, IEntityObject<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Income Group: Invalid Name: Empty name")
    @NotNull(message = "Income Group: Invalid Name: Name is NULL")
    private String name;

    private String description;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @OneToMany(mappedBy = "group")
    private Set<Income> incomes;


    public IncomeGroup(Long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }
}
