package com.vegait.expensetracker.controller;

import com.vegait.expensetracker.dto.UserBalanceDTO;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.model.Reminder;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.service.DataExportService;
import com.vegait.expensetracker.service.SchedulerReportService;
import com.vegait.expensetracker.service.common.TransactionService;
import com.vegait.expensetracker.task.TaskFrequency;
import com.vegait.expensetracker.utility.mail.MailService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.ZonedDateTime;

@Slf4j
@RestController
@RequestMapping("/user")
public class UserController {
    private final TransactionService<Income, Long, Long, IncomeGroup, Long> incomeService;
    private final TransactionService<Expense, Long, Long, ExpenseGroup, Long> expenseService;
    private final SchedulerReportService srs;

    public UserController(TransactionService<Income, Long, Long, IncomeGroup, Long> incomeService, TransactionService<Expense, Long, Long, ExpenseGroup, Long> expenseService, SchedulerReportService srs) {
        this.incomeService = incomeService;
        this.expenseService = expenseService;
        this.srs = srs;
    }

    @RequestMapping("/stats/transaction/sum")
    public UserBalanceDTO sum(
            @RequestParam(required = false, defaultValue = "") String name,
            @RequestParam(required = false, defaultValue = "") String description,
            @RequestParam(required = false, defaultValue = "") Double amountGT,
            @RequestParam(required = false, defaultValue = "") Double amountLT,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdBefore,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdAfter,
            @RequestParam(required = false, defaultValue = "") Long groupId) {
        TransactionFilter filter = new TransactionFilter(name, description, amountGT, amountLT, createdBefore, createdAfter, groupId);
        Double income = this.incomeService.sum(filter);
        Double expense = this.expenseService.sum(filter);

        return new UserBalanceDTO(income - expense, income, expense);
    }

    @RequestMapping("/subscription/subscribe")
    public String subscribeOnReport(
            @RequestParam(required = false, defaultValue = "MINUTE") TaskFrequency onFrequency,
            @RequestParam(required = false, defaultValue = "1") @Valid @Min(1) @Max(31) int onDay,
            @RequestParam(required = false, defaultValue = "1") @Valid @Min(1) @Max(7) int onDayOfWeek,
            @RequestParam(required = false, defaultValue = "10") @Valid @Min(0) @Max(23) int onHour
    ) {
        // If frequency is set on TaskFrequency.Month then we use onDay if provided, and onHour if provided
        // If frequency is set on TaskFrequency.Week then we use onDayOfWeek if provided, and onHour if provided
        // If frequency is set on TaskFrequency.Day then we use onHour if provided

        log.info("User {} has successfully created new scheduled subscription", SecurityContextHolder.getContext().getAuthentication().getName());
        srs.updateReminder(Reminder.builder().frequency(onFrequency).onDay(onDay).onDayOfWeek(onDayOfWeek).onHour(onHour).build());
        return "Successful updated subscription";
    }
    @RequestMapping("/subscription/unsubscribe")
    public String unSubscribeOnReport(){
        log.info("User {} has successfully unsubscribed from scheduled subscription", SecurityContextHolder.getContext().getAuthentication().getName());
        return srs.unsubscribe();
    }
}
