package com.vegait.expensetracker.task;

import com.itextpdf.text.DocumentException;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.service.DataExportService;
import com.vegait.expensetracker.utility.mail.MailService;
import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;

import java.io.FileNotFoundException;
import java.util.Date;
import java.util.UUID;

@Slf4j
public class RunnableTask implements Runnable {
    private String message;

    private UUID uuid = UUID.randomUUID();

    private final DataExportService dataExportService;

    private final MailService mailService;

    private Long user_id;
    private String email;

    public RunnableTask(String message, DataExportService dataExportService, MailService mailService, String email, Long user_id) {
        this.user_id = user_id;
        this.email = email;
        this.message = message;
        this.dataExportService = dataExportService;
        this.mailService = mailService;
    }

    @Override
    public void run() {

        byte[] s = new byte[0];
        try {
            s = this.dataExportService.getTotalReport(new TransactionFilter(null, null, null, null, null, null, null), user_id);
        } catch (DocumentException e) {
           log.error(this.getMessage() + " Causes error: " + e.getMessage(), e);
        } catch (FileNotFoundException e) {
            log.error(this.getMessage() + " Causes error: " + e.getMessage(), e);
        }

        try {
            mailService.compose()
                    .to(email)
                    .withSubject("User transaction report")
                    .withTitle("Transaction report")
                    .withText("Your transaction report from all of your incomes and expenses.")
                    .withAttachment(s, "UserTransactionReport.pdf")
                    .send();
        } catch (MessagingException ex) {
            log.error(this.getMessage() + " Causes error: " + ex.getMessage(), ex);
        }

        log.info(new Date() + " Runnable Task with id: '" + this.uuid + "'  " + message
                + " on thread " + Thread.currentThread().getName());
    }

    public String getMessage() {
        return " - " + new Date() + " Runnable Task with id: '" + this.uuid + "'  " + message
                + " on thread " + Thread.currentThread().getName();
    }

}