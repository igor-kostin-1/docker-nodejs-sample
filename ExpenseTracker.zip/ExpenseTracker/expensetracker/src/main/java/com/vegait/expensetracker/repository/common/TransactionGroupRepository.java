package com.vegait.expensetracker.repository.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Collection;
import java.util.Optional;

/**
 * TransactionGroupRepository is a generic repository interface for managing transaction groups.
 * It extends JpaRepository to inherit basic CRUD operations from Spring Data JPA.
 *
 * @param <T>         The type of the entity managed by the repository.
 * @param <T_ID>      The type of the entity's identifier.
 * @param <T_USER_ID> The type of the user identifier associated with the entity.
 */
@NoRepositoryBean
public interface TransactionGroupRepository<T, T_ID, T_USER_ID> extends JpaRepository<T, T_ID> {

    /**
     * Finds all transaction groups associated with a specific user.
     *
     * @param user_id The identifier of the user.
     * @return A collection of transaction groups associated with the user.
     */
    Collection<T> findByUserId(T_USER_ID user_id);

    /**
     * Finds the first transaction group with a specific identifier associated with a specific user.
     *
     * @param id      The identifier of the transaction group.
     * @param user_id The identifier of the user.
     * @return An Optional containing the first transaction group found with the given identifier associated with the user.
     */
    Optional<T> findFirstByIdAndUserId(T_ID id, T_USER_ID user_id);
}
