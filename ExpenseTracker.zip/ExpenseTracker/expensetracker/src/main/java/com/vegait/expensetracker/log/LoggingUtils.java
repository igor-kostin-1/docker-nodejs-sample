package com.vegait.expensetracker.log;

import com.vegait.expensetracker.controller.common.crud.ILoggable;
import com.vegait.expensetracker.model.common.IEntityObject;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.JoinPoint;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerMapping;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LoggingUtils {

    protected Authentication auth;
    protected final HttpServletRequest request;

    public LoggingUtils(HttpServletRequest request) {
        this.request = request;
        this.auth = null;
    }

    protected String entitySingular(JoinPoint jp) {
        try {
            return ((ILoggable) jp.getTarget()).getSingular();
        } catch (Exception e) {
            return ("Singular (" + jp.getTarget().getClass().getSimpleName() + ")");
        }
    }

    protected String entityPlural(JoinPoint jp) {
        try {
            return ((ILoggable) jp.getTarget()).getPlural();
        } catch (Exception e) {
            return ("Plural (" + jp.getTarget().getClass().getSimpleName() + ")");
        }
    }

    protected String pathVariableID(JoinPoint jp) {
        String id = "id";
        return "[" + id + "]";
    }

    protected String username() {
        this.auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getName();
    }

    protected String filter() {
        String queryParams = this.request.getQueryString();
        return StringUtils.hasText(queryParams) ? ", with query params: [" + queryParams + "]" : "";
    }

    protected String getBody() throws IOException {
        return request.getReader().lines()
                .reduce("", (accumulator, actual) -> accumulator + actual);
    }

    protected String getId() {
        return request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE).toString();
    }

    protected String dto(JoinPoint jp) {
        List<String> dtos = new ArrayList<String>();
        Arrays.stream(jp.getArgs()).iterator().forEachRemaining((i) ->
                {
                    if (i instanceof IEntityObject) {
                        dtos.add(i.toString());
                    }
                }
        );

        return dtos.toString();
    }

    protected Object stats(long l) {
        return " stats/ time: " + l + "ms ";
    }
}
