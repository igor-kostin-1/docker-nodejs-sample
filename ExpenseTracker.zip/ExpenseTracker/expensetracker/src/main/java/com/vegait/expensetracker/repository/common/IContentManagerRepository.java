package com.vegait.expensetracker.repository.common;

import com.vegait.expensetracker.model.blog.StrapiBlogResponse;
import com.vegait.expensetracker.model.blog.StrapiSingleBlogResponse;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface IContentManagerRepository {
    StrapiBlogResponse blogs(Pageable pageable);

    StrapiSingleBlogResponse getById(int id);
}
