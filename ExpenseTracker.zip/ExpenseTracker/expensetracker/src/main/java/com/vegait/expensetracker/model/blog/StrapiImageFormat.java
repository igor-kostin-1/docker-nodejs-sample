package com.vegait.expensetracker.model.blog;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StrapiImageFormat {
    private String name;
    private String hash;
    private String ext;
    private String mime;
    private int width;
    private int height;
    private double size;
    private String url;
}