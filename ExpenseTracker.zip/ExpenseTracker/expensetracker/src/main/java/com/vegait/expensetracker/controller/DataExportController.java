package com.vegait.expensetracker.controller;

import com.itextpdf.text.DocumentException;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.service.DataExportService;
import com.vegait.expensetracker.service.common.TransactionService;
import com.vegait.expensetracker.utility.mail.MailService;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileNotFoundException;
import java.time.YearMonth;
import java.time.ZonedDateTime;

/**
 * Controller class for exporting transaction data.
 */
@RestController
@RequestMapping("/data/export")
public class DataExportController {

    private final DataExportService dataExportService;

    public DataExportController( DataExportService dataExportService) {
        this.dataExportService = dataExportService;
    }

    /**
     * Generates a PDF report for all transactions based on the provided filters.
     *
     * @param groupId The ID of the group to filter transactions (optional).
     * @return Byte array representing the generated PDF.
     * @throws DocumentException     If an error occurs during PDF generation.
     * @throws FileNotFoundException If the PDF file is not found.
     */
    @RequestMapping(value = "/transactions", produces = "application/pdf")
    public byte[] pdf(
//            @RequestParam(required = false, defaultValue = "") String name,
//            @RequestParam(required = false, defaultValue = "") String description,
//            @RequestParam(required = false, defaultValue = "") Double amountGT,
//            @RequestParam(required = false, defaultValue = "") Double amountLT,
//            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdBefore,
//            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdAfter,
//            @RequestParam(required = false, defaultValue = "") Long groupId
    ) throws DocumentException, FileNotFoundException, MessagingException {


        TransactionFilter filter = new TransactionFilter(null, null, null, null, null, null, null);


        byte[] s = this.dataExportService.getTotalReport(filter);

        return s;
    }

    /**
     * Generates a PDF report for transactions in the specified month and optional group.
     *
     * @param month   The month (1-12) for which to generate the report.
     * @param groupId The ID of the group to filter transactions (optional).
     * @return Byte array representing the generated PDF.
     * @throws DocumentException     If an error occurs during PDF generation.
     * @throws FileNotFoundException If the PDF file is not found.
     */
    @RequestMapping(value = "/transactions/{month}", produces = "application/pdf")
    public byte[] monthly(
            @PathVariable(name = "month") @Valid @Min(1) @Max(12) int month,
            @RequestParam(required = false, defaultValue = "") Long groupId) throws DocumentException, FileNotFoundException {

        ZonedDateTime z = ZonedDateTime.now().withMonth(month);

        YearMonth yearMonthObject = YearMonth.of(z.getYear(), z.getMonth());

        ZonedDateTime createdAfter = ZonedDateTime.now().withMonth(month).withDayOfMonth(1).withHour(0).withHour(0).withMinute(0).withSecond(0).withNano(0);
        ZonedDateTime createdBefore = ZonedDateTime.now().withMonth(month).withDayOfMonth(yearMonthObject.lengthOfMonth()).withHour(23).withMinute(59).withSecond(59).withNano(999999999);

        TransactionFilter filter = new TransactionFilter(null, null, null, null, createdBefore, createdAfter, groupId);

        return this.dataExportService.getMonthlyReport(filter, z);
    }
}
