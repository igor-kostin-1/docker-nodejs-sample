package com.vegait.expensetracker.service;

import com.vegait.expensetracker.model.blog.StrapiBlogResponse;
import com.vegait.expensetracker.model.blog.StrapiSingleBlogResponse;
import com.vegait.expensetracker.repository.common.IContentManagerRepository;
import com.vegait.expensetracker.service.common.IContentManagerService;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class StrapiContentManagerService implements IContentManagerService {

    private  final IContentManagerRepository repository;

    public StrapiContentManagerService(IContentManagerRepository repository) {
        this.repository = repository;
    }

    @Override
    public StrapiBlogResponse getAll(Pageable pageable) {
        return this.repository.blogs(pageable);
    }

    @Override
    public StrapiSingleBlogResponse getById(int id) {
        return this.repository.getById(id);
    }
}
