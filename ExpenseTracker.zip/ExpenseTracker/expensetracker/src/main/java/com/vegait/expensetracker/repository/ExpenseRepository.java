package com.vegait.expensetracker.repository;

import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.QExpense;
import com.vegait.expensetracker.repository.common.TransactionRepository;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Repository;

@Repository
public interface ExpenseRepository extends TransactionRepository<Expense, Long, Long> {

    @Override
    default Double sum(Predicate predicate, EntityManager entityManager) {
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);

        Double s = queryFactory
                .select(QExpense.expense.amount.sum())
                .from(QExpense.expense)
                .where(predicate)
                .fetchOne();

        return s==null? 0 :s;
    }
}
