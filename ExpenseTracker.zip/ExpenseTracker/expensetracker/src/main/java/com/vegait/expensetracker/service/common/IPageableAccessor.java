package com.vegait.expensetracker.service.common;


import com.vegait.expensetracker.model.filter.TransactionFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


public interface IPageableAccessor<T> {
    Page<T> findAll(Pageable pageable, TransactionFilter filter);
}
