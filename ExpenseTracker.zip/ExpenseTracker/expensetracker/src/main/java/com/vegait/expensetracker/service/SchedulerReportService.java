package com.vegait.expensetracker.service;

import com.vegait.expensetracker.error.MissingUser;
import com.vegait.expensetracker.model.Reminder;
import com.vegait.expensetracker.security.enums.ERole;
import com.vegait.expensetracker.security.model.Role;
import com.vegait.expensetracker.security.model.User;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.security.service.UserDetailsImpl;
import com.vegait.expensetracker.task.RunnableTask;
import com.vegait.expensetracker.utility.mail.MailService;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;

@Slf4j
@Service
public class SchedulerReportService {
    private final UserRepository userRepository;
    private final ThreadPoolTaskScheduler taskScheduler;
    private final DataExportService dataExportService;
    private final MailService mailService;

    public Map<String, ScheduledFuture<?>> usersReminders = new HashMap<>();

    public SchedulerReportService(UserRepository userRepository, ThreadPoolTaskScheduler taskScheduler, DataExportService dataExportService, MailService mailService) {
        this.userRepository = userRepository;
        this.taskScheduler = taskScheduler;
        this.dataExportService = dataExportService;
        this.mailService = mailService;
    }

    @PostConstruct
    @Async
    public void initialScheduledReportSetUp() {
        userRepository.findAll().stream()
                .filter(u -> u.getRoles().stream().map(Role::getName).toList().contains(ERole.ROLE_PREMIUM_USER)  && u.getReminder() !=null)
                .forEach(this::activateUserReminder);
    }

    public void activateUserReminder(User user) {

        if(user.getReminder()==null)
            return;

        if (this.usersReminders.containsKey(user.getId().toString()))
            this.usersReminders.get(user.getId().toString()).cancel(true);

        Runnable runnable = new RunnableTask("Running transaction email report sender  ", this.dataExportService, mailService, user.getEmail(), user.getId());
        CronTrigger trigger = getCronTrigger(user);

        log.info(new Date() + " New task started, "
                + "created on thread " + Thread.currentThread().getName());
        log.info("User "+user.getUsername()+" successfully subscribed with cron interval : " + trigger.getExpression());

        ScheduledFuture<?> f = taskScheduler.schedule(runnable, trigger);

        this.usersReminders.put(user.getId().toString(), f);
    }

    private static CronTrigger getCronTrigger(User user) {
        CronTrigger trigger;
        trigger = switch (user.getReminder().getFrequency()) {
            case MONTHLY ->
                    new CronTrigger("0 0 " + user.getReminder().getOnHour() + " " + user.getReminder().getOnDay() + " 1/1 *");
            case WEEKLY ->
                    new CronTrigger("0 0 " + user.getReminder().getOnHour() + " * * " + user.getReminder().getOnDayOfWeek());
            case DAILY -> new CronTrigger("0 0 " + user.getReminder().getOnHour() + " * * *");
            default -> new CronTrigger("1 * * * * ?");
        };
        return trigger;
    }

    public void updateReminder(Reminder reminder) {
        UserDetailsImpl<Long> details = (UserDetailsImpl<Long>) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = this.userRepository.findById(details.getId()).orElseThrow(
                () -> new MissingUser("There was error getting user data, please re login.")
        );

        user.setReminder(reminder);
        User _user = this.userRepository.save(user);
        this.activateUserReminder(_user);

    }

    public String unsubscribe() {
        UserDetailsImpl<Long> details = (UserDetailsImpl<Long>) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = this.userRepository.findById(details.getId()).orElseThrow(
                () -> new MissingUser("There was error getting user data, please re login.")
        );

        user.setReminder(null);
        User _user = this.userRepository.save(user);
        if (this.usersReminders.containsKey(_user.getId().toString()))
            this.usersReminders.get(_user.getId().toString()).cancel(true);


        return "You have successfully unsubscribed .";
    }
}
