package com.vegait.expensetracker.error;


public class EntityDontExit extends RuntimeException {

    public EntityDontExit(String s) {
        super(s);
    }
}
