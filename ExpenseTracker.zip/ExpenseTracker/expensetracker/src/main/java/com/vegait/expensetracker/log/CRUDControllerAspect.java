package com.vegait.expensetracker.log;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Aspect
@Component
public class CRUDControllerAspect extends LoggingUtils {


    public CRUDControllerAspect(HttpServletRequest request) {
        super(request);
    }

    @Around("execution(* com.vegait.expensetracker.controller..findAll(..))")
    public Object beforeFindAll(ProceedingJoinPoint pjp) throws Throwable {
         String user = username();
        String plural = this.entityPlural(pjp);
        String filter = filter();

        long startTime = System.currentTimeMillis();
        log.info("[GET] User '{}' request for ACCESS of '{}' {}", user, plural, filter);

        Object result = pjp.proceed();

        long endTime = System.currentTimeMillis();
        log.info("[GET] User '{}' GOT ACCESS for '{}' {} - {}", user, plural, filter, stats(endTime-startTime));

        return result;

    }

    @Around("execution(* com.vegait.expensetracker.controller..findById(..))")
    public Object beforeFindById(ProceedingJoinPoint pjp) throws Throwable {
        String user = username();
        String singular = this.entitySingular(pjp);
        String id = getId();

        long startTime = System.currentTimeMillis();
        log.info("[GET] User '{}' request for ACCESS '{}' with id: {}", user, singular, id);

        Object result = pjp.proceed();

        long endTime = System.currentTimeMillis();
        log.info("[GET] User '{}' GOT ACCESS for '{}' with id: {} - {}", user, singular, id, stats(endTime - startTime));

        return result;

    }

    @Around("execution(* com.vegait.expensetracker.controller..save(..))")
    public Object beforeSave(ProceedingJoinPoint pjp) throws Throwable {
        String user = username();
        String singular = this.entitySingular(pjp);
        String dto = dto(pjp);

        long startTime = System.currentTimeMillis();
        log.info("[POST] User '{}' sent request to CREATE new '{}' with values: {}",user, singular, dto);

        Object result =  pjp.proceed();

        long endTime = System.currentTimeMillis();
        log.info("[POST] User '{}' SUCCESSFULLY CREATE new '{}' with values: {} - {}",user, singular, dto, stats(endTime-startTime));

        return result;
    }

    @Around("execution(* com.vegait.expensetracker.controller..update(..))")
    public Object beforeUpdate(ProceedingJoinPoint pjp) throws Throwable {
        String user = username();
        String singular = this.entitySingular(pjp);
        String id = getId();
        String dto = dto(pjp);

        long startTime = System.currentTimeMillis();
        log.info("[PUI] User '{}' sent request for UPDATE '{}' with id: {} and set new values to: '{}'",
                user,
                singular,
                id,
                dto);

        Object result = pjp.proceed();

        long endTime = System.currentTimeMillis();
        log.info("[PUI] User '{}' SUCCESSFULLY UPDATE '{}' with id: {} and set new values to: '{}' - {}",
                user,
                singular,
                id,
                dto,
                stats(endTime - startTime));

        return result;

    }

    @Around("execution(* com.vegait.expensetracker.controller..delete(..))")
    public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {
        // start stopwatch
        long startTime = System.currentTimeMillis();
        log.info("[DELETE] User '{}' request for DELETE '{}' with id: {}", username(), this.entitySingular(pjp), this.getId());

        Object result = pjp.proceed();

        long endTime = System.currentTimeMillis();
        log.info("[DELETE] User '{}' SUCCESSFULLY DELETE '{}' with id: {} - {}", username(), this.entitySingular(pjp), this.getId(), this.stats(endTime - startTime));

        return result;
    }


    @Around("execution(* com.vegait.expensetracker.controller..sum(..))")
    public Object beforeSum(ProceedingJoinPoint pjp) throws Throwable {
        String user = username();
        String plural = this.entityPlural(pjp);
        String filter = filter();

        long startTime = System.currentTimeMillis();
        log.info("[GET] User '{}' request for SUM STATS for '{}' {}", user, plural, filter);

        Object result = pjp.proceed();

        long endTime = System.currentTimeMillis();
        log.info("[GET] User '{}' SUCCESSFULLY got SUM STATS for '{}' {} - {}", user, plural, filter, stats(endTime - startTime));

        return result;

    }


}

