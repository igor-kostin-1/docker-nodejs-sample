package com.vegait.expensetracker.repository;

import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.QIncome;
import com.vegait.expensetracker.repository.common.TransactionRepository;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Repository;

@Repository
public interface IncomeRepository extends TransactionRepository<Income, Long, Long> {
    @Override
    default Double sum(Predicate predicate, EntityManager entityManager) {
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);

        Double s = queryFactory
                .select(QIncome.income.amount.sum())
                .from(QIncome.income)
                .where(predicate)
                .fetchOne();

        return s == null ? 0 : s;
    }


}
