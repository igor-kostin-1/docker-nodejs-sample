package com.vegait.expensetracker.mapper;

import com.vegait.expensetracker.dto.ExpenseDTO;
import com.vegait.expensetracker.dto.ExpenseGroupDTO;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class ExpenseMapper implements IEntityMapper<Expense, ExpenseDTO> {
    IEntityMapper<ExpenseGroup, ExpenseGroupDTO> dtoMapper;

    public ExpenseMapper(IEntityMapper<ExpenseGroup, ExpenseGroupDTO> dtoMapper) {
        this.dtoMapper = dtoMapper;
    }

    @Override
    public Expense toEntity(ExpenseDTO dto) {
        if (dto == null) return null;
        return Expense.builder()
                .id(dto.getId())
                .name(dto.getName())
                .description(dto.getDescription())
                .amount(dto.getAmount())

                .group(dtoMapper.toEntity(dto.getGroup()))

                .build();
    }

    @Override
    public ExpenseDTO toDTO(Expense entity) {
        if (entity == null) return null;
        return ExpenseDTO.builder()
                .id(entity.getId())
                .name(entity.getName())
                .description(entity.getDescription())
                .amount(entity.getAmount())

                .group(dtoMapper.toDTO(entity.getGroup()))

                .build();
    }

    /**
     * Updates an existing Expense entity with the values from an ExpenseDTO.
     * If fields in the DTO are not null or empty, they are updated; otherwise, the original values are retained.
     *
     * @param entity The existing Income entity to be updated.
     * @param dto    The IncomeDTO containing the updated values.
     * @return The updated Income entity.
     */
    @Override
    public Expense updateEntity(Expense entity, ExpenseDTO dto) {
        return Expense.builder()
                .id(entity.getId())

                .name(StringUtils.hasText(dto.getName()) ? dto.getName() : entity.getName())
                .description(StringUtils.hasText(dto.getDescription()) ? dto.getDescription() : entity.getDescription())
                .amount(dto.getAmount() != null ? dto.getAmount() : entity.getAmount())

                .user(entity.getUser())
                .group(dto.getGroup() != null ? dtoMapper.toEntity(dto.getGroup()) : entity.getGroup())

                .created(entity.getCreated())
                .lastUpdate(entity.getLastUpdate())

                .build();
    }
}
