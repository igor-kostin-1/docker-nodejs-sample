package com.vegait.expensetracker.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BlogDTO {
    Long id;
    String title;
    String summary;
    String content;
    String imageUrl;
}
