package com.vegait.expensetracker.service.common;

import com.vegait.expensetracker.error.EntityDontExit;
import com.vegait.expensetracker.error.MissingUser;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.model.common.IUserOwned;
import com.vegait.expensetracker.repository.common.TransactionGroupRepository;
import com.vegait.expensetracker.security.model.User;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.security.service.UserDetailsImpl;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * TransactionGroupService is an abstract class representing a service layer for managing transaction groups.
 * It implements the ICRUDService interface for basic CRUD operations.
 *
 * @param <T>         The type of the transaction group managed by the service.
 * @param <T_ID>      The type of the transaction group's identifier.
 * @param <T_USER_ID> The type of the user identifier associated with the transaction group.
 */
@Slf4j
public abstract class TransactionGroupService<
        T extends IUserOwned & IEntityObject<T_ID>,
        T_ID,
        T_USER_ID> implements ICRUDService<T, T_ID, T_USER_ID> {

    protected final TransactionGroupRepository<T, T_ID, T_USER_ID> repository;
    protected final UserRepository userRepository;

    /**
     * Constructs a TransactionGroupService with the specified repository and userRepository.
     *
     * @param repository     The repository for managing transaction groups.
     * @param userRepository The repository for managing users.
     */
    public TransactionGroupService(final TransactionGroupRepository<T, T_ID, T_USER_ID> repository, UserRepository userRepository) {
        this.repository = repository;
        this.userRepository = userRepository;
    }

    /**
     * Retrieves all transaction groups associated with the currently authenticated user.
     *
     * @return A list containing all transaction groups associated with the user.
     */
    public List<T> findAll() {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        return (List<T>) repository.findByUserId(userDetails.getId());
    }

    /**
     * Retrieves a transaction group by its identifier associated with the currently authenticated user.
     *
     * @param id The identifier of the transaction group to retrieve.
     * @return The transaction group with the specified identifier associated with the user, or null if not found.
     */
    public T findById(T_ID id) {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        return this.repository.findFirstByIdAndUserId(id, userDetails.getId()).orElseThrow(
                () -> new EntityDontExit("No entity found with identifier" + id)
        );
    }

    /**
     * Saves a new transaction group associated with the currently authenticated user.
     *
     * @param entity The transaction group to be saved.
     * @return The saved transaction group.
     * @throws MissingUser If the user associated with the entity is missing.
     */
    public T save(final T entity) {
        // TODO: Mapper

        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();
        User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow(
                () -> new MissingUser("There was error getting user data, please re login.")
        );

        entity.setUser(user);

        return repository.save(entity);
    }

    /**
     * Updates an existing transaction group associated with the currently authenticated user.
     *
     * @param entity The transaction group to be updated.
     * @return The updated transaction group.
     */
    public T update(final T entity) {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        this.repository.findFirstByIdAndUserId(entity.getId(), userDetails.getId()).orElseThrow(
                () -> new EntityDontExit("Entity request to be updated does not exist, or user does not have permission to make changes to that entity")
        );

        return repository.save(entity);
    }

    /**
     * Deletes a transaction group by its identifier associated with the currently authenticated user.
     *
     * @param id The identifier of the transaction group to delete.
     * @throws EntityDontExit If the entity does not exist.
     */
    public void delete(final T_ID id) {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        this.repository.findFirstByIdAndUserId(id, userDetails.getId()).orElseThrow(
                () -> new EntityDontExit("Entity request to be deleted does not exist, or user does not have permission to make changes to that entity")
        );

        repository.deleteById(id);
    }
}