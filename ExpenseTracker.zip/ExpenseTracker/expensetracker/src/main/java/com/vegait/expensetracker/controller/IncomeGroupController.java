package com.vegait.expensetracker.controller;

import com.vegait.expensetracker.controller.common.crud.CRUDController;
import com.vegait.expensetracker.controller.common.crud.CRUDControllerHandlerImpl;
import com.vegait.expensetracker.controller.common.crud.LoggingAbsCRUDController;
import com.vegait.expensetracker.dto.IncomeGroupDTO;
import com.vegait.expensetracker.mapper.common.CollectionMapperFactory;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.service.common.ICRUDService;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/incomegroup")
public class IncomeGroupController extends CRUDController<IncomeGroup, IncomeGroupDTO, Long, Long> {

    @Getter private final String singular = "IncomeGroup";
    @Getter private final String plural = "IncomesGroups";

    public IncomeGroupController(final ICRUDService<IncomeGroup, Long, Long> service,
                                 final IEntityMapper<IncomeGroup, IncomeGroupDTO> mapper) {
        super(service, mapper, CollectionMapperFactory.create(mapper), new LoggingAbsCRUDController<>(
                new CRUDControllerHandlerImpl<>(service, mapper),
                "IncomeGroups",
                "IncomeGroup") {
        });
    }

    @GetMapping("/mock")
    public ResponseEntity<List<IncomeGroupDTO>> getMock() {
        return new ResponseEntity<>(
                Arrays.asList(
                        new IncomeGroupDTO(1L, "Salary", "Salary from job."),
                        new IncomeGroupDTO(2L, "Gift", "Gift."),
                        new IncomeGroupDTO(3L, "Rent", null)
                ), HttpStatus.OK);
    }
}
