package com.vegait.expensetracker.model;


import com.vegait.expensetracker.model.common.IAuditEntity;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.model.common.ITransaction;
import com.vegait.expensetracker.model.common.IUserOwned;
import com.vegait.expensetracker.security.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.ZonedDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
@Entity
@Table(name = "expense")
public class Expense implements IUserOwned, IEntityObject<Long>, ITransaction<ExpenseGroup>, IAuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Expense: Invalid Name: Empty name")
    @NotNull(message = "Expense: Invalid Name: Name is NULL")
    private String name;

    @Column(length = 3000)
    private String description;

    @NotNull(message = "Expense: Invalid Amount: Amount is NULL")
    @Min(value = 0, message = "Expense: Invalid Amount: Amount les than zero")
    private Double amount;

    private ZonedDateTime created;
    private ZonedDateTime lastUpdate;

    @NotNull(message = "Expense: Invalid Group: Group is NULL")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "group_id", nullable = false)
    private ExpenseGroup group;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false, updatable = false)
    private User user;

    // TODO: Delete before release, inflation data constructor
    public Expense(long l, String cozyAbode, String s, double v, ExpenseGroup rent, ZonedDateTime januaryDate) {
        this.name = cozyAbode;
        this.description = s;
        this.amount = v;
        this.group = rent;
        this.created = januaryDate;
        this.lastUpdate = januaryDate;
    }

    @PrePersist
    private void prePersist() {
        this.onPrePersist();
    }

    @PreUpdate
    private void preUpdate() {
        this.onPreUpdate();
    }
}
