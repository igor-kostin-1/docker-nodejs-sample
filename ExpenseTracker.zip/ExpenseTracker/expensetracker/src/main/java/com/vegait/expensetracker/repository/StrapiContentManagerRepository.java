package com.vegait.expensetracker.repository;

import com.vegait.expensetracker.model.blog.StrapiBlogResponse;
import com.vegait.expensetracker.model.blog.StrapiSingleBlogResponse;
import com.vegait.expensetracker.repository.common.IContentManagerRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;

@Repository
public class StrapiContentManagerRepository implements IContentManagerRepository {

    @Value("${strapi.url}")
    private String strapiUrl;

    @Value("${strapi.api-prefix}")
    private String strapiApiPrefix;

    @Value("${strapi.blogs}")
    private String blogsUri;

    @Value("${strapi.token}")
    private String token;

    private final WebClient webClient;

    public StrapiContentManagerRepository() {
        this.webClient = WebClient.builder()
                .build();
    }

    @Override
    public StrapiBlogResponse blogs(Pageable pageable) {
        return webClient.get()
                .uri(buildUri(this.blogsUri, pageable.getPageNumber(), pageable.getPageSize()))
                .header(HttpHeaders.AUTHORIZATION, "bearer " + this.token)
                .retrieve()
                .bodyToMono(StrapiBlogResponse.class)
                .block();
    }

    @Override
    public StrapiSingleBlogResponse getById(int id) {
         return webClient.get()
                .uri(this.strapiUrl+this.strapiApiPrefix+"/blogs/"+id+"?populate=*")
                .header(HttpHeaders.AUTHORIZATION, "bearer " + this.token)
                .retrieve()
                .bodyToMono(StrapiSingleBlogResponse.class)
                .block();
    }

    private String buildUri(String uri, int page, int size) {
        return this.strapiUrl + this.strapiApiPrefix + uri + "?populate=*" + "&pagination[page]=" + page + "&pagination[pageSize]=" + size;
    }


}
