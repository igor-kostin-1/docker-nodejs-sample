package com.vegait.expensetracker.dto;

import com.vegait.expensetracker.model.common.IEntityObject;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IncomeDTO implements IEntityObject<Long> {
    private Long id;

//    @NotBlank(message = "Income: Invalid Name: Empty name")
//    @NotNull(message = "Income: Invalid Name: Name is NULL")
    private String name;

    private String description;

//    @NotNull(message = "Income: Invalid Amount: Amount is NULL")
    @Min(value = 0, message ="Expense: Invalid Amount: Amount les than zero")
    private Double amount;

//    @NotNull(message = "Income: Invalid Group: Group is NULL")
    private IncomeGroupDTO group;
}
