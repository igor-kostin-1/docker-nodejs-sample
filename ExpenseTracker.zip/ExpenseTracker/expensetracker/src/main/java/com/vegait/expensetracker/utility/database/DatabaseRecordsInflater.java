package com.vegait.expensetracker.utility.database;

import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.model.common.IAuditEntity;
import com.vegait.expensetracker.service.common.TransactionGroupService;
import com.vegait.expensetracker.service.common.TransactionService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/data")
public class DatabaseRecordsInflater {
    private TransactionService<Income, Long, Long, IncomeGroup, Long> incomeService;
    private TransactionService<Expense, Long, Long, ExpenseGroup, Long> expenseService;

    private TransactionGroupService<IncomeGroup, Long, Long> incomeGroupService;
    private TransactionGroupService<ExpenseGroup, Long, Long> expenseGroupService;

    public DatabaseRecordsInflater(TransactionService<Income, Long, Long, IncomeGroup, Long> incomeService, TransactionService<Expense, Long, Long, ExpenseGroup, Long> expenseService, TransactionGroupService<IncomeGroup, Long, Long> incomeGroupService, TransactionGroupService<ExpenseGroup, Long, Long> expenseGroupService) {
        this.incomeService = incomeService;
        this.expenseService = expenseService;
        this.incomeGroupService = incomeGroupService;
        this.expenseGroupService = expenseGroupService;
    }


    @RequestMapping(value = "/inflate",method= RequestMethod.GET)
    public void inflate(){
        DisableOnPresist.disabled = true;
        this.DataGeneration();
        DisableOnPresist.disabled = false;
    }

    abstract class ListWrapper<T>{

        List<T> l = new ArrayList<>();

        public void add(T item){
            this.l.add(service(item));
        }

        public List<T> getList(){
            return l;
        }
        abstract T service(T Item);

    }
    private List<IncomeGroup> incomeGroups = new ArrayList<>();
    private List<ExpenseGroup> expenseGroups = new ArrayList<>();

    public void DataGeneration() {
        this.incomeGroups = this.generateIncomeGroups();
        this.expenseGroups = this.generateExpenseGroups();
        this.generateIncomes();
        this.generateExpense();
    }

    public List<ExpenseGroup> generateExpenseGroups() {
        List<ExpenseGroup> groups = new ArrayList<>();
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Rent").description("Expenses for rent").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Utilities").description("Expenses for utilities").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Food").description("Expenses for food").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Transportation").description("Expenses for transportation").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Entertainment").description("Expenses for entertainment").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Clothing").description("Expenses for clothing").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Healthcare").description("Expenses for healthcare").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Education").description("Expenses for education").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Travel").description("Expenses for travel").build()));
        groups.add(this.expenseGroupService.save(ExpenseGroup.builder().name("Insurance").description("Expenses for insurance").build()));

        return groups;
    }

    public List<IncomeGroup> generateIncomeGroups() {
        List<IncomeGroup> groups = new ArrayList<>();

        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Salary").description("Income from regular employment").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Freelancing").description("Income from freelancing work").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Consulting").description("Income from consulting services").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Gift").description("Income from gifts").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Rent").description("Income from rental properties").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Lottery").description("Income from lottery winnings").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Gambling").description("Income from gambling").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Interest").description("Income from interest on investments").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Dividends").description("Income from dividends on investments").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Royalties").description("Income from royalties on intellectual property").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Refunds").description("Income from refunds or reimbursements").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Bonuses").description("Income from bonuses").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Sales").description("Income from sales").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Commissions").description("Income from commissions").build()));
        groups.add(this.incomeGroupService.save(IncomeGroup.builder().name("Grants").description("Income from grants").build()));


        return groups;
    }

    public ExpenseGroup getOrCreateExpenseGroupByName(String groupName) {
        for (ExpenseGroup group : this.expenseGroups) {
            if (group.getName().equals(groupName)) {
                return group;
            }
        }

        // If the group doesn't exist, create a new one and add it to the list
        ExpenseGroup newGroup = ExpenseGroup.builder().name(groupName).build();
        newGroup.setName(groupName);
        this.expenseGroups.add(this.expenseGroupService.save(newGroup));

        return this.getOrCreateExpenseGroupByName(groupName);
    }

    public IncomeGroup getOrCreateIncomeGroupByName(String groupName) {
        for (IncomeGroup group : this.incomeGroups) {
            if (group.getName().equals(groupName)) {
                return group;
            }
        }

        // If the group doesn't exist, create a new one and add it to the list
        IncomeGroup newGroup = IncomeGroup.builder().name(groupName).build();
        newGroup.setName(groupName);
        this.incomeGroups.add(this.incomeGroupService.save(newGroup));

        return this.getOrCreateIncomeGroupByName(groupName);
    }

    public List<Income> generateIncomes() {
        ListWrapper<Income> incomes = new ListWrapper<>() {
            @Override
            Income service(Income item) {
                ZonedDateTime time = item.getCreated();
                ZonedDateTime time2 = time.withDayOfMonth(DatabaseRecordsInflater.generateRandomDay());
                ZonedDateTime time3 = time2.withHour(DatabaseRecordsInflater.generateRandomHour());
                item.setCreated(time3);
                return incomeService.save(item);
            }
        };

        // Generate incomes for January
        // Generate incomes for January
        ZonedDateTime januaryDate = ZonedDateTime.now().withMonth(1);
        incomes.add(new Income(1L, "January - Freelance Project A", "Income from freelance project A in January", 48000.00, getOrCreateIncomeGroupByName("Freelancing"), januaryDate));
        incomes.add(new Income(2L, "January - Investment Returns", "Returns from investment portfolio in January", 20000.00, getOrCreateIncomeGroupByName("Investment"), januaryDate));
        incomes.add(new Income(3L, "January - Consulting Services", "Income from consulting services in January", 60000.00, getOrCreateIncomeGroupByName("Consulting"), januaryDate));
        incomes.add(new Income(4L, "January - Lottery Win", "Won a lottery prize in January", 15000.00, getOrCreateIncomeGroupByName("Lottery"), januaryDate));
        incomes.add(new Income(5L, "January - Salary", "January salary from company", 260000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(6L, "January - Freelancing", "Income from freelancing work in January", 55000.00, getOrCreateIncomeGroupByName("Freelancing"), januaryDate));
        incomes.add(new Income(7L, "January - Investment Dividends", "Dividends from investment in January", 17000.00, getOrCreateIncomeGroupByName("Investment"), januaryDate));
        incomes.add(new Income(8L, "January - Consulting", "Income from consulting services in January", 72000.00, getOrCreateIncomeGroupByName("Consulting"), januaryDate));
        incomes.add(new Income(9L, "January - Rent", "Rental income for January", 105000.00, getOrCreateIncomeGroupByName("Rent"), januaryDate));
        incomes.add(new Income(10L, "January - Rent Income", "Rental income for January", 90000.00, getOrCreateIncomeGroupByName("Rent"), januaryDate));

        // Generate incomes for February
        ZonedDateTime februaryDate = ZonedDateTime.now().withMonth(2);
        incomes.add(new Income(1L, "February - Consulting Project", "Income from consulting project in February", 65000.00, getOrCreateIncomeGroupByName("Consulting"), februaryDate));
        incomes.add(new Income(2L, "February - Stock Dividends", "Dividends from stock investments in February", 25000.00, getOrCreateIncomeGroupByName("Investment"), februaryDate));
        incomes.add(new Income(3L, "February - Freelance Gig", "Income from freelance gig in February", 55000.00, getOrCreateIncomeGroupByName("Freelancing"), februaryDate));
        incomes.add(new Income(4L, "February - Gift Received", "Received a gift in February", 8000.00, getOrCreateIncomeGroupByName("Gift"), februaryDate));
        incomes.add(new Income(5L, "February - Rent Income", "Rental income for February", 95000.00, getOrCreateIncomeGroupByName("Rent"), februaryDate));
        incomes.add(new Income(71L, "Winter Art Sales", "Earnings from selling artwork in winter art exhibitions", 57000.00, getOrCreateIncomeGroupByName("Freelancing"), februaryDate));
        incomes.add(new Income(72L, "Stock Market Profits", "Profits from successful stock market investments", 30000.00, getOrCreateIncomeGroupByName("Investment"), februaryDate));
        incomes.add(new Income(73L, "Financial Consulting Services", "Income from providing financial consulting services", 74000.00, getOrCreateIncomeGroupByName("Consulting"), februaryDate));
        incomes.add(new Income(74L, "Valentine's Day Lottery Win", "Won a lottery prize on Valentine's Day", 25000.00, getOrCreateIncomeGroupByName("Lottery"), februaryDate));
        incomes.add(new Income(75L, "Annual Bonus Payout", "Annual bonus payout for employees", 370000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(76L, "Winter Freelance Projects", "Earnings from various freelance projects in winter", 69000.00, getOrCreateIncomeGroupByName("Freelancing"), februaryDate));
        incomes.add(new Income(77L, "Investment Dividends", "Dividends from investment portfolios", 26000.00, getOrCreateIncomeGroupByName("Investment"), februaryDate));
        incomes.add(new Income(78L, "Corporate Financial Planning", "Income from providing corporate financial planning services", 83000.00, getOrCreateIncomeGroupByName("Consulting"), februaryDate));
        incomes.add(new Income(79L, "Property Rental Income", "Rental income from properties", 140000.00, getOrCreateIncomeGroupByName("Rent"), februaryDate));
        incomes.add(new Income(80L, "Winter Royalty Payments", "Royalty payments from winter publications", 125000.00, getOrCreateIncomeGroupByName("Royalties"), februaryDate));

        // Generate incomes for March
        ZonedDateTime marchDate = ZonedDateTime.now().withMonth(3);
        incomes.add(new Income(31L, "Spring Art Exhibition", "Earnings from exhibiting artwork in a spring exhibition", 55000.00, getOrCreateIncomeGroupByName("Freelancing"), marchDate));
        incomes.add(new Income(32L, "Market Speculation Profits", "Profits from successful speculation in the market", 28000.00, getOrCreateIncomeGroupByName("Investment"), marchDate));
        incomes.add(new Income(33L, "Consulting Project Completion", "Income from completing a major consulting project", 70000.00, getOrCreateIncomeGroupByName("Consulting"), marchDate));
        incomes.add(new Income(34L, "Spring Equinox Lottery Win", "Won a lottery prize during the spring equinox", 22000.00, getOrCreateIncomeGroupByName("Lottery"), marchDate));
        incomes.add(new Income(35L, "Springtime Salary Increase", "Salary increase coinciding with the arrival of spring", 320000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(36L, "Spring Freelance Rush", "Earnings from high demand for freelance work in spring", 64000.00, getOrCreateIncomeGroupByName("Freelancing"), marchDate));
        incomes.add(new Income(37L, "Investment Dividends", "Dividends from various investment portfolios", 23000.00, getOrCreateIncomeGroupByName("Investment"), marchDate));
        incomes.add(new Income(38L, "Corporate Spring Training", "Income from conducting spring-themed corporate training", 80000.00, getOrCreateIncomeGroupByName("Consulting"), marchDate));
        incomes.add(new Income(39L, "Property Rental Income", "Rental income from various properties", 120000.00, getOrCreateIncomeGroupByName("Rent"), marchDate));
        incomes.add(new Income(40L, "Spring Royalty Payments", "Royalty payments from spring publications", 105000.00, getOrCreateIncomeGroupByName("Royalties"), marchDate));

        // Generate incomes for April
        ZonedDateTime aprilDate = ZonedDateTime.now().withMonth(4);
        incomes.add(new Income(41L, "Spring Art Festival Sales", "Earnings from selling artwork at a spring art festival", 58000.00, getOrCreateIncomeGroupByName("Freelancing"), aprilDate));
        incomes.add(new Income(42L, "Real Estate Investment Profits", "Profits from successful real estate investments", 29000.00, getOrCreateIncomeGroupByName("Investment"), aprilDate));
        incomes.add(new Income(43L, "Project Management Consulting", "Income from providing project management consulting services", 72000.00, getOrCreateIncomeGroupByName("Consulting"), aprilDate));
        incomes.add(new Income(44L, "April Fool's Lottery Win", "Won a lottery prize on April Fool's Day", 24000.00, getOrCreateIncomeGroupByName("Lottery"), aprilDate));
        incomes.add(new Income(45L, "Annual Performance Bonus", "Annual bonus for exceptional performance", 340000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(46L, "Spring Freelance Projects", "Earnings from various freelance projects in spring", 66000.00, getOrCreateIncomeGroupByName("Freelancing"), aprilDate));
        incomes.add(new Income(47L, "Investment Dividends", "Dividends from investment portfolios", 24000.00, getOrCreateIncomeGroupByName("Investment"), aprilDate));
        incomes.add(new Income(48L, "Corporate Strategy Consulting", "Income from providing corporate strategy consulting", 82000.00, getOrCreateIncomeGroupByName("Consulting"), aprilDate));
        incomes.add(new Income(49L, "Property Rental Income", "Rental income from properties", 125000.00, getOrCreateIncomeGroupByName("Rent"), aprilDate));
        incomes.add(new Income(50L, "Springtime Royalty Payments", "Royalty payments from spring publications", 110000.00, getOrCreateIncomeGroupByName("Royalties"), aprilDate));

        // Generate incomes for June
        ZonedDateTime juneDate = ZonedDateTime.now().withMonth(6);
        incomes.add(new Income(51L, "Summer Art Sales", "Earnings from selling artwork in summer art exhibitions", 60000.00, getOrCreateIncomeGroupByName("Freelancing"), juneDate));
        incomes.add(new Income(52L, "Stock Market Growth", "Profits from growth in the stock market", 31000.00, getOrCreateIncomeGroupByName("Investment"), juneDate));
        incomes.add(new Income(53L, "Strategic Consulting", "Income from providing strategic consulting services", 75000.00, getOrCreateIncomeGroupByName("Consulting"), juneDate));
        incomes.add(new Income(54L, "Summer Solstice Lottery Win", "Won a lottery prize on the summer solstice", 26000.00, getOrCreateIncomeGroupByName("Lottery"), juneDate));
        incomes.add(new Income(55L, "Mid-Year Salary Increase", "Mid-year salary increase", 360000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(56L, "Summer Freelance Projects", "Earnings from various freelance projects in summer", 68000.00, getOrCreateIncomeGroupByName("Freelancing"), juneDate));
        incomes.add(new Income(57L, "Investment Dividends", "Dividends from investment portfolios", 25000.00, getOrCreateIncomeGroupByName("Investment"), juneDate));
        incomes.add(new Income(58L, "Corporate Leadership Training", "Income from providing corporate leadership training", 85000.00, getOrCreateIncomeGroupByName("Consulting"), juneDate));
        incomes.add(new Income(59L, "Property Rental Income", "Rental income from properties", 130000.00, getOrCreateIncomeGroupByName("Rent"), juneDate));
        incomes.add(new Income(60L, "Summer Royalty Payments", "Royalty payments from summer publications", 115000.00, getOrCreateIncomeGroupByName("Royalties"), juneDate));

        // Generate incomes for July
        ZonedDateTime julyDate = ZonedDateTime.now().withMonth(7);
        incomes.add(new Income(61L, "Summer Art Exhibition Sales", "Earnings from selling artwork at summer exhibitions", 62000.00, getOrCreateIncomeGroupByName("Freelancing"), julyDate));
        incomes.add(new Income(62L, "Real Estate Investment Returns", "Returns from real estate investment portfolios", 32000.00, getOrCreateIncomeGroupByName("Investment"), julyDate));
        incomes.add(new Income(63L, "Leadership Consulting", "Income from providing leadership consulting services", 78000.00, getOrCreateIncomeGroupByName("Consulting"), julyDate));
        incomes.add(new Income(64L, "Summer Vacation Lottery Win", "Won a lottery prize during summer vacation", 28000.00, getOrCreateIncomeGroupByName("Lottery"), julyDate));
        incomes.add(new Income(65L, "Mid-Year Performance Bonus", "Mid-year performance bonus", 380000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(66L, "Summer Freelance Rush", "Earnings from high demand for freelance work in summer", 70000.00, getOrCreateIncomeGroupByName("Freelancing"), julyDate));
        incomes.add(new Income(67L, "Investment Dividends", "Dividends from investment portfolios", 27000.00, getOrCreateIncomeGroupByName("Investment"), julyDate));
        incomes.add(new Income(68L, "Corporate Team Building", "Income from providing corporate team building services", 90000.00, getOrCreateIncomeGroupByName("Consulting"), julyDate));
        incomes.add(new Income(69L, "Property Rental Income", "Rental income from properties", 135000.00, getOrCreateIncomeGroupByName("Rent"), julyDate));
        incomes.add(new Income(70L, "Summer Royalty Payments", "Royalty payments from summer publications", 120000.00, getOrCreateIncomeGroupByName("Royalties"), julyDate));

        // Generate incomes for August
        ZonedDateTime augustDate = ZonedDateTime.now().withMonth(8);
        incomes.add(new Income(1L, "August - Freelance Project", "Income from freelance project in August", 48000.00, getOrCreateIncomeGroupByName("Freelancing"), augustDate));
        incomes.add(new Income(2L, "August - Investment Returns", "Returns from investment portfolio in August", 20000.00, getOrCreateIncomeGroupByName("Investment"), augustDate));
        incomes.add(new Income(3L, "August - Consulting Services", "Income from consulting services in August", 60000.00, getOrCreateIncomeGroupByName("Consulting"), augustDate));
        incomes.add(new Income(4L, "August - Lottery Win", "Won a lottery prize in August", 15000.00, getOrCreateIncomeGroupByName("Lottery"), augustDate));
        incomes.add(new Income(5L, "August - Salary", "August salary from company", 260000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(6L, "August - Freelancing", "Income from freelancing work in August", 55000.00, getOrCreateIncomeGroupByName("Freelancing"), augustDate));
        incomes.add(new Income(7L, "August - Investment Dividends", "Dividends from investment in August", 17000.00, getOrCreateIncomeGroupByName("Investment"), augustDate));
        incomes.add(new Income(8L, "August - Consulting", "Income from consulting services in August", 72000.00, getOrCreateIncomeGroupByName("Consulting"), augustDate));
        incomes.add(new Income(9L, "August - Rent", "Rental income for August", 105000.00, getOrCreateIncomeGroupByName("Rent"), augustDate));
        incomes.add(new Income(10L, "August - Rent Income", "Rental income for August", 90000.00, getOrCreateIncomeGroupByName("Rent"), augustDate));

        // Generate incomes for September
        ZonedDateTime septemberDate = ZonedDateTime.now().withMonth(9);
        incomes.add(new Income(1L, "September - Freelance Project", "Income from freelance project in September", 48000.00, getOrCreateIncomeGroupByName("Freelancing"), septemberDate));
        incomes.add(new Income(2L, "September - Investment Returns", "Returns from investment portfolio in September", 20000.00, getOrCreateIncomeGroupByName("Investment"), septemberDate));
        incomes.add(new Income(3L, "September - Consulting Services", "Income from consulting services in September", 60000.00, getOrCreateIncomeGroupByName("Consulting"), septemberDate));
        incomes.add(new Income(4L, "September - Lottery Win", "Won a lottery prize in September", 15000.00, getOrCreateIncomeGroupByName("Lottery"), septemberDate));
        incomes.add(new Income(5L, "September - Salary", "September salary from company", 260000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(6L, "September - Freelancing", "Income from freelancing work in September", 55000.00, getOrCreateIncomeGroupByName("Freelancing"), septemberDate));
        incomes.add(new Income(7L, "September - Investment Dividends", "Dividends from investment in September", 17000.00, getOrCreateIncomeGroupByName("Investment"), septemberDate));
        incomes.add(new Income(8L, "September - Consulting", "Income from consulting services in September", 72000.00, getOrCreateIncomeGroupByName("Consulting"), septemberDate));
        incomes.add(new Income(9L, "September - Rent", "Rental income for September", 105000.00, getOrCreateIncomeGroupByName("Rent"), septemberDate));
        incomes.add(new Income(10L, "September - Rent Income", "Rental income for September", 90000.00, getOrCreateIncomeGroupByName("Rent"), septemberDate));

        // Generate incomes for October
        ZonedDateTime octoberDate = ZonedDateTime.now().withMonth(10);
        incomes.add(new Income(1L, "October - Freelance Project", "Income from freelance project in October", 48000.00, getOrCreateIncomeGroupByName("Freelancing"), octoberDate));
        incomes.add(new Income(2L, "October - Investment Returns", "Returns from investment portfolio in October", 20000.00, getOrCreateIncomeGroupByName("Investment"), octoberDate));
        incomes.add(new Income(3L, "October - Consulting Services", "Income from consulting services in October", 60000.00, getOrCreateIncomeGroupByName("Consulting"), octoberDate));
        incomes.add(new Income(4L, "October - Lottery Win", "Won a lottery prize in October", 15000.00, getOrCreateIncomeGroupByName("Lottery"), octoberDate));
        incomes.add(new Income(5L, "October - Salary", "October salary from company", 260000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(6L, "October - Freelancing", "Income from freelancing work in October", 55000.00, getOrCreateIncomeGroupByName("Freelancing"), octoberDate));
        incomes.add(new Income(7L, "October - Investment Dividends", "Dividends from investment in October", 17000.00, getOrCreateIncomeGroupByName("Investment"), octoberDate));
        incomes.add(new Income(8L, "October - Consulting", "Income from consulting services in October", 72000.00, getOrCreateIncomeGroupByName("Consulting"), octoberDate));
        incomes.add(new Income(9L, "October - Rent", "Rental income for October", 105000.00, getOrCreateIncomeGroupByName("Rent"), octoberDate));
        incomes.add(new Income(10L, "October - Rent Income", "Rental income for October", 90000.00, getOrCreateIncomeGroupByName("Rent"), octoberDate));

        // Generate incomes for November
        ZonedDateTime novemberDate = ZonedDateTime.now().withMonth(11);
        incomes.add(new Income(11L, "Art Commission", "Earnings from commissioned artwork", 52000.00, getOrCreateIncomeGroupByName("Freelancing"), novemberDate));
        incomes.add(new Income(12L, "Stock Market Profits", "Profits from successful stock trades", 25000.00, getOrCreateIncomeGroupByName("Investment"), novemberDate));
        incomes.add(new Income(13L, "Business Consulting", "Income from providing business consultancy services", 65000.00, getOrCreateIncomeGroupByName("Consulting"), novemberDate));
        incomes.add(new Income(14L, "Creative Contest Prize", "Won a prize in a creative contest", 18000.00, getOrCreateIncomeGroupByName("Lottery"), novemberDate));
        incomes.add(new Income(15L, "Year-End Bonus", "Year-end bonus for outstanding performance", 280000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(16L, "Freelance Writing", "Earnings from freelance writing assignments", 59000.00, getOrCreateIncomeGroupByName("Freelancing"), novemberDate));
        incomes.add(new Income(17L, "Investment Dividends", "Dividends from various investments", 19000.00, getOrCreateIncomeGroupByName("Investment"), novemberDate));
        incomes.add(new Income(18L, "Corporate Training", "Income from conducting corporate training sessions", 74000.00, getOrCreateIncomeGroupByName("Consulting"), novemberDate));
        incomes.add(new Income(19L, "Property Rent", "Rental income from property", 110000.00, getOrCreateIncomeGroupByName("Rent"), novemberDate));
        incomes.add(new Income(20L, "Royalty Payments", "Royalty payments from published work", 95000.00, getOrCreateIncomeGroupByName("Royalties"), novemberDate));

        // Generate incomes for December
        ZonedDateTime decemberDate = ZonedDateTime.now().withMonth(12);
        incomes.add(new Income(21L, "Holiday Art Sales", "Earnings from holiday-themed artwork sales", 54000.00, getOrCreateIncomeGroupByName("Freelancing"), decemberDate));
        incomes.add(new Income(22L, "Year-End Investment Gains", "Gains from year-end investment portfolio", 27000.00, getOrCreateIncomeGroupByName("Investment"), decemberDate));
        incomes.add(new Income(23L, "Year-End Consulting Bonanza", "Consulting income peak at year-end", 68000.00, getOrCreateIncomeGroupByName("Consulting"), decemberDate));
        incomes.add(new Income(24L, "Christmas Lottery Win", "Won a lottery prize during Christmas", 20000.00, getOrCreateIncomeGroupByName("Lottery"), decemberDate));
        incomes.add(new Income(25L, "Year-End Bonus", "Year-end bonus for excellent performance", 300000.00, getOrCreateIncomeGroupByName("Salary"), ZonedDateTime.now()));
        incomes.add(new Income(26L, "Festive Freelance Projects", "Earnings from festive-themed freelance projects", 62000.00, getOrCreateIncomeGroupByName("Freelancing"), decemberDate));
        incomes.add(new Income(27L, "Investment Dividends", "Dividends from investment portfolios", 21000.00, getOrCreateIncomeGroupByName("Investment"), decemberDate));
        incomes.add(new Income(28L, "Corporate Holiday Training", "Income from holiday-themed corporate training", 78000.00, getOrCreateIncomeGroupByName("Consulting"), decemberDate));
        incomes.add(new Income(29L, "Property Rent", "Rental income from properties", 115000.00, getOrCreateIncomeGroupByName("Rent"), decemberDate));
        incomes.add(new Income(30L, "Festive Royalty Payments", "Royalty payments from festive publications", 98000.00, getOrCreateIncomeGroupByName("Royalties"), decemberDate));

        return incomes.getList();
    }

    public List<Expense> generateExpense() {
        ListWrapper<Expense> expenses = new ListWrapper<>() {
            @Override
            Expense service(Expense item) {
                ZonedDateTime time = item.getCreated();
                ZonedDateTime time2 = time.withDayOfMonth(DatabaseRecordsInflater.generateRandomDay());
                ZonedDateTime time3 = time2.withHour(DatabaseRecordsInflater.generateRandomHour());
                item.setCreated(time3);
                return expenseService.save(item);
            }
        };
        // Generate expenses for January
        ZonedDateTime januaryDate = ZonedDateTime.now().withMonth(1);

        expenses.add(new Expense(11L, "Cozy Abode", "Monthly rent for a cozy apartment", 1200.00, getOrCreateExpenseGroupByName("Rent"), januaryDate));
        expenses.add(new Expense(12L, "Kitchen Delights", "Groceries for culinary adventures", 300.00, getOrCreateExpenseGroupByName("Food"), januaryDate));
        expenses.add(new Expense(13L, "Essential Services", "Utility bills for basic amenities", 150.00, getOrCreateExpenseGroupByName("Utilities"), januaryDate));
        expenses.add(new Expense(14L, "City Commute", "Transportation expenses for city travel", 100.00, getOrCreateExpenseGroupByName("Transportation"), januaryDate));
        expenses.add(new Expense(15L, "Leisurely Pursuits", "Expenses for leisure and entertainment", 50.00, getOrCreateExpenseGroupByName("Entertainment"), januaryDate));

        ZonedDateTime februaryDate = ZonedDateTime.now().withMonth(2);

        expenses.add(new Expense(11L, "Cozy Residence", "Monthly rent for a cozy apartment", 1350.00, getOrCreateExpenseGroupByName("Rent"), februaryDate));
        expenses.add(new Expense(12L, "Kitchen Adventures", "Groceries for a month of culinary experiments", 280.00, getOrCreateExpenseGroupByName("Food"), februaryDate));
        expenses.add(new Expense(13L, "Basic Amenities", "Monthly utility bills", 160.00, getOrCreateExpenseGroupByName("Utilities"), februaryDate));
        expenses.add(new Expense(14L, "City Commute", "Transportation expenses for the shortest month", 110.00, getOrCreateExpenseGroupByName("Transportation"), februaryDate));
        expenses.add(new Expense(15L, "Leisurely Pursuits", "Fun and entertainment expenses", 70.00, getOrCreateExpenseGroupByName("Entertainment"), februaryDate));


// Generate expenses for March
        ZonedDateTime marchDate = ZonedDateTime.now().withMonth(3);

        expenses.add(new Expense(16L, "Urban Living", "Monthly rent for a modern downtown apartment", 1400.00, getOrCreateExpenseGroupByName("Rent"), marchDate));
        expenses.add(new Expense(17L, "Culinary Delights", "Groceries for trying out new recipes", 270.00, getOrCreateExpenseGroupByName("Food"), marchDate));
        expenses.add(new Expense(18L, "Essential Services", "Utility bills to keep the lights on", 155.00, getOrCreateExpenseGroupByName("Utilities"), marchDate));
        expenses.add(new Expense(19L, "City Travel", "Getting around town expenses", 105.00, getOrCreateExpenseGroupByName("Transportation"), marchDate));
        expenses.add(new Expense(20L, "Urban Entertainment", "Enjoyment expenses for social outings", 65.00, getOrCreateExpenseGroupByName("Entertainment"), marchDate));

// Generate expenses for April
        ZonedDateTime aprilDate = ZonedDateTime.now().withMonth(4);

        expenses.add(new Expense(21L, "Spring Retreat", "Monthly rent for a countryside cottage", 1300.00, getOrCreateExpenseGroupByName("Rent"), aprilDate));
        expenses.add(new Expense(22L, "Fresh Harvest", "Groceries for farm-fresh ingredients", 250.00, getOrCreateExpenseGroupByName("Food"), aprilDate));
        expenses.add(new Expense(23L, "Modern Comforts", "Utility bills for a comfortable lifestyle", 140.00, getOrCreateExpenseGroupByName("Utilities"), aprilDate));
        expenses.add(new Expense(24L, "Nature Trails", "Transportation expenses for exploring outdoor trails", 100.00, getOrCreateExpenseGroupByName("Transportation"), aprilDate));
        expenses.add(new Expense(25L, "Cultural Events", "Expenses for attending cultural events", 70.00, getOrCreateExpenseGroupByName("Entertainment"), aprilDate));

        // Generate expenses for May
        ZonedDateTime mayDate = ZonedDateTime.now().withMonth(5);

        expenses.add(new Expense(16L, "Homely Haven", "Monthly rent for a homely abode", 1350.00, getOrCreateExpenseGroupByName("Rent"), mayDate));
        expenses.add(new Expense(17L, "Kitchen Treasures", "Fresh produce and kitchen essentials", 260.00, getOrCreateExpenseGroupByName("Food"), mayDate));
        expenses.add(new Expense(18L, "Essential Services", "Utility bills for essential services", 145.00, getOrCreateExpenseGroupByName("Utilities"), mayDate));
        expenses.add(new Expense(19L, "City Commute", "Transportation expenses for city travel", 95.00, getOrCreateExpenseGroupByName("Transportation"), mayDate));
        expenses.add(new Expense(20L, "Leisure Escapades", "Leisure and entertainment expenses", 60.00, getOrCreateExpenseGroupByName("Entertainment"), mayDate));

// Generate expenses for June
        ZonedDateTime juneDate = ZonedDateTime.now().withMonth(6);

        expenses.add(new Expense(21L, "Summer Retreat", "Monthly rent for a summer retreat", 1320.00, getOrCreateExpenseGroupByName("Rent"), juneDate));
        expenses.add(new Expense(22L, "Essential Utilities", "Utility bills for essential services", 145.00, getOrCreateExpenseGroupByName("Utilities"), juneDate));
        expenses.add(new Expense(23L, "Fresh Market Finds", "Fresh produce and groceries from the market", 270.00, getOrCreateExpenseGroupByName("Food"), juneDate));
        expenses.add(new Expense(24L, "Urban Transit", "Transportation expenses for urban transit", 120.00, getOrCreateExpenseGroupByName("Transportation"), juneDate));
        expenses.add(new Expense(25L, "Entertainment Splurge", "Splurging on entertainment", 80.00, getOrCreateExpenseGroupByName("Entertainment"), juneDate));
        expenses.add(new Expense(26L, "Fashion Flair", "Fashion and clothing expenses", 200.00, getOrCreateExpenseGroupByName("Clothing"), juneDate));
        expenses.add(new Expense(27L, "Health & Wellness", "Healthcare and wellness expenses", 150.00, getOrCreateExpenseGroupByName("Healthcare"), juneDate));
        expenses.add(new Expense(28L, "Learning Adventures", "Investing in educational adventures", 300.00, getOrCreateExpenseGroupByName("Education"), juneDate));
        expenses.add(new Expense(29L, "Travel Wanderlust", "Satisfying the wanderlust with travel", 500.00, getOrCreateExpenseGroupByName("Travel"), juneDate));
        expenses.add(new Expense(30L, "Risk Protection", "Insurance coverage for unforeseen risks", 100.00, getOrCreateExpenseGroupByName("Insurance"), juneDate));

        // Generate expenses for July
        ZonedDateTime julyDate = ZonedDateTime.now().withMonth(7);

        expenses.add(new Expense(1L, "July - Rent", "Rent for the month of July", 1280.00, getOrCreateExpenseGroupByName("Rent"), julyDate));
        expenses.add(new Expense(2L, "July - Utilities", "Utility bills for July", 150.00, getOrCreateExpenseGroupByName("Utilities"), julyDate));
        expenses.add(new Expense(3L, "July - Groceries", "Groceries purchased in July", 260.00, getOrCreateExpenseGroupByName("Food"), julyDate));
        expenses.add(new Expense(4L, "July - Transportation", "Transportation expenses for July", 110.00, getOrCreateExpenseGroupByName("Transportation"), julyDate));
        expenses.add(new Expense(5L, "July - Entertainment", "Entertainment expenses for July", 70.00, getOrCreateExpenseGroupByName("Entertainment"), julyDate));
        expenses.add(new Expense(6L, "July - Clothing", "Clothing expenses for July", 180.00, getOrCreateExpenseGroupByName("Clothing"), julyDate));
        expenses.add(new Expense(7L, "July - Healthcare", "Healthcare expenses for July", 120.00, getOrCreateExpenseGroupByName("Healthcare"), julyDate));
        expenses.add(new Expense(8L, "July - Education", "Education expenses for July", 300.00, getOrCreateExpenseGroupByName("Education"), julyDate));
        expenses.add(new Expense(9L, "July - Travel", "Travel expenses for July", 500.00, getOrCreateExpenseGroupByName("Travel"), julyDate));
        expenses.add(new Expense(10L, "July - Insurance", "Insurance expenses for July", 100.00, getOrCreateExpenseGroupByName("Insurance"), julyDate));

        // Generate expenses for August
        ZonedDateTime augustDate = ZonedDateTime.now().withMonth(8);

        expenses.add(new Expense(1L, "August - Rent", "Rent expenses for August", 1200.00, getOrCreateExpenseGroupByName("Rent"), augustDate));
        expenses.add(new Expense(2L, "August - Utilities", "Utilities expenses for August", 150.00, getOrCreateExpenseGroupByName("Utilities"), augustDate));
        expenses.add(new Expense(3L, "August - Food", "Food expenses for August", 200.00, getOrCreateExpenseGroupByName("Food"), augustDate));
        expenses.add(new Expense(4L, "August - Transportation", "Transportation expenses for August", 100.00, getOrCreateExpenseGroupByName("Transportation"), augustDate));
        expenses.add(new Expense(5L, "August - Entertainment", "Entertainment expenses for August", 50.00, getOrCreateExpenseGroupByName("Entertainment"), augustDate));
        expenses.add(new Expense(6L, "August - Clothing", "Clothing expenses for August", 80.00, getOrCreateExpenseGroupByName("Clothing"), augustDate));
        expenses.add(new Expense(7L, "August - Healthcare", "Healthcare expenses for August", 70.00, getOrCreateExpenseGroupByName("Healthcare"), augustDate));
        expenses.add(new Expense(8L, "August - Education", "Education expenses for August", 150.00, getOrCreateExpenseGroupByName("Education"), augustDate));
        expenses.add(new Expense(9L, "August - Travel", "Travel expenses for August", 300.00, getOrCreateExpenseGroupByName("Travel"), augustDate));
        expenses.add(new Expense(10L, "August - Insurance", "Insurance expenses for August", 100.00, getOrCreateExpenseGroupByName("Insurance"), augustDate));

        // Generate expenses for September
        ZonedDateTime septemberDate = ZonedDateTime.now().withMonth(9);

        expenses.add(new Expense(1L, "September - Rent", "Rent expenses for September", 1200.00, getOrCreateExpenseGroupByName("Rent"), septemberDate));
        expenses.add(new Expense(2L, "September - Utilities", "Utilities expenses for September", 150.00, getOrCreateExpenseGroupByName("Utilities"), septemberDate));
        expenses.add(new Expense(3L, "September - Food", "Food expenses for September", 200.00, getOrCreateExpenseGroupByName("Food"), septemberDate));
        expenses.add(new Expense(4L, "September - Transportation", "Transportation expenses for September", 100.00, getOrCreateExpenseGroupByName("Transportation"), septemberDate));
        expenses.add(new Expense(5L, "September - Entertainment", "Entertainment expenses for September", 50.00, getOrCreateExpenseGroupByName("Entertainment"), septemberDate));
        expenses.add(new Expense(6L, "September - Clothing", "Clothing expenses for September", 80.00, getOrCreateExpenseGroupByName("Clothing"), septemberDate));
        expenses.add(new Expense(7L, "September - Healthcare", "Healthcare expenses for September", 70.00, getOrCreateExpenseGroupByName("Healthcare"), septemberDate));
        expenses.add(new Expense(8L, "September - Education", "Education expenses for September", 150.00, getOrCreateExpenseGroupByName("Education"), septemberDate));
        expenses.add(new Expense(9L, "September - Travel", "Travel expenses for September", 300.00, getOrCreateExpenseGroupByName("Travel"), septemberDate));
        expenses.add(new Expense(10L, "September - Insurance", "Insurance expenses for September", 100.00, getOrCreateExpenseGroupByName("Insurance"), septemberDate));

        // Generate expenses for October
        ZonedDateTime octoberDate = ZonedDateTime.now().withMonth(10);

        // Adjust the template for October and use the provided groups
        expenses.add(new Expense(1L, "October - Rent", "Expenses for rent", 1500.00, getOrCreateExpenseGroupByName("Rent"), octoberDate));
        expenses.add(new Expense(2L, "October - Utilities", "Expenses for utilities", 200.00, getOrCreateExpenseGroupByName("Utilities"), octoberDate));
        expenses.add(new Expense(3L, "October - Food", "Expenses for food", 300.00, getOrCreateExpenseGroupByName("Food"), octoberDate));
        expenses.add(new Expense(4L, "October - Transportation", "Expenses for transportation", 100.00, getOrCreateExpenseGroupByName("Transportation"), octoberDate));
        expenses.add(new Expense(5L, "October - Entertainment", "Expenses for entertainment", 50.00, getOrCreateExpenseGroupByName("Entertainment"), octoberDate));
        expenses.add(new Expense(6L, "October - Clothing", "Expenses for clothing", 80.00, getOrCreateExpenseGroupByName("Clothing"), octoberDate));
        expenses.add(new Expense(7L, "October - Healthcare", "Expenses for healthcare", 150.00, getOrCreateExpenseGroupByName("Healthcare"), octoberDate));
        expenses.add(new Expense(8L, "October - Education", "Expenses for education", 200.00, getOrCreateExpenseGroupByName("Education"), octoberDate));
        expenses.add(new Expense(9L, "October - Travel", "Expenses for travel", 400.00, getOrCreateExpenseGroupByName("Travel"), octoberDate));
        expenses.add(new Expense(10L, "October - Insurance", "Expenses for insurance", 120.00, getOrCreateExpenseGroupByName("Insurance"), octoberDate));

        // Generate expenses for November
        ZonedDateTime novemberDate = ZonedDateTime.now().withMonth(11);

        // Adjust the template for November and use the provided groups
        expenses.add(new Expense(1L, "November - Rent", "Expenses for rent", 1500.00, getOrCreateExpenseGroupByName("Rent"), novemberDate));
        expenses.add(new Expense(2L, "November - Utilities", "Expenses for utilities", 200.00, getOrCreateExpenseGroupByName("Utilities"), novemberDate));
        expenses.add(new Expense(3L, "November - Food", "Expenses for food", 300.00, getOrCreateExpenseGroupByName("Food"), novemberDate));
        expenses.add(new Expense(4L, "November - Transportation", "Expenses for transportation", 100.00, getOrCreateExpenseGroupByName("Transportation"), novemberDate));
        expenses.add(new Expense(5L, "November - Entertainment", "Expenses for entertainment", 50.00, getOrCreateExpenseGroupByName("Entertainment"), novemberDate));
        expenses.add(new Expense(6L, "November - Clothing", "Expenses for clothing", 80.00, getOrCreateExpenseGroupByName("Clothing"), novemberDate));
        expenses.add(new Expense(7L, "November - Healthcare", "Expenses for healthcare", 150.00, getOrCreateExpenseGroupByName("Healthcare"), novemberDate));
        expenses.add(new Expense(8L, "November - Education", "Expenses for education", 200.00, getOrCreateExpenseGroupByName("Education"), novemberDate));
        expenses.add(new Expense(9L, "November - Travel", "Expenses for travel", 400.00, getOrCreateExpenseGroupByName("Travel"), novemberDate));
        expenses.add(new Expense(10L, "November - Insurance", "Expenses for insurance", 120.00, getOrCreateExpenseGroupByName("Insurance"), novemberDate));

        // Generate expenses for December
        ZonedDateTime decemberDate = ZonedDateTime.now().withMonth(12);

        // Adjust the template for December and use the provided groups
        expenses.add(new Expense(1L, "December - Rent", "Expenses for rent", 1500.00, getOrCreateExpenseGroupByName("Rent"), decemberDate));
        expenses.add(new Expense(2L, "December - Utilities", "Expenses for utilities", 200.00, getOrCreateExpenseGroupByName("Utilities"), decemberDate));
        expenses.add(new Expense(3L, "December - Food", "Expenses for food", 300.00, getOrCreateExpenseGroupByName("Food"), decemberDate));
        expenses.add(new Expense(4L, "December - Transportation", "Expenses for transportation", 100.00, getOrCreateExpenseGroupByName("Transportation"), decemberDate));
        expenses.add(new Expense(5L, "December - Entertainment", "Expenses for entertainment", 50.00, getOrCreateExpenseGroupByName("Entertainment"), decemberDate));
        expenses.add(new Expense(6L, "December - Clothing", "Expenses for clothing", 80.00, getOrCreateExpenseGroupByName("Clothing"), decemberDate));
        expenses.add(new Expense(7L, "December - Healthcare", "Expenses for healthcare", 150.00, getOrCreateExpenseGroupByName("Healthcare"), decemberDate));
        expenses.add(new Expense(8L, "December - Education", "Expenses for education", 200.00, getOrCreateExpenseGroupByName("Education"), decemberDate));
        expenses.add(new Expense(9L, "December - Travel", "Expenses for travel", 400.00, getOrCreateExpenseGroupByName("Travel"), decemberDate));
        expenses.add(new Expense(10L, "December - Insurance", "Expenses for insurance", 120.00, getOrCreateExpenseGroupByName("Insurance"), decemberDate));

        return expenses.getList();
    }

    public static int generateRandomDay() {
        // Create a Random object
        Random random = new Random();

        // Generate a random number between 0 and 28 (inclusive)
        return random.nextInt(1,29); // Since upper bound is exclusive, use 29 for 0-28 range
    }
    public static int generateRandomHour() {
        // Create a Random object
        Random random = new Random();

        // Generate a random number between 0 and 23 (inclusive)
        return random.nextInt(1,24); // Since upper bound is exclusive, use 24 for 0-23 range
    }

}
