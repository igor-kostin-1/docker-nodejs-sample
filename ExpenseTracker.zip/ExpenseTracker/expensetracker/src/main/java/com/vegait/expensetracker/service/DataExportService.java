package com.vegait.expensetracker.service;

import com.itextpdf.text.DocumentException;
import com.vegait.expensetracker.dto.projection.EnhencedTransactionProjection;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.service.common.TransactionService;
import com.vegait.expensetracker.utility.transactionsUtils.EmptyDataPDFTemplate;
import com.vegait.expensetracker.utility.transactionsUtils.TransactionDataStats;
import com.vegait.expensetracker.utility.transactionsUtils.TransactionPDFTemplates;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DataExportService {
    private final TransactionService<Income, Long, Long, IncomeGroup, Long> incomeService;
    private final TransactionService<Expense, Long, Long, ExpenseGroup, Long> expenseService;

    public DataExportService(TransactionService<Income, Long, Long, IncomeGroup, Long> incomeService, TransactionService<Expense, Long, Long, ExpenseGroup, Long> expenseService) {
        this.incomeService = incomeService;
        this.expenseService = expenseService;
    }

    public byte[] getTotalReport(TransactionFilter filter) throws DocumentException, FileNotFoundException {
        return this.createPdfTemplates(filter).totalTransactionReport();
    }

    public byte[] getMonthlyReport(TransactionFilter filter, ZonedDateTime time) throws DocumentException, FileNotFoundException {
        return this.createPdfTemplates(filter).monthlyTransactionReport(time.getMonth());
    }

    private TransactionPDFTemplates createPdfTemplates(TransactionFilter filter) throws DocumentException, FileNotFoundException {
        List<EnhencedTransactionProjection> incomes = this.incomeService.findAll(filter).stream().map(i -> (new EnhencedTransactionProjection.ETP(Income.class, i))).collect(Collectors.toList());
        List<EnhencedTransactionProjection> expenses = this.expenseService.findAll(filter).stream().map(i -> (new EnhencedTransactionProjection.ETP(Expense.class, i))).collect(Collectors.toList());

        return this.createTemplate(incomes, expenses);
    }

    //
    public byte[] getTotalReport(TransactionFilter filter, Long user_id) throws DocumentException, FileNotFoundException {
        return this.createPdfTemplates(filter, user_id).totalTransactionReport();
    }

    public byte[] getMonthlyReport(TransactionFilter filter, ZonedDateTime time, Long user_id) throws DocumentException, FileNotFoundException {
        return this.createPdfTemplates(filter, user_id).monthlyTransactionReport(time.getMonth());
    }

    private TransactionPDFTemplates createPdfTemplates(TransactionFilter filter, Long user_id) throws DocumentException, FileNotFoundException {
        List<EnhencedTransactionProjection> incomes = this.incomeService.findAll(filter, user_id).stream().map(i -> (new EnhencedTransactionProjection.ETP(Income.class, i))).collect(Collectors.toList());
        List<EnhencedTransactionProjection> expenses = this.expenseService.findAll(filter, user_id).stream().map(i -> (new EnhencedTransactionProjection.ETP(Expense.class, i))).collect(Collectors.toList());

        return this.createTemplate(incomes, expenses);
    }

    private TransactionPDFTemplates createTemplate(List<EnhencedTransactionProjection> incomes, List<EnhencedTransactionProjection> expenses) {
        try {
            TransactionDataStats dataStats = new TransactionDataStats(incomes, expenses);
            return new TransactionPDFTemplates(dataStats);
        } catch (Exception e) {
            return new EmptyDataPDFTemplate(null);
        }
    }


}
