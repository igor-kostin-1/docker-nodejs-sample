package com.vegait.expensetracker.controller.common.crud;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * ICRUDController is an interface defining common CRUD apis for entities
 * through HTTP requests. It specifies methods for retrieving, creating, updating,
 * and deleting entities.
 *
 * @param <T>     The type of entity managed by the controller.
 * @param <T_DTO> The DTO (Data Transfer Object) type representing the entity.
 * @param <T_ID>  The type of the entity's identifier.
 */
public interface ICRUDController<T, T_DTO, T_ID>{
    // GET - getAll, getOne ----------------------------------------------------------------------------
    // Get all entity

    /**
     * Retrieves all entities.
     *
     * @return A ResponseEntity containing a collection of DTOs representing the entities.
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    ResponseEntity<Iterable<T_DTO>> findAll();

    // Get one entity

    /**
     * Retrieves an entity by its identifier.
     *
     * @param id The identifier of the entity to retrieve.
     * @return A ResponseEntity containing the DTO representing the entity, if found.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.GET)
    ResponseEntity<T_DTO> findById(@PathVariable("id") T_ID id);

    // POST - create(one), --------------------------------------------------------------------------------
    // Create one entity

    /**
     * Creates a new entity.
     *
     * @param newProvideEntity The DTO representing the new entity to create.
     * @return A ResponseEntity containing the DTO representing the created entity.
     */
    @RequestMapping(path = "", method = RequestMethod.POST)
    ResponseEntity<T_DTO> save(@Valid @RequestBody T_DTO newProvideEntity);


    // PUT - update(one), ----------------------------------------------------------------------------------------------
    // Update one entity

    /**
     * Updates an existing entity.
     *
     * @param dto The DTO containing the updated information for the entity.
     * @return A ResponseEntity containing the DTO representing the updated entity.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.PUT)
    ResponseEntity<T_DTO> update(@PathVariable T_ID id,@Valid @RequestBody T_DTO dto);


    // DELETE - delete(one) -------------------------------------------------------------------------------
    // Delete one entity

    /**
     * Deletes an entity by its identifier.
     *
     * @param id The identifier of the entity to delete.
     * @return A ResponseEntity indicating the success or failure of the deletion operation.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
    ResponseEntity<Void> delete(@PathVariable("id") T_ID id);

}

