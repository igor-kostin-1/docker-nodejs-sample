package com.vegait.expensetracker.service.common;

import com.vegait.expensetracker.dto.projection.TransactionProjection;
import com.vegait.expensetracker.error.EntityDontExit;
import com.vegait.expensetracker.error.MissingUser;
import com.vegait.expensetracker.mapper.common.SaveIEntityMapper;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.model.common.ITransaction;
import com.vegait.expensetracker.model.common.IUserOwned;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.repository.common.TransactionRepository;
import com.vegait.expensetracker.security.model.User;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.security.service.UserDetailsImpl;

import java.util.List;

public abstract class TransactionService<
        T extends IUserOwned & IEntityObject<T_ID> & ITransaction<T_GROUP>,
        T_ID,
        T_USER_ID,
        T_GROUP extends IUserOwned & IEntityObject<T_GROUP_ID>,
        T_GROUP_ID>
        implements ICRUDService<T, T_ID, T_USER_ID>, IPageableAccessor<TransactionProjection> {

    protected final TransactionRepository<T, T_ID, T_USER_ID> repository;
    protected final UserRepository userRepository;
    protected final TransactionGroupService<T_GROUP, T_GROUP_ID, T_USER_ID> groupService;

    public TransactionService(final TransactionRepository<T, T_ID, T_USER_ID> repository,
                              final UserRepository userRepository,
                              final TransactionGroupService<T_GROUP, T_GROUP_ID, T_USER_ID> groupService) {
        this.repository = repository;
        this.userRepository = userRepository;
        this.groupService = groupService;
    }

    @Override
    public List<T> findAll() {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        return (List<T>) repository.findByUserId(userDetails.getId());
    }

    @Override
    public T findById(T_ID id) {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        return this.repository.findFirstByIdAndUserId(id, userDetails.getId()).orElseThrow(
                () -> new EntityDontExit("No entity found with identifier" + id)
        );
    }

    @Override
    public T save(T entity) {

        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();
        User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow(
                () -> new MissingUser("There was error getting user data, please re login.")
        );

        T_GROUP group;
        try {
            group = this.groupService.findById(entity.getGroup().getId());// The transaction group does exist, so we use that one
        } catch (
                Exception e) {
            // ignoring potentially changed other values in a group, The transaction group does not exist, so we create a new one
            group = this.groupService.save(SaveIEntityMapper.saveSafe(entity.getGroup()));
        }

        entity.setUser(user);
        entity.setGroup(group);

        return repository.save(entity);
    }

    @Override
    public T update(T entity) {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        this.repository.findFirstByIdAndUserId(entity.getId(), userDetails.getId()).orElseThrow(
                () -> new EntityDontExit("Entity request to be updated does not exist, or user does not have permission to make changes to that entity")
        );

        T_GROUP group;

        try {
            group = this.groupService.findById(entity.getGroup().getId()); // The transaction group does exist, so we use that one
        } catch (
                Exception _e) {
            // The transaction group does not exist, so we create a new one, ignoring potentially changed other values in a group
            group = this.groupService.save(SaveIEntityMapper.saveSafe(entity.getGroup()));
        }

        entity.setGroup(group);


        return repository.save(entity);
    }

    @Override
    public void delete(T_ID id) {
        UserDetailsImpl<T_USER_ID> userDetails = this.getUserDetails();

        this.repository.findFirstByIdAndUserId(id, userDetails.getId()).orElseThrow(
                () -> new EntityDontExit("Entity request to be deleted does not exist, or user does not have permission to make changes to that entity")
        );

        repository.deleteById(id);
    }

    public abstract Double sum(TransactionFilter filter);

    public abstract List<TransactionProjection> findAll(TransactionFilter filter);

    public abstract List<TransactionProjection> findAll(TransactionFilter filter, Long user_id);
}
