package com.vegait.expensetracker.utility.transactionsUtils;

import com.vegait.expensetracker.dto.projection.TransactionProjection;


/**
 * Functional interface for accessing values from transaction projections.
 */
public interface Accessor {

    /**
     * Gets a specific value from a transaction projection.
     *
     * @param t The transaction projection from which to retrieve the value.
     * @return The value extracted from the transaction projection.
     */
    String get(TransactionProjection t);

}