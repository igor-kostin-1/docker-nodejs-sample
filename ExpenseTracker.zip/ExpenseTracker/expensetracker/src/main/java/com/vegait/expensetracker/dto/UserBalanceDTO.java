package com.vegait.expensetracker.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class UserBalanceDTO {
    private Double total;
    private Double totalIncome;
    private Double totalExpense;
}
