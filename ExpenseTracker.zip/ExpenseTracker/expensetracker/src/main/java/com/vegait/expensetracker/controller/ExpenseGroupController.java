package com.vegait.expensetracker.controller;

import com.vegait.expensetracker.controller.common.crud.CRUDController;
import com.vegait.expensetracker.controller.common.crud.CRUDControllerHandlerImpl;
import com.vegait.expensetracker.controller.common.crud.LoggingAbsCRUDController;
import com.vegait.expensetracker.dto.ExpenseGroupDTO;
import com.vegait.expensetracker.mapper.common.CollectionMapperFactory;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.service.common.ICRUDService;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/expensegroup")
public class ExpenseGroupController extends CRUDController<ExpenseGroup, ExpenseGroupDTO, Long, Long> {

    @Getter private final String singular = "ExpenseGroup";
    @Getter private final String plural = "ExpenseGroups";

    public ExpenseGroupController(final ICRUDService<ExpenseGroup, Long, Long> service,
                                  final IEntityMapper<ExpenseGroup, ExpenseGroupDTO> mapper) {
        super(service, mapper, CollectionMapperFactory.create(mapper), new LoggingAbsCRUDController<>(
                new CRUDControllerHandlerImpl<>(service, mapper),
                "ExpenseGroups",
                "ExpenseGroup") {
        });
    }

    @GetMapping("/mock")
    public ResponseEntity<List<ExpenseGroupDTO>> getMock() {
        return new ResponseEntity<>(
                Arrays.asList(
                        new ExpenseGroupDTO(12L, "Insurance", "Expanses about insurance."),
                        new ExpenseGroupDTO(13L, "Car", "Expanses about vehicles."),
                        new ExpenseGroupDTO(14L, "Rent", null)
                ), HttpStatus.OK);
    }
}
