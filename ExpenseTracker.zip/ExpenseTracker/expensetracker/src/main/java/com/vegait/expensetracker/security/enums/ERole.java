package com.vegait.expensetracker.security.enums;

public enum ERole {
    ROLE_USER, ROLE_PREMIUM_USER
}
