package com.vegait.expensetracker.task;

public enum TaskFrequency {
    MONTHLY,
    WEEKLY,
    DAILY,
    MINUTE
}
