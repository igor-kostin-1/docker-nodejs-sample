package com.vegait.expensetracker.dto;

import com.vegait.expensetracker.model.common.IEntityObject;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
public class ExpenseDTO implements IEntityObject<Long> {
    private Long id;

//    @NotBlank(message = "Expense: Invalid Name: Empty name")
//    @NotNull(message = "Expense: Invalid Name: Name is NULL")
    private String name;

    private String description;

//    @NotNull(message = "Expense: Invalid Amount: Amount is NULL")
    @Min(value = 0, message ="Expense: Invalid Amount: Amount les than zero")
    private Double amount;

//    @NotNull(message = "Expense: Invalid Group: Group is NULL")
    private ExpenseGroupDTO group;

}
