package com.vegait.expensetracker.controller.common.crud;

public interface ILoggable {
    String getSingular();
    String getPlural();
}
