package com.vegait.expensetracker.utility.transactionsUtils;

import com.vegait.expensetracker.dto.projection.EnhencedTransactionProjection;
import com.vegait.expensetracker.dto.projection.TransactionProjection;
import lombok.Getter;

import java.time.Month;
import java.time.YearMonth;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Represents statistics and analysis data for transactions, including incomes and expenses.
 * This class provides various methods to compute and analyze transaction data, such as total income, total expense,
 * maximum and minimum transactions, transactions grouped by month and group, etc.
 */
@Getter
public class TransactionDataStats {

    /**
     * List of enhanced transaction projections representing incomes.
     */
    private List<EnhencedTransactionProjection> incomes;

    /**
     * List of enhanced transaction projections representing expenses.
     */
    private List<EnhencedTransactionProjection> expenses;

    /**
     * The transaction with the highest income amount.
     */
    private EnhencedTransactionProjection maxIncomeTransaction;

    /**
     * The transaction with the lowest income amount.
     */
    private EnhencedTransactionProjection minIncomeTransaction;

    /**
     * The transaction with the highest expense amount.
     */
    private EnhencedTransactionProjection maxExpenseTransaction;

    /**
     * The transaction with the lowest expense amount.
     */
    private EnhencedTransactionProjection minExpenseTransaction;

    /**
     * The total income amount.
     */
    private Double totalIncome;

    /**
     * The total expense amount.
     */
    private Double totalExpense;

    /**
     * The total balance amount (income - expense).
     */
    private Double totalBalance;

    /**
     * Map of incomes grouped by {@link Group}.
     */
    private Map<Group, List<EnhencedTransactionProjection>> incomesByGroup;

    /**
     * Map of expenses grouped by {@link Group}.
     */
    private Map<Group, List<EnhencedTransactionProjection>> expensesByGroup;

    /**
     * Sum of income amounts grouped by group name, sorted in descending order.
     */
    private Map<String, Double> incomeSumAmountByGroupSorted;

    /**
     * Sum of expense amounts grouped by group name, sorted in descending order.
     */
    private Map<String, Double> expenseSumAmountByGroupSorted;

    /**
     * Sum of income amounts grouped by month, sorted in descending order.
     */
    private Map<String, Double> incomeSumAmountByMonthSorted;

    /**
     * Sum of expense amounts grouped by month, sorted in descending order.
     */
    private Map<String, Double> expenseSumAmountByMonthSorted;

    /**
     * Balance per month (income - expense), sorted by month.
     */
    private Map<String, Double> balancePerMonth;

    /**
     * Map representing the total income amount per day, where the key is the day of the month and the value is the total income amount for that day.
     */
    private Map<String, Double> incomesPerDay;

    /**
     * Map representing the total expense amount per day, where the key is the day of the month and the value is the total expense amount for that day.
     */
    private Map<String, Double> expensesPerDay;

    /**
     * List of enhanced transaction projections sorted by creation date.
     */
    private List<EnhencedTransactionProjection> transactionSortedByCreated;

    /**
     * Cache for storing transactions grouped by month to avoid redundant computations.
     * The key is a list of transactions, and the value is a map where the key is the month and the value is the list of transactions for that month.
     */
    private Map<List<EnhencedTransactionProjection>, Map<String, List<EnhencedTransactionProjection>>> transactionsByMonthSortedCache = new HashMap<>();


    /**
     * Constructor for initializing TransactionDataStats with incomes and expenses.
     * Computes various statistics and analyses based on the provided transactions.
     *
     * @param incomes  List of enhanced transaction projections representing incomes.
     * @param expenses List of enhanced transaction projections representing expenses.
     */
    public TransactionDataStats(List<EnhencedTransactionProjection> incomes, List<EnhencedTransactionProjection> expenses) throws NoSuchElementException {
        this.incomes = incomes;
        this.expenses = expenses;


        // Calculate the total income, total expense, and overall balance
        this.totalIncome = this.incomes.stream().mapToDouble(TransactionProjection::getAmount).sum();
        this.totalExpense = this.expenses.stream().mapToDouble(TransactionProjection::getAmount).sum();
        this.totalBalance = this.totalIncome - this.totalExpense;

        // Find the transaction with the maximum and minimum expense amount
        this.maxExpenseTransaction = Collections.max(expenses, Comparator.comparingDouble(TransactionProjection::getAmount));
        this.minExpenseTransaction = Collections.min(expenses, Comparator.comparingDouble(TransactionProjection::getAmount));

        // Find the transaction with the maximum and minimum income amount
        this.maxIncomeTransaction = Collections.max(incomes, Comparator.comparingDouble(TransactionProjection::getAmount));
        this.minIncomeTransaction = Collections.min(incomes, Comparator.comparingDouble(TransactionProjection::getAmount));

        // Group the incomes and expenses by their respective categories (groups)
        this.incomesByGroup = incomes.stream().collect(Collectors.groupingBy(t -> new Group(t.getGroupId(), t.getGroupName())));
        this.expensesByGroup = expenses.stream().collect(Collectors.groupingBy(t -> new Group(t.getGroupId(), t.getGroupName())));

        // Merge incomes and expenses into a single sorted list by creation date
        this.transactionSortedByCreated = Stream.concat(incomes.stream(), expenses.stream())
                .sorted(Comparator.comparing(TransactionProjection::getCreated))
                .toList();

        // Compute and sort the sums of expenses and incomes by their respective groups
        this.expenseSumAmountByGroupSorted = this.sumByKey(this.expensesByGroup, Group::getName)
                .entrySet().stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
        this.incomeSumAmountByGroupSorted = this.sumByKey(this.incomesByGroup, Group::getName)
                .entrySet().stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        // Compute and sort the sums of expenses and incomes by month. User only first 3 letters of month.
        this.incomeSumAmountByMonthSorted = this.sumByKey(this.groupByMonth(this.incomes), (k) -> k.substring(0, 3));
        this.expenseSumAmountByMonthSorted = this.sumByKey(this.groupByMonth(this.expenses), (k) -> k.substring(0, 3));

        // Compute the balance for each month
        this.balancePerMonth = this.balancePerMonth(this.incomes, this.expenses);
    }

    /**
     * Sums the amounts of transactions grouped by a specified key, returning a map where the key is the result of applying
     * the key mapper function to each transaction group. The value is the sum of amounts in each group.
     *
     * @param transactions A map where the key represents the grouping criteria, and the value is a list of transactions.
     * @param keyMapper    A function to extract the key from each transaction group.
     * @param <T>          The type of the key used for grouping transactions.
     * @return A map where each entry represents the sum of amounts for a specific key.
     */
    public <T> Map<String, Double> sumByKey(Map<T, List<EnhencedTransactionProjection>> transactions, Function<? super T, String> keyMapper) {
        // Stream over the entries of the transaction map
        return transactions.entrySet().stream()
                // Collect into a new map where the key is the result of applying the key mapper function,
                // and the value is the sum of amounts in each group
                .collect(Collectors.toMap(
                        // Extract the key from the entry and apply the key mapper function
                        entry -> keyMapper.apply(entry.getKey()),
                        // Calculate the sum of amounts in the transaction group
                        entry -> entry.getValue().stream()
                                .mapToDouble(TransactionProjection::getAmount)
                                .sum(),
                        // Merge function to handle duplicate keys (not used here as LinkedHashMap is used)
                        (oldValue, newValue) -> oldValue,
                        // Use LinkedHashMap to maintain insertion order
                        LinkedHashMap::new
                ));
    }


    /**
     * Groups transactions by month, returning a map where the key is the name of the month (in uppercase) and the value
     * is a list of transactions that occurred in that month.
     *
     * @param transactions The list of transactions to group by month.
     * @return A map where each entry represents transactions grouped by month.
     */
    public Map<String, List<EnhencedTransactionProjection>> groupByMonth(List<EnhencedTransactionProjection> transactions) {
        // Check if transactions are already cached
        if (this.transactionsByMonthSortedCache.containsKey(transactions))
            return this.transactionsByMonthSortedCache.get(transactions);

        // Initialize a new map to store transactions grouped by month
        Map<String, List<EnhencedTransactionProjection>> groupedTransactions = new LinkedHashMap<>();

        // Initialize lists for each month
        for (Month month : Month.values()) {
            groupedTransactions.put(month.name(), new ArrayList<>());
        }

        // Iterate through each transaction and add it to the corresponding month list
        transactions.forEach(t -> {
            groupedTransactions.get(t.getCreated().getMonth().name()).add(t);
        });

        // Cache the grouped transactions to avoid recalculating for the same input
        this.transactionsByMonthSortedCache.put(transactions, groupedTransactions);

        return groupedTransactions;
    }

    /**
     * Groups transactions by the provided accessor function, returning a map where the key is determined
     * by applying the accessor function to each transaction, and the value is a list of transactions
     * associated with that key.
     *
     * @param transactions The list of transactions to group.
     * @param accessor     The accessor function used to determine the grouping key for each transaction.
     * @return A map where transactions are grouped by the key returned by the accessor function.
     */
    public Map<String, List<EnhencedTransactionProjection>> groupBy(List<EnhencedTransactionProjection> transactions, Accessor accessor) {
        // Group transactions using the provided accessor function
        return transactions.stream().collect(Collectors.groupingBy(accessor::get));
    }

    /**
     * Groups transactions by day within the specified month, returning a map where the key is the day
     * of the month and the value is the total amount of transactions for that day.
     *
     * @param transactions The list of transactions to group.
     * @param month        The month for which transactions will be grouped by day.
     * @return A map where transactions are grouped by day within the specified month.
     */
    public Map<String, Double> transactionByDay(List<EnhencedTransactionProjection> transactions, Month month) {
        // Initialize a map to store transactions grouped by day
        Map<String, List<EnhencedTransactionProjection>> groupedByDay = new LinkedHashMap<>();

        // Get the current year and month
        ZonedDateTime zonedDateTime = ZonedDateTime.now().withMonth(month.getValue());

        // Get the total number of days in the specified month
        YearMonth yearMonthObject = YearMonth.of(zonedDateTime.getYear(), zonedDateTime.getMonth());

        // Initialize the map with empty lists for each day of the month
        IntStream.range(1, yearMonthObject.lengthOfMonth() + 1).forEachOrdered(dayOfMonth -> {
            groupedByDay.put(String.valueOf(dayOfMonth), new ArrayList<>());
        });

        // Group transactions by day of the month
        transactions.forEach(transaction -> {
            groupedByDay.get(String.valueOf(transaction.getCreated().getDayOfMonth())).add(transaction);
        });

        // Calculate the total amount of transactions for each day and return the result
        return sumByKey(groupedByDay, key -> key);
    }

    /**
     * Calculates the cumulative balance for each month based on the provided incomes and expenses.
     * The balance for each month is the sum of incomes minus expenses up to that month.
     *
     * @param incomes  The list of income transactions.
     * @param expenses The list of expense transactions.
     * @return A map where the key is the abbreviated month name (e.g., "JAN") and the value is the
     * cumulative balance up to that month.
     */
    public Map<String, Double> balancePerMonth(List<EnhencedTransactionProjection> incomes,
                                               List<EnhencedTransactionProjection> expenses) {
        // Calculate the sum of incomes per month
        Map<String, Double> incomeSumByMonth = sumByKey(groupByMonth(incomes), month -> month.substring(0, 3));

        // Calculate the sum of expenses per month
        Map<String, Double> expenseSumByMonth = sumByKey(groupByMonth(expenses), month -> month.substring(0, 3));

        // Calculate the cumulative balance for each month
        Map<String, Double> balancePerMonth = new LinkedHashMap<>();
        double cumulativeBalance = 0.0;

        for (Map.Entry<String, Double> entry : incomeSumByMonth.entrySet()) {
            String month = entry.getKey();
            double income = entry.getValue();
            double expense = expenseSumByMonth.getOrDefault(month, 0.0);

            // Calculate the cumulative balance up to the current month
            cumulativeBalance += income - expense;

            // Store the cumulative balance for the current month
            balancePerMonth.put(month, cumulativeBalance);
        }

        return balancePerMonth;
    }

    public static <T, T1> Map.Entry<T, T1> getFirst(Map<T, T1> entries) {
        return entries.entrySet().stream().iterator().next();
    }

    public static <T, T1> Map.Entry<T, T1> getLast(Map<T, T1> entries) {
        return entries.entrySet().stream().iterator().next();
    }


}
