package com.vegait.expensetracker.error;

import jakarta.validation.ConstraintViolation;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

@Getter
@ToString
@AllArgsConstructor
public class AttributeValidationError {
    private String entity;
    private String attribute;
    private String message;

    public <T> AttributeValidationError(ConstraintViolation<T> error){
//        this.entity = error.getRootBeanClass().getSimpleName();
        this.attribute = error.getPropertyPath().toString();
        this.message = error.getMessage();
    }

    public AttributeValidationError(ObjectError error){
//        this.entity = error.getObjectName();
        this.attribute = ((FieldError) error).getField();
        this.message = error.getDefaultMessage();
    }
}
