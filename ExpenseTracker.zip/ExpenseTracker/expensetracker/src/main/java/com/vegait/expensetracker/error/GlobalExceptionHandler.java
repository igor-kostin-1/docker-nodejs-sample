package com.vegait.expensetracker.error;

import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler({EntityDontExit.class})
    public ResponseEntity<Object> handleEntityDontExit(EntityDontExit exception) {
        log.warn("User: " + this.username() + " caused " + "Exception: " + exception.getMessage());
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(exception.getMessage());
    }

    @ExceptionHandler({MissingUser.class})
    public ResponseEntity<Object> handleMissingUserException(MissingUser exception) {
        log.error("User: " + this.username() + " caused " + "Exception: " + exception.getMessage());
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(exception.getMessage());
    }

    @ExceptionHandler({UserAlreadyExistException.class})
    public ResponseEntity<Object> handleUserAlreadyExist(UserAlreadyExistException exception) {
        log.error("Attempt to create pre existing user caused:  " + "Exception: " + exception.getMessage());
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(exception.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({SQLIntegrityConstraintViolationException.class})
    public String handleValidationError(SQLIntegrityConstraintViolationException exception) {

        log.error("User: " + this.username() + " caused SQLIntegrityConstraintViolationException Exception: " + exception.getMessage());

        return exception.getMessage();
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({InvalidEntityField.class})
    public String handleValidationError(InvalidEntityField exception) {

        log.error("User: " + this.username() + " caused InvalidEntityField Exception: " + exception.getMessage());

        return exception.getMessage();
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({ConstraintViolationException.class})
    public List<AttributeValidationError> handleValidationError(ConstraintViolationException exception) {
        List<AttributeValidationError> errors = new ArrayList<>();

        exception.getConstraintViolations().forEach((violation) -> {
            errors.add(new AttributeValidationError(violation));
        });

        log.error("User: " + this.username() + " caused Constraint Validation Exception: " + errors);

        return errors;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public List<AttributeValidationError> handleValidationExceptions(MethodArgumentNotValidException ex) {
        List<AttributeValidationError> errors = new ArrayList<>();

        ex.getBindingResult().getAllErrors().forEach((error) -> {
            errors.add(new AttributeValidationError(error));
        });

        log.error("User: " + this.username() + " MethodArgumentNotValidException: " + errors);

        return errors;
    }


    private String username() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return null;
        return auth.getName();
    }
}
