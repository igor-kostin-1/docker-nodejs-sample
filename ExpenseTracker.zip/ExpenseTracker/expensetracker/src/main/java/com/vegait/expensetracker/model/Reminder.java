package com.vegait.expensetracker.model;

import com.vegait.expensetracker.security.model.User;
import com.vegait.expensetracker.task.TaskFrequency;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Builder
@Table(name = "reminder")
@AllArgsConstructor
public class Reminder {

    private @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) Long id;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private TaskFrequency frequency;

    @Min(1)
    @Max(31)
    private int onDay;

    @Min(1)
    @Max(7)
    private int onDayOfWeek;

    @Min(0)
    @Max(23)
    private int onHour;

    @OneToOne(mappedBy = "reminder", optional = true)
    private User user;

}
