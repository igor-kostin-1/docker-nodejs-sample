package com.vegait.expensetracker.security.payload;

import com.vegait.expensetracker.security.model.validation.ValidPassword;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignupRequest {

    @NotBlank(message = "User: Invalid username: Empty username")
    @NotNull(message = "User: Invalid username: Username is NULL")
    private String username;

    @NotBlank(message = "User: Invalid fullName: Empty fullName")
    @NotNull(message = "User: Invalid fullName: FullName is NULL")
    private String fullName;

    @NotBlank(message = "User: Invalid email: Empty email")
    @NotNull(message = "User: Invalid email: Email is NULL")
    @Email(message = "User: Invalid email: Email is non valid")
    private String email;

    private Set<String> role;

    @NotBlank(message = "User: Invalid password: Empty password")
    @NotNull(message = "User: Invalid password: Password is NULL")
    @ValidPassword
    private String password;
}