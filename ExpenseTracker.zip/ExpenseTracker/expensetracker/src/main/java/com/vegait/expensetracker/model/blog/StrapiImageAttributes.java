package com.vegait.expensetracker.model.blog;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StrapiImageAttributes {
    private String name;
    private String alternativeText;
    private String caption;
    private int width;
    private int height;
    private StrapiImageFormats formats;
    private String hash;
    private String ext;
    private String mime;
    private double size;
    private String url;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
