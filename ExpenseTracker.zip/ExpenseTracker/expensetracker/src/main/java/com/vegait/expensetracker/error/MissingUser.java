package com.vegait.expensetracker.error;

public class MissingUser extends RuntimeException {

    public MissingUser(String s) {
        super(s);
    }
}