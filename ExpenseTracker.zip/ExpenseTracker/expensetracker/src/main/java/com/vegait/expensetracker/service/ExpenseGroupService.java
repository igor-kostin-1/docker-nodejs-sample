package com.vegait.expensetracker.service;

import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.repository.common.TransactionGroupRepository;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.service.common.TransactionGroupService;
import org.springframework.stereotype.Service;

@Service
public class ExpenseGroupService extends TransactionGroupService<ExpenseGroup, Long, Long> {
    public ExpenseGroupService(final TransactionGroupRepository<ExpenseGroup, Long, Long> repository, UserRepository userRepository) {
        super(repository, userRepository);
    }
}
