package com.vegait.expensetracker.controller.common.crud;

import com.vegait.expensetracker.mapper.common.CollectionMapperFactory;
import com.vegait.expensetracker.mapper.common.ICollectionMapper;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.mapper.common.SaveIEntityMapper;
import com.vegait.expensetracker.mapper.common.UpdateIEntityMapper;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.service.common.ICRUDService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

/**
 * CRUDControllerHandlerImpl is an implementation of the CRUD controller handler interface
 * for managing common CRUD operations for entities.
 *
 * @param <T>         The type of entity managed by the handler.
 * @param <T_DTO>     The DTO (Data Transfer Object) type representing the entity.
 * @param <T_ID>      The type of the entity's identifier.
 * @param <T_USER_ID> The type of the user identifier associated with the entity.
 */
public class CRUDControllerHandlerImpl<
        T extends IEntityObject<T_ID>,
        T_DTO extends IEntityObject<T_ID>,
        T_ID,
        T_USER_ID
        > implements ICRUDControllerHandler<T_DTO, T_ID> {

    protected final ICRUDService<T, T_ID, T_USER_ID> service;
    protected final IEntityMapper<T, T_DTO> mapper;
    protected final ICollectionMapper<T, T_DTO> collectionMapper;

    public CRUDControllerHandlerImpl(ICRUDService<T, T_ID, T_USER_ID> service, IEntityMapper<T, T_DTO> mapper) {
        this.service = service;
        this.mapper = mapper;
        this.collectionMapper = CollectionMapperFactory.create(mapper);
    }


    @Override
    public ResponseEntity<Iterable<T_DTO>> findAll() {
        List<T_DTO> result = collectionMapper.mapDTOs(this.service.findAll()).stream().toList();

        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<T_DTO> findById(final T_ID id) {
        T entity = this.service.findById(id);

        return new ResponseEntity<>(mapper.toDTO(entity), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<T_DTO> save(final T_DTO entity) {
        SaveIEntityMapper<T, T_DTO, T_ID> mapper = new SaveIEntityMapper<>(this.mapper); // creating mapper safe for creating

        T newCreatedEntity = mapper.toEntity(entity);

        T cEntity = this.service.save(newCreatedEntity);

        return new ResponseEntity<>(mapper.toDTO(cEntity), HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<T_DTO> update(T_ID id, T_DTO dto) {
        T cEntity = this.service.findById(id);  // Error is thrown and handled (By global handler),
        // if an entity is not present, and therefore
        // update operation is canceled.

        UpdateIEntityMapper<T, T_DTO, T_ID> mapper = new UpdateIEntityMapper<>(this.mapper); // creating mapper safe for update

        T e = mapper.updateEntity(cEntity, dto); // e: entity sent for update

        T e_res = this.service.update(e);

        return new ResponseEntity<>(mapper.toDTO(e_res), HttpStatus.CREATED);

    }


    @Override
    public ResponseEntity<Void> delete(final T_ID id) {
        this.service.delete(id);

        return new ResponseEntity<>(HttpStatus.OK);
    }
}
