package com.vegait.expensetracker.repository;

import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.repository.common.TransactionGroupRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExpenseGroupRepository extends TransactionGroupRepository<ExpenseGroup, Long, Long> {
}
