package com.vegait.expensetracker.dto;

import com.vegait.expensetracker.model.common.IEntityObject;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncomeGroupDTO implements IEntityObject<Long> {
    private Long id;
//    @NotBlank(message = "Income Group: Invalid Name: Empty name")
//    @NotNull(message = "Income Group: Invalid Name: Name is NULL")
    private String name;
    private String description;
}
