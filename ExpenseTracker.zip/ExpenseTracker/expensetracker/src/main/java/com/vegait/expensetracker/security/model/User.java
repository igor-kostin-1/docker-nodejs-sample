package com.vegait.expensetracker.security.model;

import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.Income;
import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.model.Reminder;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.security.model.validation.ValidPassword;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Set;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Table(name = "users")
public class User implements IEntityObject<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "User: Invalid password: Empty password")
    @NotNull(message = "User: Invalid password: Password is NULL")
    private String password;

    @NotBlank(message = "User: Invalid username: Empty username")
    @NotNull(message = "User: Invalid username: Username is NULL")
    private String username;

    @NotBlank(message = "User: Invalid fullName: Empty fullName")
    @NotNull(message = "User: Invalid fullName: FullName is NULL")
    private String fullName;

    @NotBlank(message = "User: Invalid email: Empty email")
    @NotNull(message = "User: Invalid email: Email is NULL")
    @Email(message = "User: Invalid email: Email must be well-formatted email address")
    private String email;

    @OneToMany(mappedBy = "user")
    private Set<IncomeGroup> incomeGroups;

    @OneToMany(mappedBy = "user")
    private Set<ExpenseGroup> expenseGroups;

    @OneToMany(mappedBy = "user")
    private Set<Expense> expenses;

    @OneToMany(mappedBy = "user")
    private Set<Income> incomes;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private List<Role> roles;


    @OneToOne(optional = true, cascade = CascadeType.ALL)
    @JoinColumn(name = "remider_id", referencedColumnName = "id")
    private Reminder reminder;


    public User(String username, String fullName, String email, String password) {
        this.username = username;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
    }
}
