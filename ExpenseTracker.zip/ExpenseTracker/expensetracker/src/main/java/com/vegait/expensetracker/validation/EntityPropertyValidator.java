package com.vegait.expensetracker.validation;

import com.vegait.expensetracker.error.InvalidEntityField;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EntityPropertyValidator implements ConstraintValidator<ValidEntityProperty, String> {

    private Class<?> clazz;
    private String msg;

    @Override
    public void initialize(ValidEntityProperty constraintAnnotation) {
        this.clazz = constraintAnnotation.clazz();
        this.msg = constraintAnnotation.message();
    }

    @Override
    public boolean isValid(String contactField, ConstraintValidatorContext cxt) {
        boolean v = this.doesObjectContainField(clazz, contactField);
        if (v) return true;
        throw new InvalidEntityField("Field : '" + contactField + "' is not valid field for entity '" +clazz.getSimpleName()+"'");
    }

    public boolean doesObjectContainField(Class<?> _clazz, String fieldName) {
        try {
            _clazz.getDeclaredField(fieldName);
            return true;
        } catch (NoSuchFieldException e) {
            return false;
        }
    }

}