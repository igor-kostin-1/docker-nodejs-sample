package com.vegait.expensetracker.controller;

import com.vegait.expensetracker.controller.common.crud.CRUDControllerHandlerImpl;
import com.vegait.expensetracker.controller.common.crud.ICRUDControllerHandler;
import com.vegait.expensetracker.controller.common.crud.ILoggable;
import com.vegait.expensetracker.controller.common.crud.LoggingAbsCRUDController;
import com.vegait.expensetracker.dto.ExpenseDTO;
import com.vegait.expensetracker.dto.projection.TransactionProjection;
import com.vegait.expensetracker.mapper.common.CollectionMapperFactory;
import com.vegait.expensetracker.mapper.common.ICollectionMapper;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.service.common.TransactionService;
import com.vegait.expensetracker.validation.ValidEntityProperty;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Objects;

@Slf4j
@Tag(name = "Expense", description = "Expense management(CRUD) APIs")
@RestController
@RequestMapping("/expense")
public class ExpenseController implements ILoggable {

    @Getter private final String singular = "Expense";
    @Getter private final String plural = "Expenses";

    protected final TransactionService<Expense, Long, Long, ExpenseGroup, Long> service;
    protected final IEntityMapper<Expense, ExpenseDTO> mapper;
    protected final ICollectionMapper<Expense, ExpenseDTO> collectionMapper;

    protected final ICRUDControllerHandler<ExpenseDTO, Long> crudHandler;

    public ExpenseController(final TransactionService<Expense, Long, Long, ExpenseGroup, Long> service,
                             final IEntityMapper<Expense, ExpenseDTO> mapper) {
        this.service = service;
        this.mapper = mapper;
        this.collectionMapper = CollectionMapperFactory.create(mapper);
        this.crudHandler = new LoggingAbsCRUDController<>(new CRUDControllerHandlerImpl<>(service, mapper), "Expenses", "Expense");
    }

    // GET - getAll, getOne ----------------------------------------------------------------------------
    // Get all entity

    /**
     * Retrieves all entities.
     *
     * @param page          Page number
     * @param size          Number of items per page
     * @param sortBy        Sorting field
     * @param sortOrder     Sorting order (ASC or DESC)
     * @param name          Expense name
     * @param description   Expense description
     * @param amountGT      Expense amount greater than
     * @param amountLT      Expense amount less than
     * @param createdBefore Expenses created before
     * @param createdAfter  Expenses created after
     * @param groupId       Group ID filter
     * @return A page of TransactionProjection containing the found entities.
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public Page<TransactionProjection> findAll(
            @RequestParam(defaultValue = "0") @Valid @Min(0) int page,
            @RequestParam(defaultValue = "10") @Valid @Max(100) int size,
            @RequestParam(defaultValue = "created") @Valid @ValidEntityProperty(clazz=Expense.class) String sortBy,
            @RequestParam(defaultValue = "DESC") String sortOrder,
            @RequestParam(required = false, defaultValue = "") String name,
            @RequestParam(required = false, defaultValue = "") String description,
            @RequestParam(required = false, defaultValue = "") Double amountGT,
            @RequestParam(required = false, defaultValue = "") Double amountLT,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdBefore,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdAfter,
            @RequestParam(required = false, defaultValue = "") Long groupId

    ) {

        Sort.Direction _sortOrder = Objects.equals(sortOrder.toUpperCase(), "DESC") ? Sort.Direction.DESC : Sort.Direction.ASC;
        TransactionFilter filter = new TransactionFilter(name, description, amountGT, amountLT, createdBefore, createdAfter, groupId);

        Pageable paging = PageRequest.of(page, size, _sortOrder, sortBy);


        return service.findAll(paging, filter);
    }

    // Get one entity

    /**
     * Retrieves an entity by its identifier.
     *
     * @param id The identifier of the entity to retrieve.
     * @return A ResponseEntity containing the DTO representing the entity, if found.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<ExpenseDTO> findById(@PathVariable("id") Long id) {
        return crudHandler.findById(id);
    }

    // POST - create(one), --------------------------------------------------------------------------------
    // Create one entity

    /**
     * Creates a new entity.
     *
     * @param newProvideEntity The DTO representing the new entity to create.
     * @return A ResponseEntity containing the DTO representing the created entity.
     */
    @RequestMapping(path = "", method = RequestMethod.POST)
    public ResponseEntity<ExpenseDTO> save(@Valid @RequestBody ExpenseDTO newProvideEntity) {
        return crudHandler.save(newProvideEntity);
    }


    // PUT - update(one), ----------------------------------------------------------------------------------------------
    // Update one entity

    /**
     * Updates an existing entity.
     *
     * @param dto The DTO containing the updated information for the entity.
     * @return A ResponseEntity containing the DTO representing the updated entity.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.PUT)
    public ResponseEntity<ExpenseDTO> update(@PathVariable("id") Long id,@Valid @RequestBody ExpenseDTO dto) {
        return crudHandler.update(id, dto);
    }


    // DELETE - delete(one) -------------------------------------------------------------------------------
    // Delete one entity

    /**
     * Deletes an entity by its identifier.
     *
     * @param id The identifier of the entity to delete.
     * @return A ResponseEntity indicating the success or failure of the deletion operation.
     */
    @RequestMapping(path = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        return crudHandler.delete(id);
    }

    @GetMapping(path = "/sum")
    public Double sum(
            @RequestParam(required = false, defaultValue = "") String name,
            @RequestParam(required = false, defaultValue = "") String description,
            @RequestParam(required = false, defaultValue = "") Double amountGT,
            @RequestParam(required = false, defaultValue = "") Double amountLT,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdBefore,
            @RequestParam(required = false, defaultValue = "") ZonedDateTime createdAfter,
            @RequestParam(required = false, defaultValue = "") Long groupId) {
        TransactionFilter filter = new TransactionFilter(name, description, amountGT, amountLT, createdBefore, createdAfter, groupId);


        return this.service.sum(filter);
    }
}
