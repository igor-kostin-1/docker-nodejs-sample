package com.vegait.expensetracker.mapper;

import com.vegait.expensetracker.dto.BlogDTO;
import com.vegait.expensetracker.dto.StrapiBlogResponseDTO;
import com.vegait.expensetracker.model.blog.Blog;
import com.vegait.expensetracker.model.blog.StrapiBlogResponse;
import com.vegait.expensetracker.model.blog.StrapiSingleBlogResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.stream.Collectors;

@Service
public class StrapiBlogResponseMapper {
    @Value("${strapi.url}")
    private String strapiUrl;


    public StrapiBlogResponseDTO map(StrapiBlogResponse r) {
        return StrapiBlogResponseDTO.builder()
                .content(r.getData().stream().map(
                                b -> BlogDTO.builder()
                                        .id(b.getId())
                                        .title(b.getAttributes().getTitle())
                                        .summary(b.getAttributes().getSummary())
                                        .content(b.getAttributes().getContent())
                                        .imageUrl(this.strapiUrl + b.getAttributes().getImg().getData().getAttributes().getUrl())
                                        .build())
                        .collect(Collectors.toList()))
                .pagination(r.getMeta().getPagination())
                .build();
    }

    public StrapiBlogResponseDTO map(StrapiSingleBlogResponse r) {
        Blog b = r.getData();
        return StrapiBlogResponseDTO.builder()
                .content(
                        Arrays.asList(BlogDTO.builder()
                                .id(b.getId())
                                .title(b.getAttributes().getTitle())
                                .summary(b.getAttributes().getSummary())
                                .content(b.getAttributes().getContent())
                                .imageUrl(this.strapiUrl + b.getAttributes().getImg().getData().getAttributes().getUrl())
                                .build()))
                .pagination(r.getMeta().getPagination())
                .build();
    }
}
