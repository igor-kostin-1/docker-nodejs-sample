package com.vegait.expensetracker.repository.common;

import com.querydsl.core.types.Predicate;
import com.vegait.expensetracker.dto.projection.TransactionProjection;
import jakarta.persistence.EntityManager;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Collection;
import java.util.Optional;

@NoRepositoryBean
public interface TransactionRepository<T, T_ID, T_USER_ID> extends JpaRepository<T, T_ID>, QuerydslPredicateExecutor<T> {
    Page<TransactionProjection> findAllByUserId(Pageable pageable, T_USER_ID user_id);

    Collection<T> findByUserId(T_USER_ID user_id);

    Optional<T> findFirstByIdAndUserId(T_ID id, T_USER_ID user_id);

    Page<TransactionProjection> findAllProjectedBy(Predicate predicate, Pageable pageable);

    default Double sum(Predicate predicate, EntityManager entityManager){
        throw new NotImplementedException();
    }
}
