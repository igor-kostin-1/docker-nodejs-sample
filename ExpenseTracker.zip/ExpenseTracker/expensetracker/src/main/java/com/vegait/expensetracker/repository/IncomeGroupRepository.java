package com.vegait.expensetracker.repository;

import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.repository.common.TransactionGroupRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncomeGroupRepository extends TransactionGroupRepository<IncomeGroup, Long, Long> {
}
