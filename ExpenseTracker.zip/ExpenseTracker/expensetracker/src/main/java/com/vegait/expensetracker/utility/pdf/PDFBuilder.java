package com.vegait.expensetracker.utility.pdf;

import com.itextpdf.awt.DefaultFontMapper;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import org.jfree.chart.JFreeChart;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;

/**
 * A builder class for creating PDF documents.
 */
public class PDFBuilder {
    private final Document pdf;
    private final ByteArrayOutputStream byteArrayOutputStream;
    private final PdfWriter writer;
    private int page;

    /**
     * Constructs a new PDFBuilder instance.
     * @throws DocumentException if there is an error in creating the PDF document.
     */
    private PDFBuilder() throws DocumentException {
        this.pdf = new Document(PageSize.LETTER, 50f, 50f, 50f, 50f);
        this.page = 0;
        this.byteArrayOutputStream = new ByteArrayOutputStream();
        this.writer = PdfWriter.getInstance(pdf, byteArrayOutputStream);
        this.pdf.open();
    }

    /**
     * Creates a new instance of PDFBuilder.
     * @return A new PDFBuilder instance.
     * @throws DocumentException if there is an error in creating the PDF document.
     */
    public static PDFBuilder create() throws DocumentException {
        return new PDFBuilder();
    }

    /**
     * Adds a new page to the PDF document.
     * @return This PDFBuilder instance.
     */
    public PDFBuilder withPage() {
        this.pdf.newPage();
        this.page++;
        return this;
    }

    /**
     * Sets spacing before the next element in the PDF document.
     * @param spacing The spacing value.
     * @return This PDFBuilder instance.
     * @throws DocumentException if there is an error in setting the spacing.
     */
    public PDFBuilder withSpacing(float spacing) throws DocumentException {
        Paragraph p = new Paragraph("");
        p.setSpacingBefore(spacing);
        this.pdf.add(p);
        return this;
    }

    /**
     * Adds a title to the PDF document.
     * @param title The title text.
     * @return This PDFBuilder instance.
     * @throws DocumentException if there is an error in adding the title.
     */
    public PDFBuilder withTitle(String title) throws DocumentException {
        Paragraph p = new Paragraph(title, FontFactory.getFont(FontFactory.COURIER, 25, Font.BOLD));
        p.setAlignment(Element.ALIGN_CENTER);
        p.setSpacingAfter(50f);
        this.pdf.add(p);
        return this;
    }

    /**
     * Adds a paragraph to the PDF document.
     * @param text The paragraph text.
     * @return This PDFBuilder instance.
     * @throws DocumentException if there is an error in adding the paragraph.
     */
    public PDFBuilder withParagraph(String text) throws DocumentException {
        pdf.add(new Paragraph(text));
        return this;
    }

    /**
     * Adds a chapter to the PDF document.
     * @param chapter The chapter to add.
     * @return This PDFBuilder instance.
     * @throws DocumentException if there is an error in adding the chapter.
     */
    public PDFBuilder withChapter(Chapter chapter) throws DocumentException {
        pdf.add(chapter);
        return this;
    }

    /**
     * Adds a chart to the PDF document.
     * @param chart The chart to add.
     * @return This PDFBuilder instance.
     */
    public PDFBuilder withChart(JFreeChart chart) {
        PdfContentByte contentByte = writer.getDirectContent();
        // Calculate the position to center the chart
        float width = PageSize.LETTER.getWidth();
        float height = PageSize.LETTER.getHeight() * 2 / 3;
        float x = (PageSize.LETTER.getWidth() - width) / 2;
        float y = (PageSize.LETTER.getHeight() - height) / 2;
        // Create the template
        PdfTemplate template = contentByte.createTemplate(width, height);
        Graphics2D graphics2d = template.createGraphics(width, height, new DefaultFontMapper());
        Rectangle2D rectangle2d = new Rectangle2D.Double(0, 0, width, height);
        // Draw the chart on the template
        chart.draw(graphics2d, rectangle2d);
        // Dispose of resources
        graphics2d.dispose();
        // Add the template to the page at the centered position
        contentByte.addTemplate(template, x, y);
        return this;
    }

    /**
     * Adds an element to the PDF document.
     * @param e The element to add.
     * @return This PDFBuilder instance.
     * @throws DocumentException if there is an error in adding the element.
     */
    public PDFBuilder withElement(Element e) throws DocumentException {
        pdf.add(e);
        return this;
    }

    /**
     * Builds the PDF document.
     * @return The PDF document.
     */
    public Document build() {
        if (this.pdf.isOpen()) this.pdf.close();
        return this.pdf;
    }

    /**
     * Retrieves the bytes of the PDF document.
     * @return The bytes of the PDF document.
     */
    public byte[] getBytes() {
        if (this.pdf.isOpen()) this.pdf.close();
        return this.byteArrayOutputStream.toByteArray();
    }
}