package com.vegait.expensetracker.utility.pdf;

import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;

/**
 * A builder class for creating indented lists in PDF documents.
 */
public class IndentedListBuilder {
    private final List topLevelList;
    private final ListItem currentItem;

    private final Font topLevelFont;
    private final Font bottomLevelFont;

    private final float topLevelSpacingBefore;
    private final float topLevelSpacingAfter;

    private final float bottomLevelSpacingBefore;
    private final float bottomLevelSpacingAfter;

    private final String titleIdentSymbol;
    private final String itemIdentSymbol;

    /**
     * Constructs a new IndentedListBuilder instance.
     */
    private IndentedListBuilder() {
        topLevelList = new List(List.UNORDERED);
        topLevelList.setListSymbol("•");
        currentItem = new ListItem();

        topLevelFont = FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD);
        bottomLevelFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL);

        topLevelSpacingBefore = 6;
        topLevelSpacingAfter = 2;

        bottomLevelSpacingBefore = 2;
        bottomLevelSpacingAfter = 1;

        this.titleIdentSymbol = "- ";
        this.itemIdentSymbol = "• ";
    }

    /**
     * Creates a new instance of IndentedListBuilder.
     *
     * @return A new IndentedListBuilder instance.
     */
    public static IndentedListBuilder create() {
        return new IndentedListBuilder();
    }

    /**
     * Adds a title to the list.
     *
     * @param text The title text to add.
     * @return This IndentedListBuilder instance.
     */
    public IndentedListBuilder withTitle(String text) {
        Paragraph p = new Paragraph(this.titleIdentSymbol + text, topLevelFont);
        p.setSpacingBefore(topLevelSpacingBefore);
        p.setSpacingAfter(topLevelSpacingAfter);
        currentItem.add(p);
        return this;
    }

    /**
     * Adds an item to the list.
     *
     * @param text The item text to add.
     * @return This IndentedListBuilder instance.
     */
    public IndentedListBuilder withItem(String text) {
        Paragraph p = new Paragraph(this.itemIdentSymbol + text, bottomLevelFont);
        p.setSpacingBefore(bottomLevelSpacingBefore);
        p.setSpacingAfter(bottomLevelSpacingAfter);
        currentItem.add(p);
        return this;
    }

    /**
     * Adds a nested list to the current item.
     *
     * @param list The nested list to add.
     * @return This IndentedListBuilder instance.
     */
    public IndentedListBuilder withInnerList(List list) {
        this.currentItem.add(list);
        return this;
    }

    /**
     * Builds the indented list.
     *
     * @return The built indented list.
     */
    public List build() {
        this.topLevelList.add(currentItem);
        return this.topLevelList;
    }
}