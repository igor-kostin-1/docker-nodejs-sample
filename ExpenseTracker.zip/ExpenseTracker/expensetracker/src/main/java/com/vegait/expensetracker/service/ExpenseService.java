package com.vegait.expensetracker.service;

import com.vegait.expensetracker.dto.projection.TransactionProjection;
import com.vegait.expensetracker.model.Expense;
import com.vegait.expensetracker.model.ExpenseGroup;
import com.vegait.expensetracker.model.filter.TransactionFilter;
import com.vegait.expensetracker.repository.common.TransactionRepository;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.security.service.UserDetailsImpl;
import com.vegait.expensetracker.service.common.TransactionGroupService;
import com.vegait.expensetracker.service.common.TransactionService;
import jakarta.persistence.EntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService extends TransactionService<Expense, Long, Long, ExpenseGroup, Long> {
    private final EntityManager entityManager;

    public ExpenseService(final TransactionRepository<Expense, Long, Long> repository,
                          final UserRepository userRepository,
                          final TransactionGroupService<ExpenseGroup, Long, Long> groupRepository,
                          final EntityManager entityManager) {
        super(repository, userRepository, groupRepository);
        this.entityManager = entityManager;
    }

    @Override
    public Double sum(TransactionFilter filter) {

        UserDetailsImpl<Long> userDetails = this.getUserDetails();

        return this.repository.sum(filter.buildExpenseFilter(userDetails.getId()), entityManager);
    }


    @Override
    public Page<TransactionProjection> findAll(Pageable pageable, TransactionFilter filter) {
        UserDetailsImpl<Long> userDetails = this.getUserDetails();

        return this.repository.findBy(
                filter.buildExpenseFilter(userDetails.getId()),
                q -> q.as(TransactionProjection.class).page(pageable)
        );
    }

    @Override
    public List<TransactionProjection> findAll(TransactionFilter filter) {
        UserDetailsImpl<Long> userDetails = this.getUserDetails();

        return this.findAll(filter, userDetails.getId());
    }

    @Override
    public List<TransactionProjection> findAll(TransactionFilter filter, Long user_id) {
        return this.repository.findBy(
                filter.buildExpenseFilter(user_id),
                q -> q.as(TransactionProjection.class).all()
        );
    }
}