package com.vegait.expensetracker.service.common;

import com.vegait.expensetracker.error.EntityDontExit;
import com.vegait.expensetracker.error.MissingUser;
import com.vegait.expensetracker.security.service.UserDetailsImpl;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

/**
 * ICRUDService is an interface representing a generic CRUD (Create, Read, Update, Delete) service.
 *
 * @param <T>         The type of the entity managed by the service.
 * @param <T_ID>      The type of the entity's identifier.
 * @param <T_USER_ID> The type of the user identifier associated with the entity.
 */
public interface ICRUDService<T, T_ID, T_USER_ID> {

    /**
     * Retrieves all entities.
     *
     * @return A list containing all entities.
     */
    List<T> findAll();

    /**
     * Retrieves an entity by its identifier.
     *
     * @param id The identifier of the entity to retrieve.
     * @return The entity with the specified identifier, or null if not found.
     */
    T findById(T_ID id);

    /**
     * Saves a new entity.
     *
     * @param entity The entity to be saved.
     * @return The saved entity.
     * @throws MissingUser If the user associated with the entity is missing.
     */
    T save(T entity);

    /**
     * Updates an existing entity.
     *
     * @param entity The entity to be updated.
     * @return The updated entity.
     * @throws EntityDontExit If the entity does not exist.
     */
    T update(T entity);

    /**
     * Deletes an entity by its identifier.
     *
     * @param id The identifier of the entity to delete.
     * @throws EntityDontExit If the entity does not exist.
     */
    void delete(T_ID id);

    /**
     * Retrieves the details of the currently authenticated user.
     *
     * @return An instance of UserDetailsImpl representing the details of the authenticated user.
     */
    default UserDetailsImpl<T_USER_ID> getUserDetails() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return null;
        return (UserDetailsImpl<T_USER_ID>) auth.getPrincipal();
    }
}
