package com.vegait.expensetracker.model;

import com.vegait.expensetracker.model.common.IAuditEntity;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.model.common.ITransaction;
import com.vegait.expensetracker.model.common.IUserOwned;
import com.vegait.expensetracker.security.model.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "income")
public class Income implements IUserOwned, IEntityObject<Long>, ITransaction<IncomeGroup>, IAuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Income: Invalid Name: Empty name")
    @NotNull(message = "Income: Invalid Name: Name is NULL")
    private String name;

    @Column(length = 3000)
    private String description;

    @NotNull(message = "Income: Invalid Amount: Amount is NULL")
    @Min(value = 0, message ="Expense: Invalid Amount: Amount les than zero")
    private Double amount;

    private ZonedDateTime created;
    private ZonedDateTime lastUpdate;

    @NotNull(message = "Income: Invalid Group: Group is NULL")
    @ManyToOne
    @JoinColumn(name = "group_id", nullable = false)
    private IncomeGroup group;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // TODO: Delete before release, inflation data constructor
    public Income(long l, String s, String s1, double v, IncomeGroup freelancing, ZonedDateTime januaryDate) {
        this.name = s;
        this.description = s1;
        this.amount = v;
        this.group = freelancing;
        this.created = januaryDate;
    }

    @PrePersist
    private void prePersist() {
        this.onPrePersist();
    }

    @PreUpdate
    private void preUpdate() {
        this.onPreUpdate();
    }
}
