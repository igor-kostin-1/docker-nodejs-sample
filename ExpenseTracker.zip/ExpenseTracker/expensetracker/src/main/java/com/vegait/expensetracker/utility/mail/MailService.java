package com.vegait.expensetracker.utility.mail;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class MailService {

    @Value("${spring.mail.username}")
    String from;
    private JavaMailSender emailSender;

    public MailService(JavaMailSender emailSender) {
        this.emailSender = emailSender;
    }

    public void sendMail() {
        log.info("Sending mail");
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom("expensetrackingsystem8@gmail.com");
        msg.setTo("kostiigi@gmail.com");
        msg.setSubject("test");
        msg.setText("test");

        this.emailSender.send(msg);
        log.info("Mail sent");
    }

    public void sendMail(byte[] data) {
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        try {
            MimeMessage message = emailSender.createMimeMessage();

            // Enable multipart mode
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            // Set basic email parameters
            helper.setTo("kostiigi@gmail.com");
            helper.setSubject("test");
            helper.setText("test");


            // Attach the PDF file
            ByteArrayResource pdfAttachment = new ByteArrayResource(data);
            helper.addAttachment("UserMonthlyReport.pdf", pdfAttachment);

            // Send email
            emailSender.send(message);
        } catch (MessagingException e) {
            // Handle exception
        }
    }

    public EmailMessageBuilder compose() throws MessagingException {
        return EmailMessageBuilder.create(this.emailSender, this.from);
    }
}
