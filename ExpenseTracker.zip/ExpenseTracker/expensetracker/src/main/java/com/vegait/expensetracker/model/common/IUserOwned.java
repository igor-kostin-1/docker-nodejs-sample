package com.vegait.expensetracker.model.common;

import com.vegait.expensetracker.security.model.User;


/**
 * IUserOwned is an interface representing an entity owned by a user.
 * Implementing classes provide methods to retrieve and set the user associated with the entity.
 */
public interface IUserOwned {

    /**
     * Retrieves the user associated with the entity.
     *
     * @return The user associated with the entity.
     */
    User getUser();

    /**
     * Sets the user associated with the entity.
     *
     * @param user The user to associate with the entity.
     */
    void setUser(User user);
}
