package com.vegait.expensetracker.dto;

import com.vegait.expensetracker.model.blog.Pagination;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StrapiBlogResponseDTO {
    private List<BlogDTO> content;
    private Pagination pagination;
}
