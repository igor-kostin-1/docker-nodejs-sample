package com.vegait.expensetracker.utility.database;

public class DisableOnPresist {
    public static boolean disabled = false;
}
