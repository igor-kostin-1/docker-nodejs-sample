package com.vegait.expensetracker.service.common;

import com.vegait.expensetracker.model.blog.StrapiBlogResponse;
import com.vegait.expensetracker.model.blog.StrapiSingleBlogResponse;
import org.springframework.data.domain.Pageable;

public interface IContentManagerService {
    StrapiBlogResponse getAll(Pageable pageable);

    StrapiSingleBlogResponse getById(int id);
}
