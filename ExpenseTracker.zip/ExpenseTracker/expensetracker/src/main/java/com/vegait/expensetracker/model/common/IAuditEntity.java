package com.vegait.expensetracker.model.common;

import com.vegait.expensetracker.utility.database.DisableOnPresist;

import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.TimeZone;

/**
 * IAuditEntity is an interface representing an entity with audit-related functionality.
 * Implementing classes provide methods to handle pre-persistence and pre-update events for auditing purposes.
 */
public interface IAuditEntity {
    // TODO: Database inflation utility, shout be removed before production


    /**
     * Sets the created and last update timestamps to the current date and time during pre-persistence.
     */
    default void onPrePersist() {
        if(IAuditEntity.disableOnPrePersist()) return;
        SimpleDateFormat sdf = new SimpleDateFormat(this.format());
        sdf.setTimeZone(TimeZone.getTimeZone(this.zone()));
        ZonedDateTime date = ZonedDateTime.parse(sdf.format(new Date()));
        this.setCreated(date);
        this.setLastUpdate(date);
    }

    static boolean disableOnPrePersist() {
        return DisableOnPresist.disabled;
    }

    /**
     * Sets the last update timestamp to the current date and time during pre-update.
     */
    default void onPreUpdate() {
        SimpleDateFormat sdf = new SimpleDateFormat(this.format());
        sdf.setTimeZone(TimeZone.getTimeZone(this.zone()));
        ZonedDateTime date = ZonedDateTime.parse(sdf.format(new Date()));
        this.setLastUpdate(date);
    }

    /**
     * Specifies the date and time format used for auditing purposes.
     *
     * @return The date and time format string.
     */
    default String format() {
        return "yyyy-MM-dd'T'HH:mm:ss'Z'";
    }

    /**
     * Specifies the time zone used for auditing purposes.
     *
     * @return The time zone string.
     */
    default String zone() {
        return "UTC";
    }

    /**
     * Sets the created timestamp.
     *
     * @param d The created timestamp.
     */
    void setCreated(ZonedDateTime d);

    void setLastUpdate(ZonedDateTime d);
}
