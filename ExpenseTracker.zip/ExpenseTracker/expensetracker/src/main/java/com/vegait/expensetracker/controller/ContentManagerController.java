package com.vegait.expensetracker.controller;

import com.vegait.expensetracker.dto.StrapiBlogResponseDTO;
import com.vegait.expensetracker.mapper.StrapiBlogResponseMapper;
import com.vegait.expensetracker.model.blog.StrapiSingleBlogResponse;
import com.vegait.expensetracker.service.common.IContentManagerService;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/content")
public class ContentManagerController {

    private final IContentManagerService service;
    private final StrapiBlogResponseMapper mapper;

    public ContentManagerController(IContentManagerService service, StrapiBlogResponseMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @GetMapping("/blogs")
    public StrapiBlogResponseDTO blogs(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "25") int size
    ){
        return mapper.map(this.service.getAll(PageRequest.of(page, size)));
    }

    @GetMapping("/blog/{id}")
    public StrapiBlogResponseDTO blog(
            @PathVariable int id
    ){
        return mapper.map(this.service.getById(id));
    }
}
