package com.vegait.expensetracker.service;

import com.vegait.expensetracker.model.IncomeGroup;
import com.vegait.expensetracker.repository.common.TransactionGroupRepository;
import com.vegait.expensetracker.security.repository.UserRepository;
import com.vegait.expensetracker.service.common.TransactionGroupService;
import org.springframework.stereotype.Service;

@Service
public class IncomeGroupService extends TransactionGroupService<IncomeGroup, Long, Long> {
    public IncomeGroupService(final TransactionGroupRepository<IncomeGroup, Long, Long> repository, UserRepository userRepository) {
        super(repository, userRepository);
    }
}
