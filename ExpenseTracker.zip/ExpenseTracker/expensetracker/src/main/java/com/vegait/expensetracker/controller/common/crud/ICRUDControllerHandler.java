package com.vegait.expensetracker.controller.common.crud;

import com.vegait.expensetracker.model.common.IEntityObject;
import org.springframework.http.ResponseEntity;

/**
 * ICRUDControllerHandler is an interface defining handling methods for common CRUD operations
 *
 * @param <T_DTO> The DTO type representing the entity.
 * @param <T_ID>  The type of the entity's identifier.
 */
public interface ICRUDControllerHandler<T_DTO extends IEntityObject<T_ID>, T_ID> {

    /**
     * Retrieves all entities.
     *
     * @return A ResponseEntity containing an iterable collection of DTOs representing the entities.
     */
    ResponseEntity<Iterable<T_DTO>> findAll();

    /**
     * Retrieves an entity by its identifier.
     *
     * @param id The identifier of the entity to retrieve.
     * @return A ResponseEntity containing the DTO representing the entity, if found.
     */
    ResponseEntity<T_DTO> findById(T_ID id);

    /**
     * Saves a new entity.
     *
     * @param entity The DTO representing the new entity to save.
     * @return A ResponseEntity containing the DTO representing the created entity.
     */
    ResponseEntity<T_DTO> save(T_DTO entity);

    /**
     * Updates an existing entity.
     *
     * @param entity The DTO containing the updated information for the entity.
     * @return A ResponseEntity containing the DTO representing the updated entity.
     */
    ResponseEntity<T_DTO> update(T_ID id, T_DTO dto);

    /**
     * Deletes an entity by its identifier.
     *
     * @param id The identifier of the entity to delete.
     * @return A ResponseEntity indicating the success or failure of the deletion operation.
     */
    ResponseEntity<Void> delete(T_ID id);
}
