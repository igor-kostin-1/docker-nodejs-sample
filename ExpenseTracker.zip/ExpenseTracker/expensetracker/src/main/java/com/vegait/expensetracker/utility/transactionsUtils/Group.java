package com.vegait.expensetracker.utility.transactionsUtils;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Represents a group holder containing data from  {@link com.vegait.expensetracker.model.ExpenseGroup}/{@link com.vegait.expensetracker.model.IncomeGroup} entity.
 */
@Data
@AllArgsConstructor
public class Group {
    private Long id;
    private String name;

}
