package com.vegait.expensetracker.utility.mail;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class EmailMessageBuilder {
    MimeMessage message;
    MimeMessageHelper helper;

    JavaMailSender javaMailSender;

    private LinkedList<String> texts = new LinkedList<>();

    private String title = "Email from Expense tracking system";
    private String footer = "Best regards, from Expense tracking system team !!!";

    private EmailMessageBuilder(JavaMailSender javaMailSender, String from) throws MessagingException {
        this.javaMailSender = javaMailSender;
        this.message = javaMailSender.createMimeMessage();
        this.helper = new MimeMessageHelper(message, true);

        // Default configuration
//        this.helper.setFrom(from);
    }

    public static EmailMessageBuilder create(JavaMailSender javaMailSender, String from) throws MessagingException {
        return new EmailMessageBuilder(javaMailSender, from);
    }

    public EmailMessageBuilder to(String to) throws MessagingException {
        helper.setTo(to);
        return this;
    }

    public EmailMessageBuilder withSubject(String subject) throws MessagingException {
        helper.setSubject(subject);
        return this;
    }
    public EmailMessageBuilder withTitle(String text) throws MessagingException {
        this.title = text;
        return this;
    }


    public EmailMessageBuilder withText(String text) throws MessagingException {
        this.texts.add(text);
        return this;
    }

    public EmailMessageBuilder withFooter(String text) throws MessagingException {
        this.footer = text;
        return this;
    }

    public EmailMessageBuilder withAttachment(byte[] bytes, String fileName) throws MessagingException {
        helper.addAttachment(fileName, new ByteArrayResource(bytes));
        return this;
    }

    public void send() throws MessagingException {
        this.texts.addFirst(this.title);
        this.texts.addLast(this.footer);

        helper.setText(formatStrings(this.texts));
        javaMailSender.send(message);
    }

    public static String formatStrings(List<String> strings) {
        StringBuilder formattedString = new StringBuilder();

        // Append each string with new lines and extra spacing
        for (int i = 0; i < strings.size(); i++) {
            String str = strings.get(i);
            formattedString.append(str);

            // Append two new lines after the first and second strings
            if (i == 0 || i == 1) {
                formattedString.append("\n\n");
            }

            // Append a new line after all strings except the last one
            if (i < strings.size() - 1) {
                formattedString.append("\n");
            }
        }

        // Append two new lines before the last string
        if (!strings.isEmpty()) {
            formattedString.append("\n\n");
        }

        return formattedString.toString();
    }
}
