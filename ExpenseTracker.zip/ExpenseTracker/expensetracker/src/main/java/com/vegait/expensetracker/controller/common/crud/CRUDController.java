package com.vegait.expensetracker.controller.common.crud;

import com.vegait.expensetracker.mapper.common.ICollectionMapper;
import com.vegait.expensetracker.mapper.common.IEntityMapper;
import com.vegait.expensetracker.model.common.IEntityObject;
import com.vegait.expensetracker.service.common.ICRUDService;
import org.springframework.http.ResponseEntity;

/**
 * CRUDController is an abstract class that provides basic CRUD operations for entities
 * through HTTP requests. It serves as a generic controller for handling common CRUD
 * operations such as creating, reading, updating, and deleting entities.
 *
 * @param <T>         The type of entity managed by the controller.
 * @param <T_DTO>     The DTO (Data Transfer Object) type representing the entity.
 * @param <T_ID>      The type of the entity's identifier.
 * @param <T_USER_ID> The type of the user identifier associated with the entity.
 */
public abstract class CRUDController<T extends IEntityObject<T_ID>, T_DTO extends IEntityObject<T_ID>, T_ID, T_USER_ID> implements ICRUDController<T, T_DTO, T_ID> , ILoggable {

    protected final ICRUDService<T, T_ID, T_USER_ID> service;
    protected final IEntityMapper<T, T_DTO> mapper;
    protected final ICollectionMapper<T, T_DTO> collectionMapper;

    protected final ICRUDControllerHandler<T_DTO, T_ID> handler;

    /**
     * Constructor for the CRUDController class.
     *
     * @param service          The service responsible for handling CRUD operations.
     * @param mapper           The mapper used for mapping entities to DTOs and vice versa.
     * @param collectionMapper The mapper used for mapping collections of entities to DTOs and vice versa.
     * @param handler          The handler for executing CRUD operations.
     */
    public CRUDController(final ICRUDService<T, T_ID, T_USER_ID> service,
                          final IEntityMapper<T, T_DTO> mapper,
                          final ICollectionMapper<T, T_DTO> collectionMapper,
                          final ICRUDControllerHandler<T_DTO, T_ID> handler) {
        this.service = service;
        this.mapper = mapper;
        this.collectionMapper = collectionMapper;
        this.handler = handler;
    }

    /**
     * Retrieve all entities.
     *
     * @return A ResponseEntity containing a collection of DTOs representing the entities.
     */
    @Override
    public ResponseEntity<Iterable<T_DTO>> findAll() {
        return this.handler.findAll();
    }

    /**
     * Retrieve an entity by its identifier.
     *
     * @param id The identifier of the entity to retrieve.
     * @return A ResponseEntity containing the DTO representing the entity, if found.
     */
    @Override
    public ResponseEntity<T_DTO> findById(final T_ID id) {
        return this.handler.findById(id);
    }

    /**
     * Create a new entity.
     *
     * @param dto The DTO representing the new entity to create.
     * @return A ResponseEntity containing the DTO representing the created entity.
     */
    @Override
    public ResponseEntity<T_DTO> save(final T_DTO dto) {
        return this.handler.save(dto);
    }

    /**
     * Update an existing entity.
     *
     * @param dto The DTO containing the updated information for the entity.
     * @return A ResponseEntity containing the DTO representing the updated entity.
     */
    @Override
    public ResponseEntity<T_DTO> update(final T_ID id, final T_DTO dto) {
        return this.handler.update(id, dto);
    }

    /**
     * Delete an entity by its identifier.
     *
     * @param id The identifier of the entity to delete.
     * @return A ResponseEntity indicating the success or failure of the deletion operation.
     */
    @Override
    public ResponseEntity<Void> delete(final T_ID id) {
        return this.handler.delete(id);
    }
}
