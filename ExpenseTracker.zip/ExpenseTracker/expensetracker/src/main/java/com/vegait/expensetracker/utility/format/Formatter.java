package com.vegait.expensetracker.utility.format;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Utility class for formatting dates and numbers.
 */
public class Formatter {
    static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMMM d, uuuu 'at' HH:mm:ss", Locale.ENGLISH);
    static  NumberFormat numberFormatter = new DecimalFormat("#,##0.00");


    /**
     * Formats a ZonedDateTime object into a string representation.
     * @param time The ZonedDateTime object to format.
     * @return A formatted string representing the input ZonedDateTime object.
     * <p>
     * Example:
     *  input: 2024-01-02T13:50:54.851Z
     *  output: January 2,2024 at13:50:54
     */
    public static String time(ZonedDateTime time) {
        return dateFormatter.format(time);
    }

    /**
     * Formats a double number with a thousand separators and two decimal places.
     * @param number The number to format.
     * @return A formatted string representation of the input number.
     * <p>
     * Example:
     *  input = 1234567.89;
     *  output: "1 234 567.89"
     */
    public static String number(double number) {
        String formattedNumber = numberFormatter.format(number);
        return formattedNumber.replace(",", " ");
    }

}
