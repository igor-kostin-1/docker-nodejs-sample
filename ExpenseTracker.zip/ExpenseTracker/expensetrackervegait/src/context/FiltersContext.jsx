import React, { createContext, useContext, useState } from 'react'

const FiltersContext = createContext()

export const FiltersProvider = ({ children }) => {
  const [size, setSize] = useState(5)
  const [name, setName] = useState('')
  const [amountGT, setAmountGT] = useState('')
  const [amountLT, setAmountLT] = useState('')

  

  return (
    <FiltersContext.Provider
      value={{
        size,
        setSize,
        name,
        setName,
        amountGT,
        setAmountGT,
        amountLT,
        setAmountLT,
  
      }}
    >
      {children}
    </FiltersContext.Provider>
  )
}

export const useFilters = () => useContext(FiltersContext)
