import { Route, Routes } from 'react-router-dom'
import LoginPage from './pages/loginPage/LoginPage'
import DashboardPage from './pages/dashboardPage/DashboardPage'
import BlogPage from './pages/blogPage/BlogPage'
import CreateNewUserPage from './pages/createNewUser/CreateNewUserPage'
import { Toaster } from 'react-hot-toast'
import { useAuth } from './context/AuthContext'
import PageNotFound from './pages/pageNotFound/PageNotFound'
import NavbarComponent from './components/Navbar/NavbarComponent.jsx'
import PrivateRoutes from './components/PrivateRoutes/PrivateRoutes.jsx'
import TransactionsPage from './pages/TransactionsPage/TransactionsPage.jsx'
import TransactionsGroupPage from './pages/TransactionGroupsPage/TransactionsGroupPage.jsx'
import BlogDetails from './pages/BlogDetails.jsx'
function App() {
  const { user } = useAuth()
  return (
    <>
      {user && <NavbarComponent />}
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/create-new-account" element={<CreateNewUserPage />} />
        <Route
          path="dashboard"
          element={
            <PrivateRoutes>
              <DashboardPage />
            </PrivateRoutes>
          }
        />
        <Route
          path="transactions"
          element={
            <PrivateRoutes>
              <TransactionsPage />
            </PrivateRoutes>
          }
        />
        <Route
          path="blog"
          element={
            <PrivateRoutes>
              <BlogPage />
            </PrivateRoutes>
          }
        />
        <Route
          path="blog/:id"
          element={
            <PrivateRoutes>
              <BlogDetails />
            </PrivateRoutes>
          }
        />

        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="transactions-groups" element={<TransactionsGroupPage />} />
        <Route path="blog" element={<BlogPage />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
      <Toaster
        position="top-center"
        gutter={12}
        containerStyle={{ margin: '8px' }}
        toastOptions={{
          success: {
            duration: 3000,
            error: {
              duration: 5000,
            },
            style: {
              fontSize: '16px',
              maxWidth: '500px',
              padding: '16px 24px',
              backgroundColor: '#fff',
              color: 'black',
            },
          },
        }}
      />
    </>
  )
}

export default App
