import React from 'react'
import { useAuth } from '../context/AuthContext'
import useFetch from '../hooks/useFetch'
import { Navigate, useParams } from 'react-router-dom'
import { Col, Container, Row } from 'react-bootstrap'
import Loader from '../components/Loader/Loader'

const BlogDetails = () => {
  const { user } = useAuth()
  const { id } = useParams()

  const {
    data: blogDetail,
    isLoading,
    error: blogError,
  } = useFetch(`/content/blog/${id}`)
  const isPremiumUser = user && user.roles.includes('ROLE_PREMIUM_USER')
  if (!isPremiumUser) return <Navigate to="/dashboard" replace />
  if(isLoading) return <Loader/>
  return (
    <Container className="mt-5">
    <Row>
      <Col className="text-center">
        <h1 className="mb-5">{blogDetail.content[0].title}</h1>
        <img
          src={blogDetail.content[0].imageUrl}
          alt={blogDetail.content[0].title}
          className="img-fluid mb-5 w-50"
        />
      </Col>
    </Row>
    <Row>
      <Col className="text-center">
        <p>{blogDetail.content[0].content}</p>
      </Col>
    </Row>
  </Container>
  )
}

export default BlogDetails
