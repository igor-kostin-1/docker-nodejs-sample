import { Card, Col, Container, Row } from 'react-bootstrap'
import { useAuth } from '../../context/AuthContext'
import { Navigate, useNavigate, } from 'react-router-dom'
import useFetch from '../../hooks/useFetch'
import Loader from '../../components/Loader/Loader'
import ErrorPage from '../errorPage/ErrorPage'
import styles from './BlogPage.module.css'
const BlogPage = () => {
  const { user } = useAuth()
  const { data: blogs, isLoading, error:blogError } = useFetch('/content/blogs')
const navigate=useNavigate()
  const handleBlogDetails=(blogId)=>{
    navigate(`/blog/${blogId}`)
  }

  const isPremiumUser = user && user.roles.includes('ROLE_PREMIUM_USER')
  if (!isPremiumUser) return <Navigate to="/dashboard" replace />
  if (isLoading) return <Loader />
  if (blogError) return <ErrorPage blogError={blogError}/>
  return (
    <Container className="mt-5">
      <Row xs={1} sm={2} md={2} lg={4} xl={4} xxl={4} className="g-4">
        {blogs.content.map((blog) => (
          <Col key={blog.id}>
            <Card onClick={()=>handleBlogDetails(blog.id)} className={`h-100 ${styles.pointer} ${styles.scale}  `} >
            <Card.Img  variant="top" src={blog.imageUrl} alt={blog.title} />
              <Card.Body>
                <Card.Title>{blog.title}</Card.Title>
                <Card.Text>{blog.summary}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  )
}

export default BlogPage
