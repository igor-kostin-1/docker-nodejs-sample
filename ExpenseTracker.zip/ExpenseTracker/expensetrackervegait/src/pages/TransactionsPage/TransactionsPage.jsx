import { useState } from 'react'
import { Button, Col, Container, Row } from 'react-bootstrap'
import TransactionsComponent from '../../components/TransactionsComponent/TransactionsComponent'
import AddTransactionForm from '../../components/AddTransactionForm/AddTransactionForm'
import useFetch from '../../hooks/useFetch'
import Filters from '../../components/Filters/Filters'
import { useFilters } from '../../context/FiltersContext'
import PaginationComponent from '../../components/PaginationComponent/PaginationComponent'
import { useDebounce } from '../../hooks/useDebounce'

const TransactionsPage = () => {
  const [open, setOpen] = useState(false)
  const [size, setSize] = useState(5)
  const [name, setName] = useState('')
  const [amountGT, setAmountGT] = useState('')
  const [amountLT, setAmountLT] = useState('')
  const [pageNum, setPageNum] = useState(0)
  const [transactionType, setTransactionType] = useState('expense')
  const debounceName = useDebounce(name)
  const debounceAmountGT = useDebounce(amountGT)
  const debounceAmountLT = useDebounce(amountLT)
  const { data, isLoading, error, fetchData } = useFetch(
    `/${transactionType}?size=${size}&name=${debounceName}&amountGT=${debounceAmountGT}&amountLT=${debounceAmountLT}&page=${pageNum}`,
  )
  const totalPages = data && data.totalPages

  console.log(transactionType)
  return (
    <Container className="my-5">
      <Row>
        <Col>
          <h2>Transactions</h2>
          <Button
            onClick={() => setOpen(true)}
            aria-expanded={open}
            style={{ width: 'auto' }}
          >
            Add Transaction
          </Button>
          <Filters
            setAmountGT={setAmountGT}
            setAmountLT={setAmountLT}
            setName={setName}
            setSize={setSize}
          />
          {open && (
            <AddTransactionForm
              open={open}
              setOpen={setOpen}
              showButtons={true}
              handleRefetch={fetchData}
              transactionType={transactionType}
            />
          )}
          <TransactionsComponent
            transactionType={transactionType}
            setTransactionType={setTransactionType}
            data={data}
            isLoading={isLoading}
            error={error}
            fetchData={fetchData}
          />
        </Col>
        <PaginationComponent
          totalPages={totalPages}
          pageNum={pageNum}
          setPageNum={setPageNum}
        />
      </Row>
    </Container>
  )
}

export default TransactionsPage
