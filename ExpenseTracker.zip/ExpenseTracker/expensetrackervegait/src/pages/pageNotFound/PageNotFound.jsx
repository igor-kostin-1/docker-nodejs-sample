import { Button, Container } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import styles from './PageNotFound.module.css'
const PageNotFound = () => {
  const navigate = useNavigate()
  const goBack = () => {
    navigate(-1)
  }

  return (
    <div className={styles.page}>
      <Container>
        <div className={styles.content}>
          <h1>Page Not Found</h1>
          <p>The page you are looking for does not exist.</p>
          <Button
            onClick={goBack}
            style={{
              backgroundColor: 'var(--accent-color)',
              borderColor: 'var(--accent-color)',
              width: 'auto' 
            }}
          >
            Go Back
          </Button>
        </div>
      </Container>
    </div>
  )
}

export default PageNotFound
