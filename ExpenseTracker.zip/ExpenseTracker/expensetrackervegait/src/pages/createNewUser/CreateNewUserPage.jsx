import CreateNewUserForm from '../../components/CreateNewUserForm/CreateNewUserForm'
import styles from './CreateNewUser.module.css'

const CreateNewUserPage = () => {
  return (
    <div className={styles.container}>
      <CreateNewUserForm />
    </div>
  )
}

export default CreateNewUserPage
