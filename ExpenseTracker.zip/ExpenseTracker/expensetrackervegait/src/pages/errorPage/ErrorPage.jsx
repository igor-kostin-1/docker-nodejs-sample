import { Button, Container } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import styles from './ErrorPage.module.css'

const ErrorPage = ({ expensesError, incomesError,blogError }) => {
  const navigate = useNavigate()
  const { logout } = useAuth()


  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className={styles.page}>
      <Container>
        <div className={styles.content}>
          <h1>Oops! Something went wrong.</h1>
          {expensesError && <p>Error fetching expenses: {expensesError?.message}</p>}
          {incomesError && <p>Error fetching incomes: {incomesError?.message}</p>}
          {blogError && <p>Error fetching incomes: {blogError?.message}</p>}
         
          <Button
            onClick={handleLogout}
            style={{
              backgroundColor: 'var(--accent-color)',
              borderColor: 'var(--accent-color)',
              width: 'auto',
            }}
          >
            Logout
          </Button>
        </div>
      </Container>
    </div>
  )
}

export default ErrorPage