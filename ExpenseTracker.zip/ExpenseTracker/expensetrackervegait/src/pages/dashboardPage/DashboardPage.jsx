import { Button, Container } from 'react-bootstrap'
import TotalAmountCard from '../../components/TotalAmountBadge/TotalAmountCard'
import Dashboard from '../../components/dashboard/Dashboard'
import { useState } from 'react'
import AddTransactionForm from '../../components/AddTransactionForm/AddTransactionForm'
const DashboardPage = () => {

  return (
    <>
      <Container>
        <TotalAmountCard />
       
        <Dashboard />
      </Container>
    </>
  )
}

export default DashboardPage
