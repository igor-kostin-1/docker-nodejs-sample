import { Col, Container, Row } from 'react-bootstrap'
import TransactionsGroupsComponent from '../../components/TransactionsGroupComponent/TransactionsGroupsComponent'
import { useState } from 'react'

const TransactionsGroupPage = () => {
  const [transactionType, setTransactionType] = useState('expensegroup')
  return (
    <Container className="my-5">
      <Row>
        <Col>
          <h2>TransactionGroups</h2>
          <TransactionsGroupsComponent
            transactionType={transactionType}
            setTransactionType={setTransactionType}
          />
        </Col>
      </Row>
    </Container>
  )
}

export default TransactionsGroupPage
