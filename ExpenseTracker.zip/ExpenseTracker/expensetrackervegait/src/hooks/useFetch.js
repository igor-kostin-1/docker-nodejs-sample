import { useState, useEffect } from 'react'
import apiInstance from '../api/apiInstance'
const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL

const useFetch = (endpoint) => {
  const [data, setData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchData = async () => {
    setIsLoading(true)
    try {
      const response = await apiInstance.get(`${baseUrl}${endpoint}`)
      setData(response.data)
    } catch (error) {
      setError(error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [endpoint])

  return { data, isLoading, error, fetchData }
}

export default useFetch
