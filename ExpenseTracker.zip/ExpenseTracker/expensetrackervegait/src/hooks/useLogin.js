import axios from 'axios'
import { useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const useLogin = (url) => {
  const navigate = useNavigate()
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const loginUser = async (data) => {
    try {
      setIsLoading(true)
      const res = await axios.post(url, data)
      console.log(res.data)
      if (res.data.token) {
        const{token,fullName}=res.data
        toast.success(`Wellcome ${fullName}`)
        localStorage.setItem('token', token)
        login(res.data)
        navigate('/dashboard')
      }
    } catch (error) {
      toast.error(error.response.data.message)
    } finally {
      setIsLoading(false)
    }
  }
  return { isLoading, loginUser }
}

export default useLogin
