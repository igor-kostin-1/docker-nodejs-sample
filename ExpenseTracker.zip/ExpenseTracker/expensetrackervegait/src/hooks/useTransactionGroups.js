import { useState, useEffect } from 'react'
import apiInstance from '../api/apiInstance'
const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL

const useTransactionGroups = (transactionType) => {
  const [categories, setCategories] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchCategories = async () => {
      setIsLoading(true)
      try {
        const response = await apiInstance.get(
          `${baseUrl}/${transactionType}group`,
        )
        const filteredCategories = response.data.filter(
          (group) => group?.name !== null,
        )
        setCategories(filteredCategories)
      } catch (error) {
        setError(error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCategories()
  }, [transactionType])

  return { categories, isLoading, error }
}

export default useTransactionGroups
