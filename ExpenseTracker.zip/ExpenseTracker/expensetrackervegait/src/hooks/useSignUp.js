import axios from 'axios'
import { useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
const useSignup = (url) => {
  const navigate = useNavigate()
  const [isLoading, setIsLoading] = useState(false)
  const signupUser = async (data) => {
    try {
      setIsLoading(true)
      const res = await axios.post(url, data)
      console.log(res)

      if (res.status == 200) {
        toast.success('Account successfully created!')

        navigate('/login')
      }
    } catch (error) {
      toast.error(error.response.data.message)
    } finally {
      setIsLoading(false)
    }
  }
  return { isLoading, signupUser }
}
export default useSignup
