const UserRole = {

    PREMIUM_USER: 'premium_user',
    STANDARD_USER: 'standard_user',
  };
  
  export default UserRole;
