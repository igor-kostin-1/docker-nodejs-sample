import { Table } from 'react-bootstrap'
import { formatPrice } from '../../helpers/formatPrice'
import { formatDate } from '../../helpers/formatDate'
import { useState } from 'react'
import apiInstance from '../../api/apiInstance'
import toast from 'react-hot-toast'
import Loader from '../Loader/Loader'
import AddTransactionForm from '../AddTransactionForm/AddTransactionForm'

const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL

function TableGroups({
  expenses,
  incomes,
  handleRefetch,
  showButtons,
  transactionType,
}) {
  const [loading, setLoading] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [editedTransaction, setEditedTransaction] = useState(null)

  const handleDelete = async (id, type) => {
    const confirmDelete = window.confirm(
      'Are you sure you want to delete this transaction?',
    )

    if (!confirmDelete) {
      return
    }
    try {
      setLoading(true)
      await apiInstance.delete(`${baseUrl}/${type}/${id}`)
      toast.success('Transaction deleted successfully')
      handleRefetch()
    } catch (error) {
      console.error('Error deleting transaction:', error)
      toast.error('Failed to delete transaction')
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = async (id, type) => {
    try {
      setLoading(true)
      const response = await apiInstance.get(`${baseUrl}/${type}/${id}`)
      setEditedTransaction({ ...response.data, type })
      setEditMode(true)
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <Loader />

  return (
    <>
      {editMode && (
        <AddTransactionForm
          open={true}
          setOpen={setEditMode}
          transaction={editedTransaction}
          handleRefetch={handleRefetch}
          editMode={editMode}
          transactionType={transactionType}
        />
      )}
      <Table
        responsive
        striped
        bordered
        hover
        size="lg"
        className="text-center"
      >
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Group Name</th>
            <th>Created at</th>
            <th>Amount</th>
            {showButtons && <th colSpan={2}>Action</th>}
          </tr>
        </thead>
        <tbody>
          {incomes &&
            incomes.content.map((income) => (
              <tr className="align-middle text-center" key={income.id}>
                <td>{income.id}</td>
                <td>{income.name}</td>
                <td>{income.description || 'No description'}</td>
                <td>{income.groupName}</td>
                <td>{formatDate(income.created)}</td>
                <td>{formatPrice(income.amount)}</td>
                {showButtons && (
                  <>
                    <td className="align-middle text-center">
                      <button
                        onClick={() => handleEdit(income.id, 'income')}
                        className="btn btn-primary"
                      >
                        Edit
                      </button>
                    </td>
                    <td className="align-middle text-center">
                      <button
                        onClick={() => handleDelete(income.id, 'income')}
                        className="btn btn-danger"
                      >
                        Delete
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          {expenses &&
            expenses.content.map((expense) => (
              <tr className="align-middle text-center" key={expense.id}>
                <td>{expense.id}</td>
                <td>{expense.name}</td>
                <td>{expense.description || 'No description'}</td>
                <td>{expense.groupName}</td>
                <td>{formatDate(expense.created)}</td>
                <td>{formatPrice(expense.amount)}</td>
                {showButtons && (
                  <>
                    <td className="align-middle text-center">
                      <button
                        onClick={() => handleEdit(expense.id, 'expense')}
                        className="btn btn-primary"
                      >
                        Edit
                      </button>
                    </td>
                    <td className="align-middle text-center">
                      <button
                        onClick={() => handleDelete(expense.id, 'expense')}
                        className="btn btn-danger"
                      >
                        Delete
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))}
        </tbody>
      </Table>
    </>
  )
}

export default TableGroups
