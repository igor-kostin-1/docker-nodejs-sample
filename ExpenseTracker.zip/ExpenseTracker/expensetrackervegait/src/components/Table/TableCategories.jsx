import { Table } from 'react-bootstrap'
import Loader from '../Loader/Loader'
import apiInstance from '../../api/apiInstance'
import { useState } from 'react'
import toast from 'react-hot-toast'
import EditGroupForm from '../EditGroupForm/EditGroupForm'
import useFetch from '../../hooks/useFetch'
const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL
function TableCategories({ expensesCategories, incomesCategories, fetchData }) {
  const [loading, setLoading] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [editedTransaction, setEditedTransaction] = useState(null)
  const [transactionType, setTransactionType] = useState('expensegroup')
  // const { fetchData } = useFetch()
  const handleDelete = async (id, type) => {
    const confirmDelete = window.confirm(
      'Are you sure you want to delete this transaction?',
    )

    if (!confirmDelete) {
      return
    }
    try {
      setLoading(true)
      await apiInstance.delete(`${baseUrl}/${type}group/${id}`)
      toast.success('Transaction deleted successfully')
      // handleRefetch()
    } catch (error) {
      console.error('Error deleting transaction:', error)
      toast.error('Failed to delete transaction')
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = async (id, type) => {
    console.log(type)
    try {
      setLoading(true)
      const response = await apiInstance.get(`${baseUrl}/${type}group/${id}`)
      setEditedTransaction({ ...response.data, type })
      setEditMode(true)
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }
  if (!expensesCategories && !incomesCategories) return <Loader />

  return (
    <>
      {editMode && (
        <EditGroupForm
          open={true}
          setOpen={setEditMode}
          transaction={editedTransaction}
          editMode={editMode}
          transactionType={transactionType}
          handleRefetch={fetchData}
        />
      )}
      <Table
        responsive
        striped
        bordered
        hover
        size="lg"
        className="text-center"
      >
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th colSpan={2}>Action</th>
          </tr>
        </thead>
        <tbody>
          {incomesCategories &&
            incomesCategories.map((income) => (
              <tr className="align-middle text-center" key={income.id}>
                <td>{income.id}</td>
                <td>{income.name}</td>
                <td>{income.description || 'No description'}</td>
                <td className="align-middle text-center">
                  <button
                    onClick={() => handleEdit(income.id, 'income')}
                    className="btn btn-primary"
                  >
                    Edit
                  </button>
                </td>
                <td className="align-middle text-center">
                  <button
                    onClick={() => handleDelete(income.id, 'income')}
                    className="btn btn-danger"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          {expensesCategories &&
            expensesCategories.map((expense) => (
              <tr className="align-middle text-center" key={expense.id}>
                <td>{expense.id}</td>
                <td>{expense.name}</td>
                <td>{expense.description || 'No description'}</td>
                <td className="align-middle text-center">
                  <button
                    onClick={() => handleEdit(expense.id, 'expense')}
                    className="btn btn-primary"
                  >
                    Edit
                  </button>
                </td>
                <td className="align-middle text-center">
                  <button
                    onClick={() => handleDelete(expense.id, 'expense')}
                    className="btn btn-danger"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>
    </>
  )
}

export default TableCategories
