import { NavLink } from 'react-router-dom'
// import styles from './Navbar.module.css'
import { Container, Nav, Navbar, Row } from 'react-bootstrap'
import { useAuth } from '../../context/AuthContext'
const NavbarComponent = () => {
  const { user, logout, login } = useAuth()

  const isPremiumUser = user && user.roles.includes('ROLE_PREMIUM_USER')

  return (
    <Navbar expand="lg" bg="dark" variant="dark">
      <Container>
        <NavLink to="/dashboard" className="navbar-brand">
          ExpTrckr
        </NavLink>
        <Navbar.Toggle
          aria-controls="basic-navbar-nav"
          className="ms-auto w-auto border-0"
        />
        <Navbar.Collapse
          id="basic-navbar-nav"
          className="justify-content-start"
        >
          <Nav className="ms-auto mt-sm-2 mt-lg-0  d-flex justify-content-center align-items-center">
            <Nav.Link as={NavLink} to="/dashboard">
              Dashboard
            </Nav.Link>

            <Nav.Link as={NavLink} to="/transactions-groups">
              Groups
            </Nav.Link>
            <Nav.Link as={NavLink} to="/transactions">
              Transactions
            </Nav.Link>

            {isPremiumUser && (
              <Nav.Link as={NavLink} to="/blog">
                Blog
              </Nav.Link>
            )}
            <Nav.Link as={NavLink} to="/login" onClick={!user ? login : logout}>
              {user ? 'Logout' : 'Login'}
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default NavbarComponent
