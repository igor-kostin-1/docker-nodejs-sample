import { NavLink } from 'react-router-dom'
import styles from './Navbar.module.css'
import { Container, Row } from 'react-bootstrap'
import { useAuth } from '../../context/AuthContext'
const Navbar = () => {
  const { user, logout, login } = useAuth()
  return (
    <Container fluid>
      <Row>
        <header className={styles.header}>
          <nav className={styles.navbar}>
            <div className={styles.logo}>
              <h2>ExpTrckr</h2>
            </div>

            <div className={styles.links}>
              <NavLink className={styles.navLinks} to="/dashboard">
                Dashboard
              </NavLink>
              <NavLink className={styles.navLinks} to="/transactions-groups">
                Groups
              </NavLink>
              <NavLink className={styles.navLinks} to="/blog">
                Blog
              </NavLink>
              <NavLink
                onClick={!user ? login : logout}
                className={styles.navLinks}
                to="/login"
              >
                {user ? 'Logout' : 'Login'}
              </NavLink>
            </div>
          </nav>
        </header>
      </Row>
    </Container>
  )
}

export default Navbar
