import { Col, Container, Row, Nav, Tab } from 'react-bootstrap'
import Loader from '../Loader/Loader'
import useFetch from '../../hooks/useFetch'
import TableGroups from '../Table/TableGroups'
import ErrorPage from '../../pages/errorPage/ErrorPage'
import { useState } from 'react'

const Dashboard = () => {
  const [refetch, setRefetch] = useState(false)
  const {
    data: expenses,
    isLoading: expensesLoading,
    error: expensesError,
  } = useFetch('/expense?size=5', refetch)

  const {
    data: incomes,
    isLoading: incomesLoading,
    error: incomesError,
  } = useFetch('/income?size=5', refetch)
  if (expensesLoading || incomesLoading) return <Loader />
  if (expensesError || incomesError) {
    return (
      <ErrorPage expensesError={expensesError} incomesError={incomesError} />
    )
  }

  return (
    <Tab.Container defaultActiveKey="expenses">
      <Row className="justify-content-center align-items-center my-4">
        <Col sm={12}>
          <Nav variant="tabs" className="flex-row justify-content-center mb-2">
            <Nav.Item>
              <Nav.Link eventKey="expenses">Expenses</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="incomes">Incomes</Nav.Link>
            </Nav.Item>
          </Nav>
        </Col>
        <Col sm={12}>
          <Tab.Content>
            <Tab.Pane eventKey="expenses">
              <h3 className="text-start mb-3">Last 5 Expenses</h3>
              <TableGroups
                expenses={expenses}
                handleRefetch={() => setRefetch((prev) => !prev)}
                showButtons={false}
              />
            </Tab.Pane>
            <Tab.Pane eventKey="incomes">
              <h3 className="text-start mb-3">Last 5 Incomes</h3>
              <TableGroups
                incomes={incomes}
                handleRefetch={() => setRefetch((prev) => !prev)}
              />
            </Tab.Pane>
          </Tab.Content>
        </Col>
      </Row>
    </Tab.Container>
  )
}

export default Dashboard
