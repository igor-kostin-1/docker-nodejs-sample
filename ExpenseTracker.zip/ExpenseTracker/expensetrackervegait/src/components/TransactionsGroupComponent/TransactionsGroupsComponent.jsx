import { Col, Container, Nav, Row, Tab } from 'react-bootstrap'
import useFetch from '../../hooks/useFetch'

import Loader from '../Loader/Loader'
import TableCategories from '../Table/TableCategories'

const TransactionsGroupsComponent = ({
  transactionType,
  setTransactionType,
}) => {
  const { data, isLoading, error, fetchData } = useFetch(`/${transactionType}`)
  // const {
  //   data: incomesCategories,
  //   isLoading: incomesLoading,
  //   error: incomesError,
  // } = useFetch('/incomegroup')
  const handleSelect = (value) => {
    setTransactionType(value)
  }
  console.log(transactionType)
  if (isLoading) return <Loader />
  if (error) return <div>Error: {error.message}</div>
  return (
    <Container className="vh-100">
      <Tab.Container onSelect={handleSelect} activeKey={transactionType}>
        <Row className="justify-content-center align-items-center my-4">
          <Col sm={12}>
            <Nav
              variant="tabs"
              className="flex-row justify-content-center mb-2"
            >
              <Nav.Item>
                <Nav.Link eventKey="expensegroup">Expenses/Groups</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="incomegroup">Incomes/Groups</Nav.Link>
              </Nav.Item>
            </Nav>
          </Col>
          <Col sm={12}>
            <Tab.Content>
              <Tab.Pane eventKey="expensegroup">
                <h3 className="text-start mb-3">Expenses/Groups</h3>
                <TableCategories
                  expensesCategories={data}
                  fetchData={fetchData}
                />
              </Tab.Pane>
              <Tab.Pane eventKey="incomegroup">
                <h3 className="text-start mb-3">Incomes/Groups</h3>
                <TableCategories
                  incomesCategories={data}
                  fetchData={fetchData}
                />
              </Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </Container>
  )
}

export default TransactionsGroupsComponent
