import React, { useEffect, useState } from 'react'
import { Col, Collapse, Modal, Row } from 'react-bootstrap'
import Button from 'react-bootstrap/Button'
import Form from 'react-bootstrap/Form'
import { useForm } from 'react-hook-form'
import apiInstance from '../../api/apiInstance'
import toast from 'react-hot-toast'
import useTransactionCategories from '../../hooks/useTransactionGroups'
const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL
function AddTransactionForm({
  open,
  setOpen,
  handleRefetch,
  fetchIncome,
  fetchExpense,
  transaction,
  editMode,
  transactionType,
}) {
  // const [transactionType, setTransactionType] = useState('expense')
  const [addCategory, setAddCategory] = useState(false)
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm({ defaultValues: { transactionType: transaction?.type } })

  const { categories } = useTransactionCategories(transactionType)

  useEffect(() => {
    if (transaction && editMode) {
      setValue('name', transaction.name)
      setValue('description', transaction.description)
      setValue('amount', transaction.amount)
      setValue('group.name', transaction.group.name)
      setValue('group.description', transaction.group.description)
    }
  }, [transaction, setValue, editMode])

  const onSubmit = async (data) => {
    if (editMode) {
      try {
        await apiInstance.put(
          `${baseUrl}/${transactionType}/${transaction.id}`,
          data,
        )
        reset()
        await handleRefetch()
        setOpen(false)
      } catch (error) {
        toast.error(error.message)
      }
    } else {
      try {
        await apiInstance.post(`${baseUrl}/${transactionType}`, data)
        reset()
        setOpen(false)
        await handleRefetch()
        ;(await fetchIncome()) || (await fetchExpense())
      } catch (error) {
        toast.error(error.message)
      }
    }
  }

  return (
    <>
      <Modal show={open} onHide={() => setOpen(false)} size="md" centered>
        <Modal.Header closeButton>
          <Modal.Title>
            {editMode ? 'Edit Transaction' : 'Add Transaction'}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col>
              <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group className="mb-3" controlId="transactionType">
                  <Form.Label>Choose transaction type</Form.Label>
                  <Form.Select
                    {...register('transactionType')}
                    disabled={addCategory || editMode}
                  >
                    <option value="income">Income</option>
                    <option value="expense">Expense</option>
                  </Form.Select>
                </Form.Group>

                <Form.Group className="mb-3" controlId="category">
                  <Form.Label>Group name</Form.Label>
                  <div className="d-flex align-items-center">
                    <Form.Select
                      disabled={addCategory}
                      className="w-75"
                      {...register('group.id', {
                        required: !addCategory
                          ? 'Please choose category or add new one'
                          : false,
                      })}
                    >
                      <option disabled value="">
                        Select category
                      </option>
                      {categories.map((category, index) => (
                        <option key={index} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </Form.Select>
                    <span className="mx-2"> or</span>
                    <Button
                      variant="secondary"
                      className="w-25"
                      onClick={() => {
                        setAddCategory((prev) => !prev)
                        reset({ 'group.id': '' })
                      }}
                    >
                      Add New
                    </Button>
                  </div>
                </Form.Group>

                <Collapse className="bg-light py-3 px-3" in={addCategory}>
                  <div>
                    <Form.Group className="mb-3" controlId="new-category-name">
                      <Form.Label>Name</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Enter name"
                        {...register('group.name', {
                          required: addCategory
                            ? 'Please provide group name'
                            : false,
                          maxLength: {
                            value: 20,
                            message: 'Name should not exceed 20 characters',
                          },
                        })}
                        isInvalid={errors['group.name']}
                        style={{ width: '50%', marginRight: '10px' }}
                        disabled={!addCategory}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors['group.name'] && errors['group.name'].message}
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group
                      className="mb-3"
                      controlId="additionalDescription"
                      disabled={!addCategory}
                    >
                      <Form.Label>Description</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Group description"
                        {...register('group.description')}
                        style={{ width: '50%', marginRight: '10px' }}
                      />
                    </Form.Group>
                  </div>
                </Collapse>

                <Form.Group className="mb-3" controlId="name">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter name"
                    {...register('name', {
                      required: 'Name is required',
                      maxLength: {
                        value: 20,
                        message: 'Name should not exceed 20 characters',
                      },
                    })}
                    isInvalid={errors.name}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.name && errors.name.message}
                  </Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-3" controlId="transactonDescription">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Transaction description"
                    {...register('description')}
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="amount">
                  <Form.Label>Amount</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="Amount"
                    {...register('amount', {
                      required: 'Amount  is required',
                    })}
                    isInvalid={errors.amount}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.amount && errors.amount.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <Button size="md" variant="primary" type="submit">
                  {editMode ? 'Edit' : 'Submit'}
                </Button>
              </Form>
            </Col>
          </Row>
        </Modal.Body>
      </Modal>
    </>
  )
}

export default AddTransactionForm
