import { Link } from 'react-router-dom'
import styles from './CreateNewUserForm.module.css'
import { useForm } from 'react-hook-form'

import useSignup from '../../hooks/useSignUp'
import UserRole from '../../constants/UserRole'

const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL
const signupUrl = `${baseUrl}/auth/signup`

const CreateNewUserForm = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm()
  const { isLoading, signupUser } = useSignup(signupUrl)

  const onSubmit = async (data) => {
    const transformedData = {
      username: data.userName,
      fullName: data.fullName,
      email: data.email,
      password: data.password,
      role: [
        data.type === UserRole.PREMIUM_USER ? UserRole.PREMIUM_USER : null,
      ],
    }
    signupUser(transformedData)
  }
  return (
    <div className={styles.container}>
      <h3>Welcome to Expense Tracker</h3>
      <form onSubmit={handleSubmit(onSubmit)} className={styles.form}>
        <div className={styles.inputContainer}>
          <input
            type="text"
            name="fullName"
            placeholder="Enter your full name"
            {...register('fullName', {
              required: 'Full name is required',
              minLength: {
                value: 5,
                message: 'Full name must be at least 5 characters long',
              },
            })}
          />
          {errors.fullName && (
            <span className={styles.errorMessage}>
              {errors.fullName.message}
            </span>
          )}
        </div>
        <div className={styles.inputContainer}>
          <input
            type="text"
            name="userName"
            placeholder="Enter your user name"
            {...register('userName', {
              required: 'User name is required',
              minLength: {
                value: 3,
                message: 'User name must be at least 3 characters long',
              },
            })}
          />
          {errors.userName && (
            <span className={styles.errorMessage}>
              {errors.userName.message}
            </span>
          )}
        </div>
        <div className={styles.inputContainer}>
          <input
            type="text"
            name="email"
            placeholder="email"
            {...register('email', {
              required: 'Email is required',
              pattern: {
                value: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                message: 'Invalid email address',
              },
            })}
          />
          {errors.email && (
            <span className={styles.errorMessage}>{errors.email.message}</span>
          )}
        </div>
        <div className={styles.inputContainer}>
          <input
            type="password"
            id="password"
            placeholder="password"
            name="password"
            {...register('password', {
              required: 'Password is required',
              minLength: {
                value: 8,
                message: 'Password needs a minimum of 8 characters',
              },
            })}
          />
          {errors.password && (
            <span className={styles.errorMessage}>
              {errors.password.message}
            </span>
          )}
        </div>
        <div className={styles.inputContainer}>
          <input
            type="password"
            placeholder="confirm password"
            name="confirmPass"
            {...register('confirmPass', {
              required: 'This field is required',
              validate: (value) =>
                value === getValues().password || 'Passwords need to match',
            })}
          />
          {errors.confirmPass && (
            <span className={styles.errorMessage}>
              {errors.confirmPass.message}
            </span>
          )}
        </div>
        <div>
          <label htmlFor="type">Please choose user type: &nbsp;</label>
          <select
            name="type"
            id="type"
            {...register('type', { required: 'Please choose type' })}
          >
            <option value="regular_user">Regular</option>
            <option value="premium_user">Premium</option>
          </select>
        </div>
        <button className='btn btn-primary' disabled={isLoading} type="submit">
          {isLoading ? 'Signing up...' : 'Sign Up'}
        </button>
        <span>or</span>
        <Link to="/login">Log in</Link>
      </form>
    </div>
  )
}

export default CreateNewUserForm
