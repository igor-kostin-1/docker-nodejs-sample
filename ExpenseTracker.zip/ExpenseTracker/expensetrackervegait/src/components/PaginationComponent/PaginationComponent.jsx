import Pagination from 'react-bootstrap/Pagination'

function PaginationComponent({ totalPages, setPageNum, pageNum }) {
  const pageNumbers = Array.from({ length: totalPages })
  const lastPage = totalPages - 1
  return (
    <Pagination size="md">
      <Pagination.First onClick={() => setPageNum(0)} />
      <Pagination.Prev
        onClick={() => setPageNum(pageNum - 1)}
        disabled={pageNum == 0}
      />
      {pageNumbers.map((_, index) => (
        <Pagination.Item
          onClick={() => setPageNum(index)}
          key={index}
          active={pageNum === index}
        >
          {index + 1}
        </Pagination.Item>
      ))}
      <Pagination.Next
        onClick={() => setPageNum(pageNum + 1)}
        disabled={pageNum == totalPages - 1}
      />
      <Pagination.Last onClick={() => setPageNum(lastPage)} />
    </Pagination>
  )
}

export default PaginationComponent
