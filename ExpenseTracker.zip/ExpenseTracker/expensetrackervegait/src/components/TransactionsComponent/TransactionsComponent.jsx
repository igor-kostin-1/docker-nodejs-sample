import { Col, Nav, Row, Tab } from 'react-bootstrap'
import Loader from '../Loader/Loader'
import TableGroups from '../Table/TableGroups'
import ErrorPage from '../../pages/errorPage/ErrorPage'

const TransactionsComponent = ({
  data,
  error,
  isLoading,
  fetchData,
  transactionType,
  setTransactionType,
}) => {
  const handleSelect = (value) => {
    setTransactionType(value)
  }
  if (isLoading || error) return <Loader />
  if (error) {
    return (
      <ErrorPage
        expensesError={transactionType === 'expense' && error}
        incomesError={transactionType === 'income' && error}
      />
    )
  }
  return (
    <Tab.Container onSelect={handleSelect} activeKey={transactionType}>
      <Row className="justify-content-center align-items-center my-4">
        <Col sm={12}>
          <Nav variant="tabs" className="flex-row justify-content-center mb-2">
            <Nav.Item>
              <Nav.Link eventKey="expense">Expenses</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="income">Incomes</Nav.Link>
            </Nav.Item>
          </Nav>
        </Col>
        <Col sm={12}>
          <Tab.Content>
            <Tab.Pane eventKey="expense">
              <h3 className="text-start mb-3">Expenses</h3>
              <TableGroups
                expenses={data}
                handleRefetch={fetchData}
                showButtons={true}
                transactionType={transactionType}
              />
            </Tab.Pane>
            <Tab.Pane eventKey="income">
              <h3 className="text-start mb-3">Incomes</h3>
              <TableGroups
                incomes={data}
                handleRefetch={fetchData}
                showButtons={true}
                transactionType={transactionType}
              />
            </Tab.Pane>
          </Tab.Content>
        </Col>
      </Row>
    </Tab.Container>
  )
}

export default TransactionsComponent
