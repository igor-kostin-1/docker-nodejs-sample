import { Badge, Card } from 'react-bootstrap'
import useFetch from '../../hooks/useFetch'
import { formatPrice } from '../../helpers/formatPrice'
const TotalAmountCard = () => {
  const transactions = useFetch('/user/stats/transaction/sum')
  if (!transactions.data) return
  const totalAmount = transactions.data.total

  return (
    <Card className="text-center border-0">
      <Card.Body>
        <Card.Title>Total Amount</Card.Title>
        <h2>
          <Card.Text className="bg">
            <Badge bg={totalAmount >= 0 ? 'primary' : 'danger'}>
              {formatPrice(totalAmount)}
            </Badge>
          </Card.Text>
        </h2>
      </Card.Body>
    </Card>
  )
}

export default TotalAmountCard
