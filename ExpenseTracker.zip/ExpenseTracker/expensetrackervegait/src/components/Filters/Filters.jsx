import { useEffect, useState } from 'react'
import { Col, Container, Form, Row } from 'react-bootstrap'

import { useDebounce } from '../../hooks/useDebounce'

const Filters = ({ setSize, setName, setAmountGT, setAmountLT }) => {
  const handleSizeChange = (e) => {
    setSize(e.target.value)
  }
  const handleName = (e) => {
    setName(e.target.value)
  }
  const handleAmountGT = (e) => {
    setAmountGT(e.target.value)
  }
  const handleAmountLT = (e) => {
    setAmountLT(e.target.value)
  }

  return (
    <Container className="my-4 p-3 border">
      <h3>Filters</h3>
      <Form>
        <Row>
          <Col>
            <Form.Group className="mb-3   " controlId="size">
              <Form.Label>Size</Form.Label>
              <Form.Select onChange={handleSizeChange}>
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="20">20</option>
                <option value="20">50</option>
              </Form.Select>
            </Form.Group>
          </Col>

          <Col>
            <Form.Group className="mb-3 " controlId="size">
              <Form.Label>Name</Form.Label>
              <Form.Control
                onChange={handleName}
                type="text"
                placeholder="Search by name"
              />
            </Form.Group>
          </Col>
        </Row>
        <Row className="bg-light d-flex p-2 justify-content-center align-items-center">
          <Col xs={12} md={4}>
            <Form.Group className="mb-3">
              <Form.Label htmlFor="amountGT">Amount Greater Than</Form.Label>
              <Form.Control
                type="number"
                name="amountGT"
                placeholder="Enter amount"
                id="amountGT"
                onChange={handleAmountGT}
              />
            </Form.Group>
          </Col>
          <Col xs={12} md={4}>
            <Form.Group className="mb-3">
              <Form.Label htmlFor="amountLT">Amount Less Than</Form.Label>
              <Form.Control
                type="number"
                name="amountLT"
                placeholder="Enter amount"
                id="amountLT"
                onChange={handleAmountLT}
              />
            </Form.Group>
          </Col>
        </Row>
      </Form>
    </Container>
  )
}

export default Filters
