import React, { useEffect, useState } from 'react'
import { Col, Collapse, Modal, Row } from 'react-bootstrap'
import Button from 'react-bootstrap/Button'
import Form from 'react-bootstrap/Form'
import { useForm } from 'react-hook-form'
import apiInstance from '../../api/apiInstance'
import toast from 'react-hot-toast'
import useTransactionCategories from '../../hooks/useTransactionGroups'
import useFetch from '../../hooks/useFetch'
const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL
function EditGroupForm({
  open,
  setOpen,
  handleRefetch,
  fetchIncome,
  fetchExpense,
  transaction,
  transactionType,
}) {
  //   const { fetchData } = useFetch()
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm()
  useEffect(() => {
    setValue('name', transaction.name)
    setValue('description', transaction.description)
  }, [setValue, transaction.name, transaction.description])
  const onSubmit = async (data) => {
    try {
      await apiInstance.put(
        `${baseUrl}/${transactionType}/${transaction.id}`,
        data,
      )
      reset()
      await handleRefetch()
      setOpen(false)
    } catch (error) {
      toast.error(error.message)
    }
  }

  return (
    <>
      <Modal show={open} onHide={() => setOpen(false)} size="md" centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Group</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col>
              <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group className="mb-3" controlId="name">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter name"
                    {...register('name', {
                      required: 'Name is required',
                      maxLength: {
                        value: 20,
                        message: 'Name should not exceed 20 characters',
                      },
                    })}
                    isInvalid={errors.name}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.name && errors.name.message}
                  </Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-3" controlId="transactonDescription">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Transaction description"
                    {...register('description')}
                  />
                </Form.Group>

                <Button size="md" variant="primary" type="submit">
                  Edit
                </Button>
              </Form>
            </Col>
          </Row>
        </Modal.Body>
      </Modal>
    </>
  )
}

export default EditGroupForm
