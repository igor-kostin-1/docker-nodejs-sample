import { Link } from 'react-router-dom'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import useLogin from '../../hooks/useLogin'
import styles from './LoginForm.module.css'
import { FaEye, FaEyeSlash } from 'react-icons/fa'
const baseUrl = import.meta.env.VITE_REACT_APP_BASE_URL
const loginUrl = `${baseUrl}/auth/login`
const LoginForm = () => {
  const [showPassword, setShowPassword] = useState(false)
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()
  const { loginUser, isLoading } = useLogin(loginUrl)

  const onSubmit = (data) => {
    loginUser(data)
  }
  return (
    <div className={styles.container}>
      <h3>Expense Tracker</h3>
      <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
        <div className={styles.inputContainer}>
          <input
            type="text"
            placeholder="username"
            id="username"
            name="username"
            {...register('username', {
              required: 'Username is required',
              minLength: {
                value: 5,
                message: 'Username must be at least 5 characters long',
              },
            })}
          />
          {errors.username && (
            <span className={styles.errorMessage}>
              {errors.username.message}
            </span>
          )}
        </div>
        <div className={styles.inputContainer}>
          <input
            type={!showPassword ? 'password' : 'text'}
            placeholder="password"
            id="password"
            name="password"
            {...register('password', {
              required: 'Password is required',
              minLength: {
                value: 8,
                message: 'Password must be at least 8 characters long',
              },
            })}
          />
          {showPassword ? (
            <FaEye
              className={styles.passwordIcon}
              onClick={() => setShowPassword((prevState) => !prevState)}
            />
          ) : (
            <FaEyeSlash
              className={styles.passwordIcon}
              onClick={() => setShowPassword((prevState) => !prevState)}
            />
          )}
          {errors.password && (
            <span className={styles.errorMessage}>
              {errors.password.message}
            </span>
          )}
        </div>

        <button
          className="btn btn-primary w-100"
          type="submit"
          disabled={isLoading}
        >
          {isLoading ? 'Signing in...' : 'Sign in'}
        </button>
        <span>or</span>
        <Link to="/create-new-account">Create new account</Link>
      </form>
    </div>
  )
}

export default LoginForm
