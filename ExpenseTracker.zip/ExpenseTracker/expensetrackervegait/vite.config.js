import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import eslintPlugin from 'vite-plugin-eslint'

// https://vitejs.dev/config/

export default defineConfig({
  plugins: [react(),eslintPlugin(),],
  define:{
    'process.env.VITE_REACT_APP_LOGIN_URL':JSON.stringify(process.env.VITE_REACT_APP_LOGIN_URL),
    'process.env.VITE_REACT_APP_SIGNUP_URL':JSON.stringify(process.env.VITE_REACT_APP_LOGIN_URL)
  },


})
